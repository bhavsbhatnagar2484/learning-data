var config = require('./config/config.js');
var request = require('request');

var baseHost= config.base.host;
var awdHost = config.base.awd;
var droolsHost = config.base.drools;
var soap = require('soap');

module.exports = {
getWorkItems: function(req, res,callback) {

    var role = req.headers.role_name;
    var producttype = req.headers.product_type;
    var manreview = req.headers.manreview;
    
    let region = req.headers.region_code;
    let company = req.headers.company_code;
    let url = 'http://cscmbpsnor403/environment-ws-2.3/EnvironmentWebService?wsdl' ;
    let args = {region: region, company:company};
    
    soap.createClient(url, function(err, client) {
     
        client.EnvironmentWebServiceService.EnvironmentWebServicePort.getCompanyDetail(args, function(err, result) {
            if(result != null){
      
            let businessarea_param = result.companyDetail.businessArea;
            let businessarea = businessarea_param.toUpperCase();
            console.log(businessarea);      
            // need to be deleted
            businessarea = "BHF";      
            var _body = {
                "role":role,
                "productType":producttype,
                "businessArea":businessarea,
                "manreview":manreview
            };
            var _baseurl =baseHost;
            var authenticateOptions = getHeaderOptions();
            authenticateOptions.url = droolsHost+'/csrPortal-rules/v1/rules/workItems/types/execute';
            authenticateOptions.body =JSON.stringify(_body);
    
            var _response = {};          
            var _items=[];
            request.post(authenticateOptions, function (error, response, body) {
                if(response && (response.statusCode === 200 || response.statusCode === 201)) {
                    var _body = JSON.parse(body);
                    for(var i=0;i<_body._links.item.length;i++){
                        var _type= _body._links.item[i].href.split("workItems")[1];
                        var _url=  _baseurl +_type;
                        _body._links.item[i].href = _url;    
                    }
                    _body._links.self['href'] = baseHost+"/types";
                    callback(null,_body);
                }
                else{
                    callback(error,body);         
                }
            });//request
           } 
           else{
                return "error";
           }
        });
    
    });
    },

    getWorkItem: function(req, res,callback) {
    var role = req.headers.role_name;
    var producttype = req.headers.product_type;
    var manreview = req.headers.manreview;
    let region = req.headers.region_code;
    let company = req.headers.company_code;
    var typename = req.params.typename;

    let url = 'http://cscmbpsnor403/environment-ws-2.3/EnvironmentWebService?wsdl' ;
    let args = {region: region, company:company};
    
    soap.createClient(url, function(err, client) {
        client.EnvironmentWebServiceService.EnvironmentWebServicePort.getCompanyDetail(args, function(err, result) {
         if(result != null){
      
            let businessarea_param = result.companyDetail.businessArea;
            let businessarea = businessarea_param.toUpperCase();
            console.log(businessarea);      
            // need to be deleted
            businessarea = "BHF";      
            
            var _body = {
                "role":role,
                "productType":producttype,
                "businessArea":businessarea,
                "manreview":manreview
            };
    
            var _baseurl =baseHost+"/types/";
            var authenticateOptions = getHeaderOptions();
            authenticateOptions.url = droolsHost+'/csrPortal-rules/v1/rules/workItems/types/'+typename;
            console.log(authenticateOptions.url);
            authenticateOptions.body =JSON.stringify(_body);
            var _response = {};          
            var _items=[];
            request.post(authenticateOptions, function (error, response, body) {
                if(response && (response.statusCode === 200 || response.statusCode === 201)) {
                    var _body = JSON.parse(body);
                    callback(null,_body);
                }
                else{
                    callback(error,null);         
                }
            });//request
        }
        else
        {
            return "error"
        }
        });
    });
    },
    
    getWorkItemsSchema: function(req, res,callback) {
    var role = req.headers.role_name;
    var producttype = req.headers.product_type;
    var manreview = req.headers.manreview;
    var typename = req.params.typename;
    var role = req.headers.role_name;
    var producttype = req.headers.product_type;
    var manreview = req.headers.manreview;
    
    let region = req.headers.region_code;
    let company = req.headers.company_code;
    let url = 'http://cscmbpsnor403/environment-ws-2.3/EnvironmentWebService?wsdl' ;
    let args = {region: region, company:company};
    
    soap.createClient(url, function(err, client) {
        client.EnvironmentWebServiceService.EnvironmentWebServicePort.getCompanyDetail(args, function(err, result) {
             if(result != null){
      
            let businessarea_param = result.companyDetail.businessArea;
            let businessarea = businessarea_param.toUpperCase();
            console.log(businessarea);      
            businessarea = "BHF";      
            
            var _body = {
                "role":role,
                "productType":producttype,
                "businessArea":businessarea,
                "manreview":manreview
            };
        var _baseurl =baseHost;
        var authenticateOptions = getHeaderOptions();
        authenticateOptions.url = droolsHost+'/csrPortal-rules/v1/rules/workItems/schemas/types/'+ typename ;
        authenticateOptions.body =JSON.stringify(_body);
  
        var _response = {};          
        request.post(authenticateOptions, function (error, response, body) {
            if(response && (response.statusCode === 200 || response.statusCode === 201)) {
                var _body = JSON.parse(body);
                callback(null,_body);
            }
            else{
                callback(error,null);         
            }
        });//request
        }
        else {
            return "error"
        }
      });
    });
    }
};

function getHeaderOptions() {
  var headerOptions = {
    headers: {
      'Content-Type': 'application/hal+json',
      'Accept': 'application/hal+json',
      'remote_user': 'AWDOMNI',
      'Accept-Language': 'en-US,en;q=0.8'
    },
  };
  return clone(headerOptions);
}
function clone(a) {
  return JSON.parse(JSON.stringify(a));
}
