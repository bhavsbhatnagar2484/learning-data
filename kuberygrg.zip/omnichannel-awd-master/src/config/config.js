var config = {};
config.base={};

config.base.key = process.env.KEY_DEV;
config.base.iv = process.env.IV_DEV;
config.base.host='https://dev.gateway.api.dxc.technology/csc-insurance-api-development/omnichannel-dev/omnichannel/dev/casemanagement/awd';
config.base.awd='https://v4-c3-dev.bps-test-services.com';
config.base.drools='https://v4-c3-dev.bps-test-services.com';
config.base.resourceAPIUrl = 'https://dev.gateway.api.dxc.technology/csc-insurance-api-development/omnichannel-dev/omnichannel/dev/resource/tenants/CSR/decrypt';
config.base.resourceAPIUrl.clientid = 'dc1809ba-d09f-4d9f-ae9c-304a7ff6fc88';
config.base.resourceAPIUrl.clientsecret='pK8eC3cQ4rD1pV0cC1dQ6uX3mQ5cP2qI1lQ6xG0fS1yP7sA2nN';
  
module.exports = config;
