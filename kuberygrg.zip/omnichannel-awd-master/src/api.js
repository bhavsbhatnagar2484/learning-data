var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var cors = require('cors');
var mongo = require('mongodb');

//Application file imports
var awdService = require('./awdService');
var droolsService = require('./droolsService');

var config = require('./config/config.js');
var multer  = require('multer');
var upload = multer({ dest: 'uploads/' });
var request = require('request');

var fs = require('fs');
var DOMParser = require('xmldom').DOMParser;
var XMLSerializer = require('xmldom').XMLSerializer;
var path = require('path');
var xmlReader = require('read-xml');

var xmlString ;
var filename ;

var router = express.Router();
var port = process.env.PORT;

app.listen(port);
app.use('', router);

app.use(function(req, res, next){
  var whitelist = ['http://localhost:4200','http://localhost:4600', 'http://dev.bhf.csr.s3-website-us-east-1.amazonaws.com', 'http://sit.bhf.csr.s3-website-us-east-1.amazonaws.com']
  var host = req.headers.origin;
    if(host != undefined){
        whitelist.forEach(function(val, key){
            if (host.indexOf(val) > -1){
                res.setHeader('Access-Control-Allow-Origin', host);
            }
        });
        res.setHeader('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Requested-With, accept, Access-Control-Request-Method, Access-Control-Request-Headers, Authorization, accept-language, User-Language, Content-Type, User-Id, x-requested-with,iPlanetDirectoryPro,X-IBM-Client-Secret,X-IBM-Client-Id,remote_user,role_name,product_type,manreview,company_code,regions_code');
        res.setHeader('Access-Control-Allow-Credentials', 'true'); 
        res.setHeader('Access-Control-Allow-Methods','POST, GET, DELETE, PUT, PATCH, OPTIONS'); 
        res.setHeader('Access-Control-Expose-Headers','Origin, Access-Control-Request-Method, Access-Control-Allow-Origin, Access-Control-Allow-Credentials'); 
    }
       next();
});

app.use(bodyParser.json());

console.log('app started');

// Path to get the list of available work items - 
app.options('/types',  function(req, res, next) {
    next();
});

//path to get the schemas of workitems
app.options('/schemas/types/:typename',  function(req, res, next) {
    next();
});

//path to get the workitem
app.options('/types/:typename',  function(req, res, next) {
    next();
});

//path to create a workitem for a policy
app.options('/contracts/:contractid/instances',  function(req, res, next) {
    next();
});

// Path to get the list of available work items - 
app.get('/types',  function(req, res) {
    droolsService.getWorkItems(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            res.status(200);
            res.json(result);
        }
    })
});

//path to get the schemas of workitems
app.get('/schemas/types/:typename',  function(req, res) {
    droolsService.getWorkItemsSchema(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            res.status(200);
            res.json(result);
        }
    })
});

//path to get the workitem
app.get('/types/:typename',  function(req, res) {
    droolsService.getWorkItem(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

// Path to get the list of workitems for a policy - 
app.get('/contracts/:contractid/instances',  function(req, res) {
    awdService.getPolicyWorkItems(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

//path to create a workitem for a policy
app.post('/contracts/:contractid/instances',  function(req, res) {
    awdService.createPolicyWorkItem(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        }else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});
// Path to get a workitem based on a woritemid - 
app.options('/contracts/:contractid/instances/:instanceid',  function(req, res, next) {
    next();
});

//path to get the sources for a workitem
app.options('/contracts/:contractid/instances/:instanceid/sources',  function(req, res, next) {
    next();
});

//path to get the history for a workitem
app.options('/contracts/:contractid/instances/:instanceid/history',  function(req, res, next) {
    next();
});

//path to get the comments for a workitem
app.options('/contracts/:contractid/instances/:instanceid/comments',  function(req, res, next) {
    next();
});

//path to update the comments for a workitem
app.options('/contracts/:contractid/instances/:instanceid/comments',  function(req, res, next) {
    next();
});

// Path to get the list of available work items - 
app.options('/user/instances',  function(req, res, next) {
    next();
});

app.options('/contracts/:contractid/instances/:instanceid/sources',  function(req, res, next) {
    next();
});

// Path to get the list of available work items - 
app.get('/types',  function(req, res) {
    droolsService.getWorkItems(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            res.status(200);
            res.json(result);
        }
    })
});

//path to get the schemas of workitems
app.get('/schemas/types/:typename',  function(req, res) {
    droolsService.getWorkItemsSchema(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            res.status(200);
            res.json(result);
        }
    })
});

//path to get the workitem
app.get('/types/:typename',  function(req, res) {
    droolsService.getWorkItem(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

//path to create a workitem for a policy
app.post('/contracts/:contractid/instances',  function(req, res) {
    awdService.createPolicyWorkItem(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        }else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

// Path to get the list of workitems for a policy - 
app.get('/contracts/:contractid/instances',  function(req, res) {
    awdService.getPolicyWorkItems(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

// Path to get a workitem based on a woritemid - 
app.get('/contracts/:contractid/instances/:instanceid',  function(req, res) {
    awdService.getPolicyWorkItem(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

//path to get the sources for a workitem
app.get('/contracts/:contractid/instances/:instanceid/sources',  function(req, res) {
    awdService.getPolicyWorkItemSources(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

//path to get the history for a workitem
app.get('/contracts/:contractid/instances/:instanceid/history',  function(req, res) {
    awdService.getPolicyWorkItemHistory(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

//path to get the comments for a workitem
app.get('/contracts/:contractid/instances/:instanceid/comments',  function(req, res) {
    awdService.getPolicyWorkItemComments(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

//path to update the comments for a workitem
app.post('/contracts/:contractid/instances/:instanceid/comments',  function(req, res) {
    awdService.updatePolicyWorkItemComments(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.json(result);
            }
        }
    })
});

// Path to get the list of available work items - 
app.get('/user/instances',  function(req, res) {
    awdService.getAssignedWorkItems(req, res, function(err, result) {
        if (err) {
            res.status(400);
            res.json(err);
        } else {
            if (result.code === '400') {
                res.status(400);
                res.json(result);
            } else {
                res.status(200);
                res.setHeader('Content-Type', 'application/hal+json');
                res.setHeader('Access-Control-Allow-Headers', 
                              'Origin, Content-Type, X-Requested-With, accept, Access-Control-Request-Method, Access-Control-Request-Headers, Authorization, accept-language, User-Language, Content-Type, User-Id, x-requested-with,iPlanetDirectoryPro,X-IBM-Client-Secret,X-IBM-Client-Id,remote_user');
                res.setHeader('Access-Control-Allow-Credentials', 'true'); 
                res.setHeader('Access-Control-Allow-Methods','POST, GET, DELETE, PUT, PATCH, OPTIONS'); 
                res.setHeader('Access-Control-Expose-Headers','Origin, Access-Control-Request-Method, Access-Control-Allow-Origin, Access-Control-Allow-Credentials'); 
                res.json(result);
            }
        }
    })
});

var storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'config')
    },
    filename: (req, file, cb) => {
      filename = file.originalname+'-'+ Date.now(); 
      cb(null, filename);
    }
});

var upload = multer({storage: storage});

app.post('/contracts/:contractid/instances/:instanceid/sources', upload.single('file'),  function (req,res) {
    
    var instanceid = req.params.instanceid;
    var business_area_name = req.params.businessarea;
    console.log(instanceid);
    var FILE = path.join(__dirname, './xml/source_create.xml');
    xmlReader.readXML(fs.readFileSync(FILE), function(err, data) {
        if (err) {
            console.error(err);
            res.send('error');
        }
        var createXML = new DOMParser().parseFromString(data.content);
        createXML.getElementsByTagName("businessAreaName")[0].childNodes[0].data = business_area_name;
        createXML.getElementsByTagName("parentIds")[0].childNodes[0].data = instanceid;
        var xmlString = new XMLSerializer().serializeToString(createXML);
        console.log(xmlString);
        const options = {
            method: "POST",
            url: "http://cscdhtpnor600.fsg.amer.csc.com:82/awdServer/b2b/services/v1/instances",
            headers: {
                'Content-Type': 'application/vnd.dsttechnologies.awd+xml',
                'Accept': 'application/vnd.dsttechnologies.awd+xml',
                'remote_user': 'AWDOMNI',
                'Accept-Language': 'en-US,en;q=0.8'
            },
            formData : {
                "request":xmlString,
                "file_input" : {
                "value": fs.readFileSync("./config/"+filename),
                "options":{
                    "filename":filename
                }
            }
        }    
    };
    
    request(options, function (err, response, body) 
    {
        if (response && (response.statusCode === 200 || response.statusCode === 201)) {
            res.send({"source_id":body});
        }
        else{
            res.send({"not OK":"not OK"});
        }
    });
});
});

