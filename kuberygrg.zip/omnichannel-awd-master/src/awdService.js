var request = require('request');
var xmlGen = require('js2xmlparser');
var parseString = require('xml2js').parseString;
var libxmljs = require("libxmljs");
var fs = require('fs');
var DOMParser = require('xmldom').DOMParser;
var XMLSerializer = require('xmldom').XMLSerializer;
var config = require('./config/config.js');
var workitems_lookup = require('./json/workitems_lookup.json');
var path = require('path');
var xmlReader = require('read-xml');
var datetime = require('node-datetime');
var crypto = require('crypto');

var baseHost= config.base.host;
var awdHost = config.base.awd;
var droolsHost = config.base.drools;
var soap = require('soap');
module.exports = {
    getAssignedWorkItems : function (req, res, callback){
      var authenticateOptions = getHeaderOptions();
      console.log(authenticateOptions);
      var _start = req.query._start;
      var _self
      var _base =baseHost+"/user/instances" ;
      var _id,_policy_number,_created,_status,_typename;
      var _items = [];
      var _response={};
      var itemProperties = { 
            "policy_number": {
                "type": "string"
            },
            "created": {
                "type": "string"
            },
            "worktype": {
                "type": "string"
            },
            "status": {
                "type": "string"
            }
      }          
      authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/user/instances';
      console.log(authenticateOptions);
      request.get(authenticateOptions, function (error, response, body) {
        if (response && (response.statusCode === 200 || response.statusCode === 201)) {
          parseString(body, function (err, result) {
          var count = result.worklistInstances.$.unfilteredCount;
          var length = result.worklistInstances.instance.length;
          for(var i=0;i<length;i++){
            _id=result.worklistInstances.instance[i].$.id;
            noOfFields = result.worklistInstances.instance[i].fieldValues[0].fieldValue.length;
            for(var j=0;j<noOfFields;j++){
              if(result.worklistInstances.instance[i].fieldValues[0].fieldValue[j].$.name == 'POLN')
              {
              _policy_number = result.worklistInstances.instance[i].fieldValues[0].fieldValue[j].value[0];
              }
            }//for
            _typename = result.worklistInstances.instance[i].typeName[0]._;
            var _typename_desc = getTypenameDesc(_typename);
            var businessarea = result.worklistInstances.instance[i].businessAreaName[0]._;
            _status = result.worklistInstances.instance[i].statusName[0]._;
            var _date = result.worklistInstances.instance[i].date + " " + result.worklistInstances.instance[i].time;
            _datetime = formatDateTime(_date);
            _href = baseHost+"/contracts/"+_policy_number+"/instances/"+_id;
            var _summary = {
              "policy_number": _policy_number,
              "created": _datetime,
              "worktype":_typename_desc,
              "status":_status
            };
            if(_policy_number !=undefined && !_policy_number==''){
            _items.push({
              "href": _href,
              "summary": _summary,
            });
            }
          }//for      
          //_response['count'] = count;
          _response['_links'] = {
            "item": _items,
            "self": {
              "href": _base,
            }
          }
          _response['_options'] = {
            "links": [
              {
                "href": _base,
                "mediaType": "application/vnd.hal+json",
                "method": "GET",
                "rel": "fetch"
              }
            ],
            "properties":itemProperties
          }
           callback(null, _response);
        });
      }else{
        res.status(500).send('error');
      }
    });
    },
    createPolicyWorkItem : function (req, res, callback){
    console.log('creating');
    let region = req.headers.region_code;
    let company = req.headers.company_code;
    let contractid = req.params.contractid;
    let url = 'http://cscmbpsnor403/environment-ws-2.3/EnvironmentWebService?wsdl' ;
    let args = {region: region, company:company};
    var _self;
    var _base =baseHost+"/contracts/"+contractid+"/instances" ;
    soap.createClient(url, function(err, client) {
    client.EnvironmentWebServiceService.EnvironmentWebServicePort.getCompanyDetail(args, function(err, result) {
      if(result != null){
        let businessarea_param = result.companyDetail.businessArea;
        let businessarea = businessarea_param.toUpperCase();
        console.log(businessarea);
            var authenticateOptions = getHeaderOptions();
        authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/instances';
        var fields = req.body;
        var keys = Object.keys(fields);
  
        var FILE = path.join(__dirname, './xml/intake_create.xml');
        xmlReader.readXML(fs.readFileSync(FILE), function(err, data) {
          if (err) {
            console.error(err);
            res.send('error');
          }
          var createXML = new DOMParser().parseFromString(data.content);
          createXML.getElementsByTagName("businessAreaName")[0].childNodes[0].data = businessarea;
          for (i=0;i<keys.length;i++){
            var keyname = keys[i];
            if(keyname === 'typename'){
             createXML.getElementsByTagName("typeName").data = 'INTAKE';
            }else if(keyname==='status'){
              createXML.getElementsByTagName("statusName").data =fields[keyname];
            }else if(keyname === 'comments'){
              createXML.getElementsByTagName("addComment").data = fields[keyname];
            }  
            else{  
              fieldEle = createXML.createElement("fieldValue");
              fieldEle.setAttribute("name",keyname)
              valueEle = createXML.createElement("value");
              valueText=createXML.createTextNode(fields[keyname]);
              valueEle.appendChild(valueText);
              fieldEle.appendChild(valueEle);
              createXML.getElementsByTagName("fieldValues")[0].appendChild(fieldEle);
            }
          }  
          createXML.getElementsByTagName("fieldValues")[0].appendChild(fieldEle);
          var xmlString = new XMLSerializer().serializeToString(createXML);
          console.log(xmlString);
          authenticateOptions.body = xmlString;
          request.post(authenticateOptions, function (error, response, body) {
            if (response && (response.statusCode === 200 || response.statusCode === 201)) {
              parseString(body, function (err, result) {
                var _response = {'code':'200', 'message': 'Workitem created successfully', 'success': true}
                callback(null,_response);
              });
            }else{
              res.status(500).send('error');
            }
          });//request
        });//fs     
      }
      else{
        return "error";
      }
    });
  });
 },   

  getPolicyWorkItems : function (req, res, callback){
    let region = req.headers.region_code;
    let company = req.headers.company_code;
    let _start = req.query._start;
    let contractid = req.params.contractid;
    let url = 'http://cscmbpsnor403/environment-ws-2.3/EnvironmentWebService?wsdl' ;
    let args = {region: region, company:company};
    var _self;
    var _base =baseHost+"/contracts/"+contractid+"/instances" ;
    soap.createClient(url, function(err, client) {
    client.EnvironmentWebServiceService.EnvironmentWebServicePort.getCompanyDetail(args, function(err, result) {
      if(result != null){
        let businessarea_param = result.companyDetail.businessArea;
        let businessarea = businessarea_param.toUpperCase();
        console.log(businessarea);
        console.log(contractid);
        const decryptUrl = {
          method: "POST",
          url: config.base.resourceAPIUrl,
          headers: {
            'Content-Type': 'application/json',
            'X-IBM-Client-Id':'dc1809ba-d09f-4d9f-ae9c-304a7ff6fc88',
            'X-IBM-Client-Secret':'pK8eC3cQ4rD1pV0cC1dQ6uX3mQ5cP2qI1lQ6xG0fS1yP7sA2nN'
          },
          body : JSON.stringify({
            'encrypted_text': [contractid]
          })
        };
        request(decryptUrl, function (error, response, body) {
          var authenticateOptions = getHeaderOptions();
          if (response && (response.statusCode === 200 || response.statusCode === 201)) {
            let policy_number = JSON.parse(body).clear_text[0][1];
            if(_start == undefined){
              authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/instances/lookup';
              _start= 0;
              _self=_base;
            }
            else{
              _self = _base+"?_start="+_start+"&_num=20";
              var pageNo = (parseInt(_start) / 20 ) +1 ;
              if(pageNo > 1){
                authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/instances/lookup?page='+pageNo;
              }
            }
            console.log(authenticateOptions.url);
            var FILE = path.join(__dirname, './xml/workitems_history.xml');
            
            xmlReader.readXML(fs.readFileSync(FILE), function(err, data) {
            if (err) {
              console.error(err);
              res.send('error');
            }
            var lookupXML = new DOMParser().parseFromString(data.content);
            lookupXML.getElementsByTagName("lookupParameter")[0].childNodes[0].data = policy_number;
            var xmlString = new XMLSerializer().serializeToString(lookupXML);
            authenticateOptions.body = xmlString;
            var _items=[];
            var _href;
            var _datetime, _status, _typename,_claimtype;
            var _create=baseHost+"/contracts/"+contractid+"/instances";
            var _response={};
            var count = 0;
            var length = 0;
            console.log(xmlString);
            request.put(authenticateOptions, function (error, response, body) {
            if (response && (response.statusCode === 200 || response.statusCode === 201)) {
                parseString(body, function (err, result) {
                if(result.lookupResults.$.total !=undefined){
                  count = result.lookupResults.$.total;
                }
                if(result.lookupResults.instance !=undefined && result.lookupResults.instance.length !=undefined){   
                  length = result.lookupResults.instance.length;
                  for(var i=0;i<length;i++){
                    _id=result.lookupResults.instance[i].$.id;
                    _date = result.lookupResults.instance[i].date[0] + " " + result.lookupResults.instance[i].time;
                    _datetime = formatDateTime(_date);
                    _typename = result.lookupResults.instance[i].typeName[0]._;
                    var noOfFields = result.lookupResults.instance[i].fieldValues[0].fieldValue.length;
                    for(var j=0;j<noOfFields;j++){
                       if(result.lookupResults.instance[i].fieldValues[0].fieldValue[j].$.name === 'CLTY'){
                          _claimtype = result.lookupResults.instance[i].fieldValues[0].fieldValue[j].value[0];
                       }//if
                    }//for
                    var _typename_desc = getTypenameDesc(_typename);
                    var _claimtype_desc = getTypenameDesc(_claimtype);
                    _status = result.lookupResults.instance[i].statusName[0]._;
                    _href = baseHost+"/contracts/"+contractid+"/instances/"+_id;
                    var _summary = {
                      "datetime": _datetime,
                      "typename": _typename_desc,
                      "status":_status,
                      "worktype":_claimtype_desc
                    };
                    _items.push({
                      "href": _href,
                      "summary": _summary,
                    });
                  }//for
                  _response['count'] = count;
                  _response['_links'] = getPaginationLinks(_start,20,count,_base,_items);
                }
                else{
                  _response['_links'] = {
                    "item": _items,
                    "self": {
                      "href": _base,
                    }
                  };
                }

               _response['_options'] = {
                  "links": [
                  {
                    "href": _self,
                    "mediaType": "application/vnd.hal+json",
                    "method": "GET",
                    "rel": "fetch"
                  },
                  {
                    "href": _create,
                    "mediaType": "application/json",
                    "method": "POST",
                    "rel": "create",
                    "schema": {
                        "properties":"" 
                    }
                  }
               ],
                "properties": "",
              }
                callback(null, _response);
              }); 
            }
            else{
              console.log(body);
              res.status(500).send('error');
            }
          }); //reqeust.put is close
        });
      }
      else{
            console.log(error);
      }
    });//decrypt url 
   }
  });
  });
 },
 updatePolicyWorkItemComments : function (req, res, callback){
  var workComment={
    "@":{
        "xmlns": "http://www.dsttechnologies.com/awd/rest/v1"
    },
    "comment":"this has to get updated"
  };
  
  if(!req.body){
      res.status(400).send({'message': 'Bad data', 'success': false});
    }

  workComment.comment = req.body.comment;
  console.log(workComment.comment);
  var instanceid =req.params.instanceid;
  var authenticateOptions = getHeaderOptions();
  authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/instances/'+ instanceid + '/history/comments';
  authenticateOptions.body = xmlGen.parse("addComment", workComment);
  request.post(authenticateOptions, function (error, response, body) {
    if (response && (response.statusCode === 200 || response.statusCode === 201)) {
      parseString(body, function (err, result) {
        var _response = {'code':'200', 'message': 'comments updated successfully', 'success': true}
        callback(null,_response);
      });
    }
    else{
      res.status(500).send('error');
    }
  });
}, 
getPolicyWorkItemSources : function (req, res, callback){
  var instanceid = req.params.instanceid;
  var contractid = req.params.contractid;
  var authenticateOptions = getHeaderOptions();
  var _self =baseHost+"/contracts/"+contractid+"/instances/"+instanceid+"/sources" ;
  var _update =baseHost+"/contracts/"+contractid+"/instances/"+instanceid+"/sources" ;
  
  authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/instances/'+instanceid+'/children';
  var _date, _time,_user,_comment;
  var _items=[];
  var _response={};
  request.get(authenticateOptions, function (error, response, body) {
    if (response && (response.statusCode === 200 || response.statusCode === 201)) {
      parseString(body, function (err, result) {
        if(result.children.sourceInstance !=undefined && result.children.sourceInstance.length !=undefined)
        {   
            var length = result.children.sourceInstance.length;
            //console.log(length);
            for(var i=0;i<length;i++){
              var _id=result.children.sourceInstance[i].$.id;
              //console.log(_id);
              var _typename = result.children.sourceInstance[i].typeName[0]._;
              var _source = "Source:" + _typename+" "+ _id;
              _href = _self+"/"+_id;
              var _summary = {
                "source": _source
              };
              _items.push({
                "href": _href,
                "summary": _summary,
              });
            }//for
            _response['_links'] = {
              "item": _items,
              "self": {
                "href": _self,
              }
          }
                  }
        else{
            _response['_links'] = {
              "item": _items,
              "self": {
                "href": _self,
              }
            };
        }

            _response['_options'] = {
            "links": [
              {
                "href": _self,
                "mediaType": "application/vnd.hal+json",
                "method": "GET",
                "rel": "fetch"
              },
              {
                "href": _update,
                "mediaType": "application/json",
                "method": "POST",
                "rel": "update",
                "schema": {
                  "properties":""
                }
              }
            ],
            "properties": "",
          }
           callback(null, _response);
      });
    }  
    else{
      res.status(500).send('error');
    }
  });  
},

getPolicyWorkItemComments : function (req, res, callback){
  var instanceid = req.params.instanceid;
  var contractid = req.params.contractid;
  var authenticateOptions = getHeaderOptions();
  var _self =baseHost+"/contracts/"+contractid+"/instances/"+instanceid+"/comments" ;
  var _update =baseHost+"/contracts/"+contractid+"/instances/"+instanceid+"/comments" ;
  var commentProperties = { 
            "comment": {
                "type": "string"
            },
            "date":{
                "type": "string"
            },
            "time":{
                "type": "string"
            },
            "user": {
                "type": "string"
            } 
  };          

  authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/instances/'+instanceid+'/history/comments';
  console.log(authenticateOptions.url);
  var _date, _time,_user,_comment;
  var _items=[];
  var _response={};
  request.get(authenticateOptions, function (error, response, body) {
    if (response && (response.statusCode === 200 || response.statusCode === 201)) {
      parseString(body, function (err, result) {
        if(result.comments.comment !=undefined && result.comments.comment.length !=undefined)
        {   
            var length = result.comments.comment.length;
            for(var i=0;i<length;i++){
              _id=result.comments.comment[i].$.id;
              _date = result.comments.comment[i].date[0] + " " 
              _time= result.comments.comment[i].time[0]; 
              _user = result.comments.comment[i].userNameInfo[0].$.userId;
              _comment=result.comments.comment[i].text[0]._;

              _href = _self+"/"+_id;
              var _summary = {
                "date": _date,
                "time":_time,
                "user": _user,
                "comment":_comment,
              };
              _items.push({
                "href": _href,
                "summary": _summary,
              });
            }//for
            _response['_links'] = {
              "item": _items,
              "self": {
                "href": _self,
              }
          }
                  }
        else {
            _response['_links'] = {
              "item": _items,
              "self": {
                "href": _self,
              }
            };
        }

            _response['_options'] = {
            "links": [
              {
                "href": _self,
                "mediaType": "application/vnd.hal+json",
                "method": "GET",
                "rel": "fetch"
              },
              {
                "href": _update,
                "mediaType": "application/json",
                "method": "POST",
                "rel": "update",
                "schema": {
                  "properties":commentProperties
                }
              }
            ],
            "properties": commentProperties,
          }
           callback(null, _response);
      });
    }  
    else{
      res.status(500).send('error');
    }
  });  
},

getPolicyWorkItemHistory : function (req, res, callback){
  var instanceid = req.params.instanceid;
  var contractid = req.params.contractid;
  var authenticateOptions = getHeaderOptions();
  var _self =baseHost+"/contracts/"+contractid+"/instances/"+instanceid+"/history" ;
  var _update =baseHost+"/contracts/"+contractid+"/instances/"+instanceid+"/comments" ;
  var historyProperties = { 
            "comment": {
                "type": "string"
            },
            "datetime":{
                "type": "string"
            },
            "enddatetime":{
                "type": "string"
            },
            "time":{
                "type": "string"
            },
            "user": {
                "type": "string"
            },
            "typename":{
                "type": "string"
            },
            "queue":{
                "type": "string"
            },
            "status":{
                "type": "string"
            }
  };          

  authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/instances/'+instanceid+'/history';
  var _items=[];
  var _response={};
  var _comment,_queue_name,_status_name,_type_name,_enddate,_enddatetime;  
  request.get(authenticateOptions, function (error, response, body) {
    if (response && (response.statusCode === 200 || response.statusCode === 201)) {
      parseString(body, function (err, result) {
      
            if(result.history.systemEvent !=undefined && result.history.systemEvent.length !=undefined){
              var length = result.history.systemEvent.length;
              for(var i=0;i<length;i++){
                _date = result.history.systemEvent[i].date[0] + " " + result.history.systemEvent[i].time[0]; 
                _datetime = formatDateTime(_date);
                _user = result.history.systemEvent[i].userName[0]._;
                
        if(result.history.systemEvent[i].stopDate != undefined && result.history.systemEvent[i].stopTime !=undefined){ 
         _enddate = result.history.systemEvent[i].stopDate[0] + " " + result.history.systemEvent[i].stopTime[0]; 
                 _enddatetime = formatDateTime(_enddate);
                }
            
        if(result.history.systemEvent[i].text != undefined){ 
                  _comment=result.history.systemEvent[i].text[0]._;
                }
                _href = result.history.systemEvent[i].link[0].$.href;
                if(result.history.systemEvent[i].statusName != undefined){ 
                  _status_name =  result.history.systemEvent[i].statusName[0]._;
                }  
                if(result.history.systemEvent[i].queueName != undefined){ 
                 _queue_name =   result.history.systemEvent[i].queueName[0]._;
                }
                if(result.history.systemEvent[i].typeName != undefined){
                  _type_name =   result.history.systemEvent[i].typeName[0]._;
                }               
                var _summary = {
                  "datetime": _datetime,
                  "enddatetime":_enddatetime,
                  "user": _user,
                  "comment":_comment,
                  "typename":_type_name,
                  "queue":_queue_name,
                  "status":_status_name
                };
                _items.push({
                  "href": _href,
                  "summary": _summary,
                });
              }//for
            }
            if(result.history.serviceEvent !=undefined && result.history.serviceEvent.length !=undefined){
              var length = result.history.serviceEvent.length;
              for(var i=0;i<length;i++){
                _date = result.history.serviceEvent[i].date[0] + " " 
                _datetime = formatDateTime(_date);
                _user = result.history.serviceEvent[i].userName[0]._;
      
        if(result.history.serviceEvent[i].stopDate != undefined && result.history.serviceEvent[i].stopTime !=undefined){ 
         _enddate = result.history.serviceEvent[i].stopDate[0] + " " + result.history.serviceEvent[i].stopTime[0]; 
                 _enddatetime = formatDateTime(_enddate);
                }
            
                if(result.history.serviceEvent[i].text != undefined){ 
                  _comment=result.history.serviceEvent[i].text[0]._;
                }
                _href = result.history.serviceEvent[i].link[0].$.href;
                if(result.history.serviceEvent[i].statusName != undefined){ 
                  _status_name =  result.history.serviceEvent[i].statusName[0]._;
                }  
                if(result.history.serviceEvent[i].queueName != undefined){ 
                 _queue_name =   result.history.serviceEvent[i].queueName[0]._;
                }
                if(result.history.serviceEvent[i].typeName != undefined){
                  _type_name =   result.history.serviceEvent[i].typeName[0]._;
                }
                
                var _summary = {
                  "datetime": _datetime,
          "enddatetime":_enddatetime,
                  "user": _user,
                  "comment":_comment,
                  "typename":_type_name,
                  "queue":_queue_name,
                  "status":_status_name
                };
                _items.push({
                  "href": _href,
                  "summary": _summary,
                });
              }//for
            }
            if(result.history.comment !=undefined && result.history.comment.length !=undefined){
              var length = result.history.comment.length;
              for(var i=0;i<length;i++){
                //_id=result.history.comment[i].$.id;
                _date = result.history.comment[i].date[0] + " " 
                _datetime = formatDateTime(_date);
                _user = result.history.comment[i].userName[0]._;
        
        if(result.history.comment[i].stopDate != undefined && result.history.comment[i].stopTime !=undefined){ 
          _enddate = result.history.comment[i].stopDate[0] + " " + result.history.comment[i].stopTime[0]; 
                  _enddatetime = formatDateTime(_enddate);
                }
            
                if(result.history.comment[i].text != undefined){ 
                  _comment=result.history.comment[i].text[0]._;
                }
                _href = result.history.comment[i].link[0].$.href;
                if(result.history.comment[i].statusName != undefined){ 
                  _status_name =  result.history.comment[i].statusName[0]._;
                }  
                if(result.history.comment[i].queueName != undefined){ 
                 _queue_name =   result.history.comment[i].queueName[0]._;
                }
                if(result.history.comment[i].typeName != undefined){
                  _type_name =   result.history.comment[i].typeName[0]._;
                }
              
                var _summary = {
                  "datetime": _datetime,
          "enddatetime":_enddatetime,
                  "user": _user,
                  "comment":_comment,
                  "typename":_type_name,
                  "queue":_queue_name,
                  "status":_status_name
                };
                _items.push({
                  "href": _href,
                  "summary": _summary,
                });
              }//for
            }
            if( result.history.processEvent !=undefined && result.history.processEvent.length !=undefined){
              var length = result.history.processEvent.length;
              for(var i=0;i<length;i++){
                //_id=result.history.processEvent[i].$.id;
                _date = result.history.processEvent[i].date[0] + " " 
                _datetime = formatDateTime(_date);
                _user = result.history.processEvent[i].userName[0]._;
      
        if(result.history.processEvent[i].stopDate != undefined && result.history.processEvent[i].stopTime !=undefined){ 
         _enddate = result.history.processEvent[i].stopDate[0] + " " + result.history.processEvent[i].stopTime[0]; 
                 _enddatetime = formatDateTime(_enddate);
                }
            
                if(result.history.processEvent[i].text != undefined){ 
                  _comment=result.history.processEvent[i].text[0]._;
                }
                _href = result.history.processEvent[i].link[0].$.href;
                if(result.history.processEvent[i].statusName != undefined){ 
                  _status_name =  result.history.processEvent[i].statusName[0]._;
                }  
                if(result.history.processEvent[i].queueName != undefined){ 
                 _queue_name =   result.history.processEvent[i].queueName[0]._;
                }
                if(result.history.processEvent[i].typeName != undefined){
                  _type_name =   result.history.processEvent[i].typeName[0]._;
                }               
                var _summary = {
                  "datetime": _datetime,
          "enddatetime":_enddatetime,
                  "user": _user,
                  "comment":_comment,
                  "typename":_type_name,
                  "queue":_queue_name,
                  "status":_status_name
                };_items.push({
                  "href": _href,
                  "summary": _summary,
                });
              }//for
            }
            _response['_links'] = {
              "item": _items,
              "self": {
                "href": _self,
              }
          
            }
            _response['_options'] = {
            "links": [
              {
                "href": _self,
                "mediaType": "application/vnd.hal+json",
                "method": "GET",
                "rel": "fetch"
              },
              {
                "href": _update,
                "mediaType": "application/json",
                "method": "POST",
                "rel": "update",
                "schema": {
                  "properties":historyProperties
                }
              }
            ],
            "properties": historyProperties,
          }

           callback(null,_response);
      });
    }  
    else{
      res.status(500).send('error');
    }
  });  
},

getPolicyWorkItem : function (req, res, callback){
  var authenticateOptions = getHeaderOptions();
  var instanceid = req.params.instanceid;
  var contractid = req.params.contractid;
  var workDetailProperties = { 
            "datetime": {
                "type": "string"
            },
            "queuename": {
                "type": "string"
            },
            "typename": {
                "type": "string"
            }
  };          

  authenticateOptions.url = awdHost+'/awdServer/b2b/services/v1/instances/'+instanceid;
  var _self = baseHost +"/contracts/"+contractid+"/instances/"+instanceid;
  var _history_url = baseHost +"/contracts/"+contractid+"/instances/"+instanceid+"/history";
  var _comments_url = baseHost +"/contracts/"+contractid+"/instances/"+instanceid+"/comments";
  var _sources_url = baseHost + "/contracts/"+contractid+"/instances/"+instanceid+"/sources";
  var _response={};
  var _datetime,_typename_desc,_queue_name;
  request.get(authenticateOptions, function (error, response, body) {
    if (response && (response.statusCode === 200 || response.statusCode === 201)) {
      parseString(body, function (err, result) {
         _date = result.instance.date[0] + " " + result.instance.time; 
         _datetime = formatDateTime(_date);
         var _typename = result.instance.typeName[0]._;
         _typename_desc = getTypenameDesc(_typename);
         _queue_name = result.instance.queueName[0]._;
        _response['_links'] = {
          "sources": {
              "href": _sources_url
          },
          "history": {
              "href": _history_url
          },
          "comments": {
            "href": _comments_url
          },
          "self": {
            "href": _self
          }
        };

        _response['_options'] = {
          "links": [
            {
              "href": _comments_url,
              "mediaType": "application/vnd.hal+json",
              "method": "POST",
              "rel": "updatecomments"
            },
            {
              "href": _sources_url,
              "mediaType": "application/json",
              "method": "POST",
              "rel": "updatesources",
            },
            {
              "href": _sources_url,
              "mediaType": "application/json",
              "method": "GET",
              "rel": "fetchsources"
            },
            {
              "href": _history_url,
              "mediaType": "application/vnd.hal+json",
              "method": "GET",
              "rel": "fetchhistory"
            }
          ],
             "properties": workDetailProperties
        };
        _response['datetime'] = _datetime;
        _response['queuename'] = _queue_name;
        _response['typename'] = _typename;
        callback(null,_response);
    });
  }else{
      res.status(500).send('error');
    }
  });
}


};

function getPaginationLinks(_start,_num,_count,_self,_items){
  var numOfRec= parseInt(_start)+parseInt(_num);
  var _links = {  };
  if(_start == 0){
    var _nextStart = parseInt(_start)+parseInt(_num);
    _next=_self+"?_start="+_nextStart+"&_num="+_num;
    _links ={
      "item": _items,
      "self": {
        "href": _self,
        "mediaType": "application/json"
      },
      "next":{
        "href": _next,
        "mediaType": "application/json"
      }
    };
  } //if
  else if(numOfRec > _count){
    var _prevStart = parseInt(_start)-parseInt(_num);
    _prev=_self+"?_start="+_prevStart+"&_num="+_num;
    _self=_self+"?_start="+_start+"&_num="+_num;
    _links ={
      "item": _items,
      "self": {
        "href": _self,
        "mediaType": "application/json"
      },
      "up":{
        "href": _prev,
        "mediaType": "application/json"
      }
    };
  }//else if
  else {
    var _prevStart = parseInt(_start)+parseInt(_num);
    _prev=_self+"?_start="+_prevStart+"&_num="+_num;
    var _nextStart = parseInt(_start)+parseInt(_num);
    _next=_self+"?_start="+_nextStart+"&_num="+_num;
   _self=_self+"?_start="+_start+"&_num="+_num;
    
    _links ={
      "item": _items,
      "self": {
        "href": _self,
        "mediaType": "application/json"
      },
      "up":{
        "href": _prev,
        "mediaType": "application/json"
      },
      "next":{
        "href": _next,
        "mediaType": "application/json"
      }
    };  
  }
  return _links; 
}

function getHeaderOptions() {
  var headerOptions = {
    headers: {
      'Content-Type': 'application/vnd.dsttechnologies.awd+xml',
      'Accept': 'application/vnd.dsttechnologies.awd+xml',
      'remote_user': 'AWDOMNI',
      'Accept-Language': 'en-US,en;q=0.8'
    },
  };
  return clone(headerOptions);
}
function clone(a) {
  return JSON.parse(JSON.stringify(a));
}
function getTypenameDesc(typename) {
  for(var i=0;i<workitems_lookup.workitems.length;i++){
    if((workitems_lookup.workitems[i].worktype_id).toString() == typename){
      return workitems_lookup.workitems[i].worktype_label;
    }else {
      return typename;
    }
  }
}
function formatDateTime(_dt){
  var dt = datetime.create(_dt);
  _datetime = dt.format('m/d/y H:M');
  return _datetime;              
}
