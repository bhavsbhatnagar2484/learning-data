# omnichannel-awd
This repository host code for AWD microservice which exposes Omnichannel complaint APIs for integration with AWD system.
