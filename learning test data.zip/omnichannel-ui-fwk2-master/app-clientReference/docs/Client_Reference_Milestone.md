# Milestone Document for Client Reference Application
The document contains the details of the milestone for Client Reference application.

## Contant
* [Components Availability](#ComponentsAvailability)
* [Required Component](#RequiredComponent)
* [Milestone Details for Client Reference Application](#MilestoneDetailsforClientReferenceApplication)
    * [Milestone 1](#Milestone1)
    * [Milestone 2](#Milestone2)
    * [Milestone 3](#Milestone3)
    * [Milestone 4](#Milestone4)

## <a name='ComponentsAvailability'></a>Components Availability
Till milestone 3 below are the list of available components
- button
- checkbox
- custom
- date
- default
- label
- modal
- renderer
- select
- table
- text

## <a name='RequiredComponent'></a>Required Component
As per available Client Reference application of Framework below is the list of required components.
- action
- buttonGroup
- buttonSmall
- carousel
- custom
- datemask
- email
- label
- marketing
- select
- table
- text
- textarea
- wizards

## <a name='MilestoneDetailsforClientReferenceApplication'></a>Milestone Details for Client Reference Application
Each milestone we will convert in 2 sprints

### <a name='Milestone1'></a>Milestone 1

#### Sprint46
- Create new Client Reference application
- Congifure application based on requirements
- Verify application structure
- Inject OcInfra as a dependency

#### Sprint47
- Start creating screen for Client Reference application
- Use of components
  - button
  - label
  - text

### <a name='Milestone2'></a>Milestone 2

#### Sprint48

#### Sprint49

### <a name='Milestone3'></a>Milestone 3

#### Sprint50

#### Sprint51

### <a name='Milestone4'></a>Milestone 4

#### Sprint52

#### Sprint53
