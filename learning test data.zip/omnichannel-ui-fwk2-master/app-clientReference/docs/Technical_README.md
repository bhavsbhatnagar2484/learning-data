# AppClientReference
Reference application using Framework 2.

* [Scope](#Scope)
* [Technical Approach](#TechnicalApproach)
* [Details](#Details)
* [Backlog](#Backlog)

## <a name='Scope'></a>Scope

## <a name='TechnicalApproach'></a>Technical Approach

## <a name='Details'></a>Details

## <a name='Backlog'></a>Backlog
