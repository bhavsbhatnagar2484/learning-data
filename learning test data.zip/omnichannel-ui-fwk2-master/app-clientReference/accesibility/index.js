
const puppeteer = require('puppeteer');
const lighthouse = require('lighthouse');
const log = require('lighthouse-logger');
const Printer = require('lighthouse/lighthouse-cli/printer');
const fs = require('fs');
const backstop = require('backstopjs');
const config = require('./accesibilityConf');


const lighthouseRunner = {
    runAudit : function(url, debugPort, screenName) {
        const flags = { logLevel: 'info', output: 'html' , port: debugPort};
        log.setLevel(flags.logLevel);
        try{
            lighthouse(url, flags, null).then(results => {
                results.artifacts = undefined;
                Printer.checkOutputPath = 'report/' + screenName + '.' + flags.output;
                if (!fs.existsSync(Printer.checkOutputPath)) {
                    fs.closeSync(fs.openSync((Printer.checkOutputPath), 'w'));
                }
                return Printer.write(results.report, flags.output, Printer.checkOutputPath);
           
            });
        }catch(e){
            console.log(e);
            return true;
        }        
            
        
    }
};


 
 
(async () => {
  const browserArgs = '--remote-debugging-port=' + config.environmnentPort;
  const browser = await puppeteer.launch({headless: true, slowMo:100, args: ['--remote-debugging-port=9222']});
  const page = await browser.newPage();
  const loginPage = config.environmnentUrl 
  await page.goto(loginPage);
  
  lighthouseRunner.runAudit(loginPage, config.environmnentPort, 'login');

  //await page.screenshot({path: 'login.png'});

  await page.waitForSelector('[id="authUsername"]');
  await page.click('[id="authUsername"]');
  await page.type('[id="authUsername"]', 'kkdrensk')
  await page.click('[id="authPassword"]');
  await page.type('[id="authPassword"]', 'kkdrensk')

  await page.click('[id="loginBtn"]');

  await page.waitForSelector('[id="client-search-first-name"]');
 
  //await page.screenshot({path: 'search.png'});

  const searchClientPage = config.environmnentUrl  + 'screen/searchClient';

  lighthouseRunner.runAudit(searchClientPage, config.environmnentPor, 'searchClient');


  backstop('test');


//  browser.close();

})();