
var accesibilityConf = {

    environmnentUrl:'https://omnichannel-ui-fwk2-dev.mybluemix.net/',
    environmnentPort: 9222
    
}

module.exports = accesibilityConf;