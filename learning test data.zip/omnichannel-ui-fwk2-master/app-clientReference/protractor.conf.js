// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts
var jasminePtorFailfast = require('./e2e/utilities/jasminePtorFailfast');
var htmlReporter = require('./e2e/utilities/htmlReporter');
var fs = require('fs');
//const { SpecReporter } = require('jasmine-spec-reporter');

exports.config = {
  allScriptsTimeout: 11000,
  seleniumAddress: 'http://54.175.14.78:4444/wd/hub',
  seleniumPort: 4444,
    // seleniumAddress: 'http://localhost:4444/wd/hub',
    // seleniumPort: 4444,
   suites:
  { 
    RegressionTest: ['./e2e/tests/**/app.TS_CRA0*.ts'] ,
    
    SmokeTest: ['./e2e/tests/**/app.TS_CRA001.ts', './e2e/tests/**/app.TS_CRA015.ts',
    './e2e/tests/**/app.TS_CRA010.ts', './e2e/tests/**/app.TS_CRA011.ts',
     './e2e/tests/**/app.TS_CRA014.ts'] ,
    
    // CustomTest: ['./e2e/tests/**/app.TS_CRA001.ts'] 
  },
  
  capabilities: {
    'browserName': 'chrome',
    //  maxInstances: 2
  },
  // directConnect: true,
  framework: 'jasmine',
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000,
    print: function() {}
  },
  allScriptsTimeout: 400000,
  getPageTimeout: 50000,
  beforeLaunch: function() {
    require('ts-node').register({
      project: 'e2e/tsconfig.e2e.json'
    });
    console.log('beforeLaunch');
    // check if folders exists or not, if not create them
    var functionalReportsFolder = 'functionalReports';
    var reportsFolder = 'functionalReports/Reports';
    var reportsScreenshotsFolder = 'functionalReports/reports_screenshots';
    var perfFile = 'functional/Perf';
    
    if(!fs.existsSync(perfFile)){
      fs.mkdirSync(perfFile);
      console.log('perfFile created');
    };
    
    if(!fs.existsSync(functionalReportsFolder)){
      fs.mkdirSync(functionalReportsFolder);
      console.log('functionalReportsFolder created');
    };
    if(!fs.existsSync(reportsFolder)){
      fs.mkdirSync(reportsFolder);
      console.log('reportsFolder created');
    };
    if(!fs.existsSync(reportsScreenshotsFolder)){
      fs.mkdirSync(reportsScreenshotsFolder);
      console.log('reportsScreenshotsFolder created');
    };
    
  },
  afterLaunch: function() {
    console.log('afterLaunch');
    var htmlreporter = new htmlReporter();
    htmlreporter.readDatafromFile();
    console.log('onto htmlreporter.createHTML(function()');
    htmlreporter.createHTML();
    console.log('onto htmlreporter.writeFile();');
    htmlreporter.writeFile();              
    console.log('completed htmlreporter.writeFile();');
    htmlreporter.deleteFiles();
  },
  onPrepare: function() {
    browser.manage().timeouts().pageLoadTimeout(50000);
    browser.manage().deleteAllCookies();
    browser.manage().timeouts().implicitlyWait(25000);
    browser.getCapabilities().then(function (cap) {
      browser.browserName = cap.browserName;
    });
    jasmine.getEnv().addReporter(new jasminePtorFailfast().launch());
  
  },
  params:
    {
		wait : 50000,
		waitTime : 30000,
		env:'DEV',
    Url:'http://dev.oc.cra.s3-website-us-east-1.amazonaws.com/#/',
   
    // Url:'http://sit.oc.cra.s3-website-us-east-1.amazonaws.com',
    // Url:'http://demo.oc.cra.s3-website-us-east-1.amazonaws.com'
    }
};
