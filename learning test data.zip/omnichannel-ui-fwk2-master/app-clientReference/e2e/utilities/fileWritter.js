'use strict';
var fs = require('fs');
// var screenshot = require('desktop-screenshot');
var fileWritter = function(){
	this.path = 'functionalReports/Reports';
	this.data = "";
	this.isSuiteFailed;
	this.passedSpec;
	this.failedSpecs;
	this.disabledSpecs;
	this.SpecStartedAt;
	this.SuiteExecutionTime;
	this.totalSuites=0;
	this.failedSuites=0;
	this.suite;
}
fileWritter.prototype.startHTML = function(suiteInfo) {
	var prefixHTML = '<html>'
	+'<head>'
	+'<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>'
	+'<span><failedcases>FailedTestCases</failedcases></span>'
	+'<span><passedcases>PassedTestCases</passedcases></span>'
	+'</head>'
	+'<body>';
	// +'<div class="ConsolidateResult">'
	// +'<span><b>Total Test Cases</b> : <b>TotalTestCases</b></span>'
	// +'<span><b>Passed Test Cases</b> : <b>PassedTestCases</b></span>'
	// +'<span><b>Failed Test Cases</b> : <b>FailedTestCases</b></span>'
	// +'</div>';
	this.data = this.data+prefixHTML;
	// console.log('this.data in startHTML'+this.data);
};
fileWritter.prototype.startBodyWithSuite = function(suiteName) {
	this.isSuiteFailed = false;
	this.passedSpec=0;
	this.failedSpecs=0;
	this.disabledSpecs=0;
	this.SuiteExecutionTime=0;
	this.totalSuites++;
	this.suite = suiteName;
	var prefixSuite = '<div class="container">'
	+'<div class="header" style="background-color : SuiteResultBcColor">'
	+'<span class="suiteName"><b>'+suiteName+'</b></span>'
	+'&nbsp;&nbsp;&nbsp;<span class="suiteName"><b>SuiteExecutionTime</b></span>'
	+'<div>Total : SpecsInSuite</div>'
	+'<div>Passed : passedSpecInSuite</div>'
	+'<div>Failed : FailedSpecInSuite</div>'
	+'<div>Disabled : DisabledSpecInSuite</div>'
	+'</div>'
	+'<div class="content">'
	+'<ul>';
	this.data = this.data+prefixSuite;
	// console.log('this.data in startBodyWithSuite'+this.data);
	console.log(':::::::::Count:::::::::'+this.totalSuites+'::::::::::::::::SCRIPT NAME::::::::::::::'+suiteName+':::::::::::');
};
fileWritter.prototype.startSpec = function(){
	this.SpecStartedAt = (new Date()).getTime();
}
fileWritter.prototype.addSpecResult = function(specName,resultStatus,message,description) {
	if(!message) message=""
		if(!description) description=""
			var specEndedAt = (new Date()).getTime();
		var captureTime =  (specEndedAt - this.SpecStartedAt)/1000; 
		this.SuiteExecutionTime = this.SuiteExecutionTime + captureTime;
		var imagePath = 'reports_screenshots/'+this.suite+'.png';
		var imagePathWarn =  'reports_screenshots/'+this.suite+'@warn.png';
		//console.log('imagePath:::',imagePath,'imagePathWarn::::',imagePathWarn);
		var specResult =  '<li style="background-color : SpecResultBcColor"><b>'+specName
		+'</b><div><b>'+captureTime+'</b></div><div>'+message+'</div>'
		+ "imagePlaceHolder"
		+'<div>'+description+'</div></li>'
		+'<hr></hr>';	
		if(resultStatus == 'passed'){
			this.passedSpec++;
			specResult = specResult.replace("SpecResultBcColor" , "#72B072");
			specResult = specResult.replace("imagePlaceHolder" , "");
		}
		if(resultStatus == 'failed' && (specName.indexOf('@warn') > -1) ){
			this.passedSpec++;
			takeScreenshot(this.suite+'@warn');
			specResult = specResult.replace("SpecResultBcColor" , "#f0ad4e");
			specResult = specResult.replace("imagePlaceHolder" , '<a href="'+imagePathWarn+'"><img src="'+imagePathWarn+'" height="200" width="300"></img></a>');
		}
		if(resultStatus == 'failed' &&  (specName.indexOf('@warn') == -1) ){	
			takeScreenshot(this.suite);	
			this.failedSpecs++;	
			this.failedSuites++;
			this.isSuiteFailed = true;		
			specResult = specResult.replace("SpecResultBcColor" , "#C05350");
			specResult = specResult.replace("imagePlaceHolder" , '<a href="'+imagePath+'"><img src="'+imagePath+'" height="200" width="300"></img></a>');
			// element(by.id('errorPopup')).isDisplayed().then(function(result) {
			// 	if ( result ) {
			// 		element(by.css('#errorPopup > div.btn-group.btn-group-sm.pull-right > button')).click().then(function(){
			// 		});
			// 	}
			// });
		}
		if(resultStatus == 'disabled'){
			this.disabledSpecs++;
			specResult = specResult.replace("SpecResultBcColor" , "#adadad");
			specResult = specResult.replace("imagePlaceHolder" , "");
		}

		this.data = this.data+specResult;
		// console.log('this.data in addSpecResult'+this.data);
	};
	fileWritter.prototype.closeBodyWithSuite = function(result) {
		if(this.isSuiteFailed){
			this.data = this.data.replace("SuiteResultBcColor" , "#C05350");
		}else{
			this.data = this.data.replace("SuiteResultBcColor" , "#72B072");
		}
		this.data = this.data.replace("passedSpecInSuite" , this.passedSpec);
		this.data = this.data.replace("FailedSpecInSuite" , this.failedSpecs);
		this.data = this.data.replace("DisabledSpecInSuite" , this.disabledSpecs);
		this.data = this.data.replace("SuiteExecutionTime" , this.SuiteExecutionTime);
		this.data = this.data.replace("SpecsInSuite" , this.passedSpec+this.failedSpecs+this.disabledSpecs);
		var suffixSuite = '</ul>'
		+'</div>'
		+'</div>';
		this.data = this.data+suffixSuite;
		// console.log('this.data in closeBodyWithSuite'+this.data);
	};
	fileWritter.prototype.closeHTML = function() {
		
		// this.data = this.data.replace('TotalTestCases' , this.totalSuites);
		this.data = this.data.replace('FailedTestCases',this.failedSuites);
		this.data = this.data.replace('PassedTestCases',this.totalSuites -this.failedSuites);
		
		var suffixHTML =  '</body>'
		+'</html>';
		this.data = this.data+suffixHTML;
		// console.log('this.data in closeHTML'+this.data);
	};

	var takeScreenshot = function(specEndedAt) {
		var pathToSave = "functionalReports/reports_screenshots/";
		var imageName = specEndedAt+".png"
		browser.takeScreenshot().then(function(png){
			var stream = fs.createWriteStream(pathToSave+imageName);
			stream.write(new Buffer(png, 'base64'));
			stream.end();
		});
	}

/*var takeScreenshot = function(specEndedAt) {
	var pathToSave = "functionalReports/reports_screenshots/";
	var imageName = specEndedAt+".jpg"
	screenshot(pathToSave+imageName, {width: 900, height: 700, quality: 100}, function(error, complete) {
		if(error){
			console.log(error);
		}
		else{
			// suceess...
			console.log(complete);
		}});
	}*/
	fileWritter.prototype.writeFile = function() {
	fs.writeFileSync(this.path+"/"+this.suite+".html", this.data);
	/* , function(err) {
		if(err) {
			console.log(err);
		}
		else{
			console.log("file saved///////////////////");
		}
	});*/ 
};
	
	module.exports = fileWritter