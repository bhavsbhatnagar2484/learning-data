'use strict';
var fs = require('fs');
var htmlReporter = function(){
	this.completeData = [];
	this.fileList = [];
	this.totalSuites=0;
	this.failedTotalSuites=0;
	this.passedTotalSuites=0;
	this.templateReport = '<html>'
	+'<head>'
	+'<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>'
	+'</head>'
	+'<body>'
	+'<div class="ConsolidateResult">'
	+'<span><b>Total Test Cases</b> : <b>TotalTestCases</b></span>'
	+'<span><b>Passed Test Cases</b> : <b>PassedTestCases</b></span>'
	+'<span><b>Failed Test Cases</b> : <b>FailedTestCases</b></span>'
	+'placeholder'
	+'</body>'
	+'additionalCSS'
	+'</html>';	
};
	
htmlReporter.prototype.readDatafromFile = function() {
	var self = this;
	//console.log('Inside readDatafromFile');
	//console.log('fs:::'+fs);
	var files = fs.readdirSync('functionalReports/Reports');
	this.fileList = files;
	self.totalSuites = files.length;
	//console.log('Inside readdir'+this.fileList);
	//console.log('self.totalSuites'+self.totalSuites);
	/* this.fileList.forEach(function(currentValue,index,array){
		console.log('index::'+index);
		var passedSuite=0;
		var failedSuite=0;
		console.log('Inside Foreach::currentValue:::'+currentValue);
		var currentBodyData = "";
		var currentHeadData = "";
		var data = fs.readFileSync('../../functionalReports/Reports/'+currentValue);
		// console.log('current value::'+currentValue+'::: data::::'+data);
		currentBodyData = data.toString().split('<body>')[1].split('</body>')[0];
		currentHeadData = data.toString().split('<head>')[1].split('</head>')[0];
		passedSuite = Number(currentHeadData.toString().split('<passedcases>')[1].split('</passedcases>')[0]);
		failedSuite = Number(currentHeadData.toString().split('<failedcases>')[1].split('</failedcases>')[0]);
		self.failedTotalSuites += failedSuite;
		self.passedTotalSuites += passedSuite;
		self.completeData.push(currentBodyData);
	}) */
	for(var index = 0; index < self.totalSuites; index++){
		//console.log('index::'+index);
		var passedSuite=0;
		var failedSuite=0;
		//console.log('Inside For::currentValue:::'+this.fileList[index]);
		var currentBodyData = "";
		var currentHeadData = "";
		var data = fs.readFileSync('functionalReports/Reports/'+this.fileList[index]);
		currentBodyData = data.toString().split('<body>')[1].split('</body>')[0];
		currentHeadData = data.toString().split('<head>')[1].split('</head>')[0];
		passedSuite = Number(currentHeadData.toString().split('<passedcases>')[1].split('</passedcases>')[0]);
		failedSuite = Number(currentHeadData.toString().split('<failedcases>')[1].split('</failedcases>')[0]);
		self.failedTotalSuites += failedSuite;
		self.passedTotalSuites += passedSuite;
		self.completeData.push(currentBodyData);
	}
};

htmlReporter.prototype.createHTML = function() {
	this.templateReport = this.templateReport.replace("TotalTestCases" , this.totalSuites);
	this.templateReport = this.templateReport.replace("PassedTestCases" , this.passedTotalSuites);
	this.templateReport = this.templateReport.replace("FailedTestCases" , this.failedTotalSuites);
	this.templateReport = this.templateReport.replace("placeholder" , this.completeData);
	var additionalCSS =  '<style type="text/css">'
		+'.suiteName{'
		+'font-size: 20px;'
		+'}'
		+'.container {'
		+'width:100%;'
		+'border:1px solid #d3d3d3;'
		+'padding-bottom: 10px;'
		+'}'
		+'.container div {'
		+'width:100%;'
		+'}'
		+'.container .header {'
		+'background-color:#d3d3d3;'
		+'padding: 2px;'
		+'cursor: pointer;'
		+'font-weight: bold;'
		+'}'
		+'.container .content {'
		+'display: none;'
		+'padding : 5px;'
		+'}'
		+'.ConsolidateResult{'
		+'background-color : #5bc0de;'
		+'color : white;'
		+'padding-top : 10px;'
		+'padding-bottom : 10px;'
		+'}'
		+'.ConsolidateResult span{'
		+'padding-right : 24%'
		+'}'
		+'</style>'
		+'<head>'
		+'<script type="text/javascript">'
		+'$(".header").click(function () {'
		+'$header = $(this);'
		+'$content = $header.next();'
		+'$content.slideToggle(500, function () {'
		+'});'
		+'});'
		+'</script>'
		+'</head>';
	this.templateReport = this.templateReport.replace("additionalCSS" , additionalCSS);
};	

htmlReporter.prototype.writeFile = function() {
	fs.writeFileSync('functionalReports/Reporter.html', this.templateReport);
	//console.log("file saved///////////////////");
	/* , function(err) {
		if(err) {
			console.log(err);
		}
		else{
			console.log("file saved///////////////////");
		}
	});  */
};

htmlReporter.prototype.deleteFiles = function() {
	var self = this;
	for(var index = 0; index < self.totalSuites; index++){
		fs.unlinkSync('functionalReports/Reports/'+this.fileList[index]);
	}
		
	/* , function(err) {
		if(err) {
			console.log(err);
		}
		else{
			console.log("file saved///////////////////");
		}
	});  */
};

module.exports = htmlReporter;