
import { ElementFinder, browser, by, element, protractor } from 'protractor';
import { CsvProcessor } from './CsvProcessor';
import { LoginPage } from './Pages/LoginPage';
import { SearchPage } from './Pages/SearchPage';
import { CreateClientInfoPage } from './Pages/CreateClientInfoPage';
import { CreateAddressInfoPage } from './Pages/CreateAddressInfoPage';
import { ClientSummaryClientInfoPage } from './Pages/ClientSummaryClientInfoPage';
import { ClientSummaryQuestionsPage } from './Pages/ClientSummaryQuestionsPage';
import { ListAddressPage } from './Pages/ListAddressPage';
import { ListDependentPage } from './Pages/ListDependentPage';
import { concat } from 'rxjs/observable/concat';



export class Application {

app: object;
wait: number;
csvProcessor: CsvProcessor;
url: string;
EC: object;
currentEnv: string;
scriptName: string;
specdata: object;


loginPage: LoginPage;
searchPage: SearchPage;
createClientInfoPage: CreateClientInfoPage;
createAddressInfoPage: CreateAddressInfoPage;
clientSummaryClientInfoPage: ClientSummaryClientInfoPage;
clientSummaryQuestionsPage: ClientSummaryQuestionsPage;
listAddressPage: ListAddressPage;
listDependentPage: ListDependentPage;

constructor(scriptName: string) {
    console.log('do Something here ....');
    this.url = browser.params.Url;
    this.currentEnv = browser.params.env;
    this.csvProcessor = new CsvProcessor();
    this.initTestData('./e2e/dataRepo/' + this.currentEnv + '/ClientReferenceApplication.csv', scriptName);

    this.wait = browser.params.wait;
    this.EC = protractor.ExpectedConditions;
    this.specdata = {};
    this.searchPage = new SearchPage();
    this.loginPage = new LoginPage();
    this.createClientInfoPage = new CreateClientInfoPage();
    this.createAddressInfoPage = new CreateAddressInfoPage();
    this.clientSummaryClientInfoPage = new ClientSummaryClientInfoPage();
    this.clientSummaryQuestionsPage = new ClientSummaryQuestionsPage();
    this.listAddressPage = new ListAddressPage();
    this.listDependentPage = new ListDependentPage();
    
}

initTestData(file: string, testCaseName: string): void {
    const self = this;
    self.csvProcessor.initialize(file, testCaseName);
    self.csvProcessor.readDatafromFile(function (data) {
    self.csvProcessor.initData(data);
  });
};

showDate(): void { }

launchURL(): void {
    browser.driver.manage().window().maximize();
    browser.get(this.url);
    browser.waitForAngularEnabled(true);
    browser.sleep(4000);
};

getParam(criteria: any) {
    const self = this;
    const param = {};
    criteria.forEach(function(item){
 
    const value = self.csvProcessor.filterData(item);
    param[item] = value;
    console.log( '^^^^^^' + value);
 });
    return param;
 };

 clientSearchByParams(param: any) {
    browser.sleep(8000);
   // element(by.xpath('//*[@id="toggle-1"]/div/div[1]/div/div/div')).click();
  
     for (let key in param) {
        browser.sleep(2000);
         switch (key) {
            
             case ('FirstName'):
             this.searchPage.firstNameSearchField().sendKeys(param[key]);
             break;
 
             case ('MiddleName'):
             this.searchPage.middleNameSearchField().sendKeys(param[key]);
             break;
 
             case ('LastName'):
             this.searchPage.lastNameSearchField().sendKeys(param[key]);
             break;
             
            //  case ('Gender'):
            //  this.searchPage.genderSearchOption().sendKeys(param[key]);
            //  break;
 
             case ('DateOfBirth'):
             this.searchPage.dateOfBirthSearchField().click();
             console.log("clciked++")
             this.searchPage.dateOfBirthSearchField().sendKeys(param[key]);
             break;
 
             case ('Email'):
             this.searchPage.emailSearchField().sendKeys(param[key]);
             break;

          
         }   
         browser.sleep(1000);
     }
 };

// ----------------------   LOGIN PAGE  -----------------------------------------

loginApplication() {
    const self = this;
    const userName = self.csvProcessor.filterData('UserName');		
    const password = self.csvProcessor.filterData('Password');
   
    this.loginPage.userNameField().sendKeys(userName);
    this.loginPage.passwordField().sendKeys(password);

    this.loginPage.loginButton().click();
    browser.waitForAngularEnabled(true);
};

logoutIcon() {
  const self =  this;
  const clickLogoutIcon = this.loginPage.logoutIcon();
  browser.wait(protractor.ExpectedConditions.presenceOf(clickLogoutIcon), this.wait)
  .then(function() {
    clickLogoutIcon.click();
  });
};

logoutButton() {
    const self = this;
    const clickLogoutIcon = this.loginPage.logoutButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(clickLogoutIcon), this.wait)
    .then(function() {
      clickLogoutIcon.click();
    });
  };

  //--------------- Select Language --------------
  selectLanguage() {
    const self =  this;
    const icon = this.searchPage.personIcon();
    const arabic = this.searchPage.arabic();
    browser.wait(protractor.ExpectedConditions.presenceOf(icon), this.wait)
    .then(function() {
        icon.click();
        arabic.click();
        browser.sleep(6000);
    });
  };

// -----------------  CREATE CLIENT FUNCTIONS   --------------------------------------- 

// -----------    Fill Client Information  --------
 fillClientInformation(){
    const self = this;	
    const FirstName  = self.csvProcessor.filterData('FirstName');
    const MiddleName = self.csvProcessor.filterData('MiddleName');
    const LastName = self.csvProcessor.filterData('LastName');
    const Gender = self.csvProcessor.filterData('Gender');
    const DateOfBirth = self.csvProcessor.filterData('DateOfBirth');
    const Email = self.csvProcessor.filterData('Email');
   console.log(FirstName);
// // Create Base64 Object
// const Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
// encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);
// while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);
// s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}
// else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},
// decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=this._keyStr.indexOf(e.charAt(f++));
// o=this._keyStr.indexOf(e.charAt(f++));u=this._keyStr.indexOf(e.charAt(f++));a=this._keyStr.indexOf(e.charAt(f++));n=s<<2|o>>4;
// r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=Base64._utf8_decode(t);return t},
// _utf8_encode:function(e){e=e.replace(/rn/g,"n");var t="";for(var n=0;n<e.length;n++)
// {var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}
// else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t},_utf8_decode:function(e)
// {var t="";var n=0;var c1; var c2; var c3; var r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224)
// {c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}
// else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);
// t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}}

// // Define the string
// console.log(FirstName);
// const string = FirstName;

// // Encode the String
// const encodedString = Base64.encode(string);
// console.log('>>>>>'+encodedString); // Outputs: "SGVsbG8gV29ybGQh"

// // Decode the String
// const decodedString = Base64.decode(encodedString);
// console.log('>>>>>'+decodedString); // Outputs: "Hello World!"


    const firstNameField = this.createClientInfoPage.firstNameField();
    browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(firstNameField), this.wait)
    .then(function() {
        firstNameField.click();
    });

    if (Gender === "female") {
        console.log('female>>>>>>>>>>>>>>>>>>>>>')
         self.createClientInfoPage.femaleGenderOption().click();
    }
    else{
     console.log('male>>>>>>>>>>>>>>>>>>>>>')
     self.createClientInfoPage.maleGenderOption().click();
    }
     
    this.createClientInfoPage.firstNameField().sendKeys(FirstName);
    // browser.sleep(2000);
    this.createClientInfoPage.middleNameField().sendKeys(MiddleName);
    // browser.sleep(2000);
   
    this.createClientInfoPage.lastNameField().sendKeys(LastName);
    // browser.sleep(2000);
    this.createClientInfoPage.emailField().sendKeys(Email);
    // browser.sleep(2000);
    this.createClientInfoPage.dateOfBirthField().sendKeys(DateOfBirth);
    // browser.sleep(2000);
 
    this.createClientInfoPage.firstNameField().click();
    // browser.sleep(8000);

    // browser.sleep(9000);
    // browser.waitForAngularEnabled(true);
};

// -----------    Fill Address Information  --------

fillAddressInformation(){
    const self = this;	
    const AddressLine1 = self.csvProcessor.filterData('AddressLine1');
    const AddressLine2 = self.csvProcessor.filterData('AddressLine2');
    const City = self.csvProcessor.filterData('City');
    const State = self.csvProcessor.filterData('State');
    const PostalCode = self.csvProcessor.filterData('PostalCode');
    const Country = self.csvProcessor.filterData('Country');
    const AddressType = self.csvProcessor.filterData('AddressType');

    const addressLine1Field = this.createAddressInfoPage.addressLine1Field();
    // browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(addressLine1Field), this.wait)
    .then(function() {
        addressLine1Field.click();
    });
    addressLine1Field.sendKeys(AddressLine1);
    this.createAddressInfoPage.addressLine2Field().sendKeys(AddressLine2);
    this.createAddressInfoPage.cityField().sendKeys(City);
    this.createAddressInfoPage.stateField().sendKeys(State);
    this.createAddressInfoPage.postalCodeField().sendKeys(PostalCode);
    this.createAddressInfoPage.countryField().sendKeys(Country);

    if (AddressType === 'Primary') {
        this.createAddressInfoPage.addressDropDown().click();
        this.createAddressInfoPage.addressTypePrimary().click();
    }
    else {
        this.createAddressInfoPage.addressTypeSecondary().click();
    }
    //browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

// -----------------  CLIENT SUMMARY FUNCTIONS -------------------------------------- 

  // -----------    Update Client Information  --------

  updateClientInfoDetails(){
    const self = this;	
    const FirstName = self.csvProcessor.filterData('edit_FirstName');
    const MiddleName = self.csvProcessor.filterData('edit_MiddleName');
    const LastName = self.csvProcessor.filterData('edit_LastName');
    const Gender = self.csvProcessor.filterData('edit_Gender');
    const DateOfBirth = self.csvProcessor.filterData('edit_DateOfBirth');
    const Email = self.csvProcessor.filterData('edit_Email');

    const editFirstNameField = this.clientSummaryClientInfoPage.editFirstNameField();
    browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(editFirstNameField), this.wait)
    .then(function() {
        editFirstNameField.clear();
    });
    this.clientSummaryClientInfoPage.editFirstNameField().sendKeys(FirstName);

    this.clientSummaryClientInfoPage.editMiddleNameField().clear();
    this.clientSummaryClientInfoPage.editMiddleNameField().sendKeys(MiddleName);

    this.clientSummaryClientInfoPage.editLastNameField().clear();
    this.clientSummaryClientInfoPage.editLastNameField().sendKeys(LastName);

    this.clientSummaryClientInfoPage.editDateOfBirthField().clear();
    this.clientSummaryClientInfoPage.editDateOfBirthField().sendKeys(DateOfBirth);

    this.clientSummaryClientInfoPage.editEmailField().clear();
    this.clientSummaryClientInfoPage.editEmailField().sendKeys(Email);

   // if (Gender === 'female') {
        this.clientSummaryClientInfoPage.editGenderOption().click();
   // }
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

  // -----------    Verify Client Information  --------

  verifyClientInfoDetails(){
    const self = this;	
    const FirstName = self.csvProcessor.filterData('FirstName');
    const MiddleName = self.csvProcessor.filterData('MiddleName');
    const LastName = self.csvProcessor.filterData('LastName');
    const Gender = self.csvProcessor.filterData('Gender');
    const DateOfBirth = self.csvProcessor.filterData('DateOfBirth');
    const Email = self.csvProcessor.filterData('Email');

    const editFirstNameField = this.clientSummaryClientInfoPage.editFirstNameField();
    browser.sleep(4000);
   // browser.wait(protractor.ExpectedConditions.presenceOf(editFirstNameField), this.wait)
   // .then(function() {
       // expect(editFirstNameField.getAttribute('value')).toContain(FirstName);
    //});
     expect( this.clientSummaryClientInfoPage.editFirstNameField().getAttribute('value')).toContain(FirstName);
    expect( this.clientSummaryClientInfoPage.editMiddleNameField().getAttribute('value')).toContain(MiddleName);
    expect( this.clientSummaryClientInfoPage.editLastNameField().getAttribute('value')).toContain(LastName);
    expect( this.clientSummaryClientInfoPage.editDateOfBirthField().getAttribute('value')).toContain(DateOfBirth);
    expect( this.clientSummaryClientInfoPage.editEmailField().getAttribute('value')).toContain(Email);

    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

  // -----------    Update Client Questions  --------

  updateClientQuestions(){
    const self = this;	
    const Smoke = self.csvProcessor.filterData('Smoke');
    const SmokingYears = self.csvProcessor.filterData('SmokingYears');
    const SameNationality = self.csvProcessor.filterData('SameNationality');
    const HazardousActivity = self.csvProcessor.filterData('HazardousActivity');
   
    browser.sleep(4000);
 //   Smoking Question YES/NO
    if (Smoke === 'yes') { 
       // Enter no. of years
        console.log('yes')
        this.clientSummaryQuestionsPage.smokeYes().click(); 
        this.clientSummaryQuestionsPage.smokingYearsField().clear();
        this.clientSummaryQuestionsPage.smokingYearsField().sendKeys(SmokingYears);
    }
     else {
        this.clientSummaryQuestionsPage.smokeNo().click();
    }
   
    // Hazardous Activity selection 
    this.clientSummaryQuestionsPage.hazardousActivity().click();
    if (HazardousActivity === 'SkyDiving') {
        this.clientSummaryQuestionsPage.hazardousActivitySkyDiving().click();
    }else if (HazardousActivity === 'ScobaDiving')  {
         this.clientSummaryQuestionsPage.hazardousActivityScobaDiving().click();
    }else {
        this.clientSummaryQuestionsPage.hazardousActivityBunjiJumping().click();
    }
    
    // this.clientSummaryQuestionsPage.sameNationalityeField().clear();
    // this.clientSummaryQuestionsPage.sameNationalityeField().sendKeys(SameNationality);
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};



  // -----------    Address List Operations  --------

  addAddressInfoDetails(){
    const self = this;	
    const AddressLine1 = self.csvProcessor.filterData('add_AddressLine1');
    const AddressLine2 = self.csvProcessor.filterData('add_AddressLine2');
    const City = self.csvProcessor.filterData('add_City');
    const State = self.csvProcessor.filterData('add_State');
    const PostalCode = self.csvProcessor.filterData('add_PostalCode');
    const Country = self.csvProcessor.filterData('add_Country');
    const AddressType = self.csvProcessor.filterData('add_AddressType');

    const addAddressLine1Field = this.listAddressPage.addAddressLine1Field();
    console.log("AddressLine1");
     browser.sleep(6000);
    browser.wait(protractor.ExpectedConditions.presenceOf(addAddressLine1Field), this.wait)
    .then(function() {

        addAddressLine1Field.click();
    });
    addAddressLine1Field.sendKeys(AddressLine1);
    this.listAddressPage.addAddressLine2Field().sendKeys(AddressLine2);
    this.listAddressPage.addCityField().sendKeys(City);
    this.listAddressPage.addStateField().sendKeys(State);
    this.listAddressPage.addPostalCodeField().sendKeys(PostalCode);
    this.listAddressPage.addCountryField().sendKeys(Country);
    browser.sleep(9000);
    if (AddressType === 'Primary') {
        this.createAddressInfoPage.addressDropDown().click();
        browser.sleep(2000);
        this.createAddressInfoPage.addressTypePrimary().click();
    }
    else {
        this.createAddressInfoPage.addressDropDown().click();
        browser.sleep(2000);
        this.createAddressInfoPage.addressTypeSecondary().click();
    }
    browser.waitForAngularEnabled(true);
    // addressTypeOption('Type': value).click();
 }

 updateExistingAddress(){
    const self = this;	
    const AddressLine1 = self.csvProcessor.filterData('edit_AddressLine1');
    const AddressLine2 = self.csvProcessor.filterData('edit_AddressLine2');
    const City = self.csvProcessor.filterData('edit_City');
    const State = self.csvProcessor.filterData('edit_State');
    const PostalCode = self.csvProcessor.filterData('edit_PostalCode');
    const Country = self.csvProcessor.filterData('edit_Country');
    const AddressType = self.csvProcessor.filterData('edit_AddressType');

    const addressLine1Field = this.listAddressPage.addressLine1Field();
    // browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(addressLine1Field), this.wait)
    .then(function() {
        addressLine1Field.clear();
    });
    addressLine1Field.sendKeys(AddressLine1);

    this.listAddressPage.addressLine2Field().clear();
    this.listAddressPage.addressLine2Field().sendKeys(AddressLine2);

    this.listAddressPage.cityField().clear();
    this.listAddressPage.cityField().sendKeys(City);

    this.listAddressPage.stateField().clear();
    this.listAddressPage.stateField().sendKeys(State);

    this.listAddressPage.postalCodeField().clear();
    this.listAddressPage.postalCodeField().sendKeys(PostalCode);

    this.listAddressPage.countryField().clear();
    this.listAddressPage.countryField().sendKeys(Country);

    // addressTypeOption('Type': value).click();
    
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
 }

 // --------------------- Verify Address Details ----------------------- 

 verifyAddressDetails(){
    const self = this;	
    const AddressLine1 = self.csvProcessor.filterData('AddressLine1');
    const AddressLine2 = self.csvProcessor.filterData('AddressLine2');
    const City = self.csvProcessor.filterData('City');
    const State = self.csvProcessor.filterData('State');
    const PostalCode = self.csvProcessor.filterData('PostalCode');
    const Country = self.csvProcessor.filterData('Country');
    const AddressType = self.csvProcessor.filterData('AddressType');

    const addressLine1Field = this.listAddressPage.addressLine1Field();
    browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(addressLine1Field), this.wait)
    .then(function() {
        expect(addressLine1Field.getAttribute('value')).toContain(AddressLine1);
        
    });
 
    expect(this.listAddressPage.addressLine2Field().getAttribute('value')).toContain(AddressLine2);
    expect(this.listAddressPage.cityField().getAttribute('value')).toContain(City);
    expect(this.listAddressPage.stateField().getAttribute('value')).toContain(State);
    expect(this.listAddressPage.postalCodeField().getAttribute('value')).toContain(PostalCode);
    expect(this.listAddressPage.countryField().getAttribute('value')).toContain(Country);

    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
 }


 // -----------    Dependent List Operations  --------

 addDependentInfoDetails(){
    const self = this;	
    const DependentName = self.csvProcessor.filterData('add_dependentName');
    const Relation = self.csvProcessor.filterData('add_relation');
    const DependentType = self.csvProcessor.filterData('add_dependentType');
    const DependentDoB = self.csvProcessor.filterData('add_dependentDoB');
   // browser.sleep(4000);
  
   this.listDependentPage.addDependentNameField().sendKeys(DependentName);
   this.listDependentPage.addDependentDoB().sendKeys(DependentDoB);

   this.listDependentPage.addRelationDropdown().click();
   browser.sleep(3000);
   if (Relation === 'Spouse') {
       this.listDependentPage.relationTypeSpouse().click();
   } else if (Relation === 'Children'){
       this.listDependentPage.relationTypeChildren().click();
   }else {
       this.listDependentPage.relationTypeOther().click();
   }

   this.listDependentPage.addTypeDropdown().click();
   browser.sleep(3000);
   if (DependentType === 'Primary') {
      this.listDependentPage.dependentTypePrimary().click();
   }else {
       this.listDependentPage.dependentTypeSecondary().click();
   }

    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
 }
 

 
 addDependentInfoDetailsTwo(){
    const self = this;	
    const DependentName = self.csvProcessor.filterData('add_dependentNameTwo');
    const Relation = self.csvProcessor.filterData('add_relationTwo');
    // const DependentType = self.csvProcessor.filterData('add_dependentTypeTwo');
    const DependentDoB = self.csvProcessor.filterData('add_dependentDoBTwo');
     // browser.sleep(4000);

    this.listDependentPage.addDependentNameField().sendKeys(DependentName);
    this.listDependentPage.addDependentDoB().sendKeys(DependentDoB);

    this.listDependentPage.addRelationDropdown().click();
    // browser.sleep(3000);
    if (Relation === 'Spouse') {
        this.listDependentPage.relationTypeSpouse().click();
    } else if (Relation === 'Children'){
        this.listDependentPage.relationTypeChildren().click();
    }else {
        this.listDependentPage.relationTypeOther().click();
    }

    this.listDependentPage.addTypeDropdown().click();
    // if (DependentType === 'Primary') {
    //    this.listDependentPage.dependentTypePrimary().click();
    // }
    // \else {
        this.listDependentPage.dependentTypeSecondary().click();
    // }

    browser.sleep(4000);
    browser.waitForAngularEnabled(true);
 }

 updateExistingDependent(){
    const self = this;	
    const DependentName = self.csvProcessor.filterData('edit_dependentName');
    const Relation = self.csvProcessor.filterData('edit_relation');
    const DependentType = self.csvProcessor.filterData('edit_dependentType');
    const DependentDoB = self.csvProcessor.filterData('edit_dependentDoB');
    // browser.sleep(4000);
    this.listDependentPage.dependentNameField().clear();
    this.listDependentPage.dependentNameField().sendKeys(DependentName);

    this.listDependentPage.dependentDoB().clear();
    this.listDependentPage.dependentDoB().sendKeys(DependentDoB);

    this.listDependentPage.relationDropdown().click();
    // browser.sleep(3000);
    if (Relation === 'Spouse') {
        this.listDependentPage.relationTypeSpouse().click();
    } else if (Relation === 'Children'){
        this.listDependentPage.relationTypeChildren().click();
    }else {
        this.listDependentPage.relationTypeOther().click();
    }

    this.listDependentPage.typeDropdown().click();
    browser.sleep(3000);
    if (DependentType === 'Primary') {
       this.listDependentPage.dependentTypePrimary().click();
    }else {
        this.listDependentPage.dependentTypeSecondary().click();
    }

    browser.sleep(9000);
}

verifyDependentDetails(){
    const self = this;	
    const DependentName = self.csvProcessor.filterData('add_dependentName');
    const Relation = self.csvProcessor.filterData('add_relation');
    const DependentType = self.csvProcessor.filterData('add_dependentType');
    browser.waitForAngularEnabled(true);
 
    const DependentDoB = self.csvProcessor.filterData('add_dependentDoB');
  

    const dependentNameField = this.listDependentPage.dependentNameField();
    browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(dependentNameField), this.wait)
    .then(function() {
        expect(dependentNameField.getAttribute('value')).toContain(DependentName);
    });

    expect(this.listDependentPage.dependentDoB().getAttribute('value')).toContain(DependentDoB);
    // expect(this.listDependentPage.relationFieldOption().getAttribute('value')).toContain(Relation);
    // expect(this.listDependentPage.dependentTypeOption().getAttribute('value')).toContain(DependentType);
   
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
 }
  // --------------------------------- SEARCH PAGE BUTTONS----------------------------------


clickCreateButton():void{
    const self = this;
    const  createButton = this.searchPage.createButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(createButton), this.wait)
    .then(function() {
        createButton.click();
        browser.sleep(6000);
    });
  };  
 
  clickSearchButton():void{
    const self = this;
    const searchButton = this.searchPage.searchButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(searchButton), this.wait)
    .then(function() {
        searchButton.click();
        browser.sleep(5000);
    });
  };

  clickResetButton():void{
    const self = this;
    const resetButton = this.searchPage.resetButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(resetButton), this.wait)
    .then(function() {
        resetButton.click();
    });
  };

  clickEditButton():void{
    const self = this;
    const editButton = this.searchPage.editButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editButton), this.wait)
    .then(function() {
        editButton.click();
        browser.sleep(5000);
    });
  };

  clickClientSummaryButton():void{
    const self = this;
    const clientSummaryButton = this.clientSummaryClientInfoPage.clientSummaryButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(clientSummaryButton), this.wait)
    .then(function() {
        clientSummaryButton.click();
        browser.sleep(5000);
    });
  };
  
  
  clickDeleteClientButton():void{
    let self = this;
    const deleteButton = this.searchPage.deleteButton();
    const deleteClient = self.csvProcessor.filterData('deleteClient');
    const confirmDeleteButton = this.searchPage.confirmDeleteButton(); 
    const cancelDeleteButton = this.searchPage.cancelDeleteButton(); 
    
    browser.wait(protractor.ExpectedConditions.presenceOf(deleteButton), this.wait)
    .then(function() {
        deleteButton.click();
        console.log('inside if'+ deleteClient.trim()+'hhhh');
      

        if (deleteClient === 'yes')
        {
            console.log('inside if'+ deleteClient)
            browser.sleep(5000); 
            confirmDeleteButton.click();
        
      
        }
       else {
        browser.sleep(5000); 
         console.log('inside if'+ deleteClient)
          cancelDeleteButton.click();
        }
    });
};  


verifyNoClientFound(): void{
        expect(this.searchPage.deleteButton().isPresent()).toBe(false);
        console.log('Client deleted successfully ....');
    };	  

 


   // -------------------------- CREATE CLIENT BUTTONS --------------------------------
   
   clickAddressInfoButton():void{
    const self = this;
    const nextButton = this.createClientInfoPage.nextButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(nextButton), this.wait)
    .then(function() {
        nextButton.click();
    });
  };

  clickGoClientInfoButton():void{
    const self = this;
    const previousButton = this.createAddressInfoPage.previousButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(previousButton), this.wait)
    .then(function() {
        previousButton.click();
    });
  };
   
  clickStartOverButton():void{
    const self = this;
    const startOverButton = this.createAddressInfoPage.startOverButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(startOverButton), this.wait)
    .then(function() {
        startOverButton.click();
    });
}; 
   
    clickCancelButton():void{
        const self = this;
        const cancelButton = this.createAddressInfoPage.cancelButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(cancelButton), this.wait)
        .then(function() {
            cancelButton.click();
        });
    }; 
   
// --------------------------   CLIENT SUMMARY BUTTONS -----------------------------

     clickCloseButton():void{
        const self = this;
        const closeButton = this.clientSummaryClientInfoPage.closeButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(closeButton), this.wait)
        .then(function() {
            closeButton.click();
        });
    }; 
   
 //              -------------- CLIENT INFORMATION SECTION BUTTONS --------------

 clickEditClientInfoButton():void{
    const self = this;
    const editClientInfoButton = this.clientSummaryClientInfoPage.editClientInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editClientInfoButton), this.wait)
    .then(function() {
        editClientInfoButton.click();
    });
};

clickOkClientInfoButton():void{
    const self = this;
    const okClientInfoButton = this.clientSummaryClientInfoPage.okClientInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(okClientInfoButton), this.wait)
    .then(function() {
        okClientInfoButton.click();
    });
};

clickCloseClientInfoButton():void{
    const self = this;
    const closeClientInfoButton = this.clientSummaryClientInfoPage.closeClientInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(closeClientInfoButton), this.wait)
    .then(function() {
        closeClientInfoButton.click();
    });
};
   
//              -------------- CLIENT QUESTION SECTION BUTTONS --------------

clickEditClientQuestionsButton():void{
    const self = this;
    const editClientQuestionsButton = this.clientSummaryQuestionsPage.editClientQuestionsButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editClientQuestionsButton), this.wait)
    .then(function() {
        editClientQuestionsButton.click();
    });
};

clickOkClientQuestionsButton():void{
    const self = this;
    const OkClientQuestionsButton = self.clientSummaryQuestionsPage.OkClientQuestionsButton();
    // browser.wait(protractor.ExpectedConditions.presenceOf(OkClientQuestionsButton), this.wait)
    // .then(function() {
        OkClientQuestionsButton.click();
    // });
};

clickCloseQuestionsButton():void{
    const self = this;
    const closeClientQuestionsButton = this.clientSummaryQuestionsPage.closeClientQuestionsButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(closeClientQuestionsButton), this.wait)
    .then(function() {
        closeClientQuestionsButton.click();
    });
};
  
//               -------------- CLIENT ADDRESS SECTION BUTTONS --------------

clickAddressListButton():void{
    const self = this;
    const addressListButton = this.listAddressPage.addressListButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(addressListButton), this.wait)
    .then(function() {
        addressListButton.click();
    });
};

clickAddAddressInfoButton():void{
    const self = this;
    const addAddressInfoButton = this.listAddressPage.addAddressInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(addAddressInfoButton), this.wait)
    .then(function() {
        addAddressInfoButton.click();
    });
}

clickEditAddressButton():void{
    const self = this;
    const editClientAddressButton = this.listAddressPage.editClientAddressButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editClientAddressButton), this.wait)
    .then(function() {
        editClientAddressButton.click();
    });
}

clickAddAddressInfoOKButton():void{
    const self = this;
    const addOKAddressInfoButton = this.listAddressPage.addOKAddressInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(addOKAddressInfoButton), this.wait)
    .then(function() {
        addOKAddressInfoButton.click();
       });
}

clickEditAddressInfoOKButton():void{
    const self = this;
    const editOKAddressInfoButton = this.listAddressPage.editOKAddressInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editOKAddressInfoButton), this.wait)
    .then(function() {
        editOKAddressInfoButton.click();
    });
}

clickAddressInfoCloseButton():void{
    const self = this;
    const closeAddressInfoButton = this.listAddressPage.closeAddressInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(closeAddressInfoButton), this.wait)
    .then(function() {
        closeAddressInfoButton.click();
    });
}

clickEditListClientAddressButton(): void {
    const self = this; 
    const editListClientAddressButton = this.listAddressPage.editListClientAddressButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editListClientAddressButton), this.wait)
    .then(function() {
        editListClientAddressButton.click();
    });
}

clickDeleteAddressButton(): void {
    const self = this;
    const deleteAddressButton = this.listAddressPage.deleteAddressButton();
    const deleteAddress = self.csvProcessor.filterData('deleteAddress');
    const confirmDeleteButton = this.listAddressPage.confirmDeleteButton(); 
    const cancelDeleteButton = this.listAddressPage.cancelDeleteButton(); 
    browser.sleep(5000);
    browser.wait(protractor.ExpectedConditions.presenceOf(deleteAddressButton), this.wait)
    .then(function() {
        deleteAddressButton.click();
        console.log('inside if'+ deleteAddress.trim()+ 'hhhh');
        browser.sleep(3000); 

        if (deleteAddress === 'yes')
        {
            console.log('inside if'+ deleteAddress)
            //browser.sleep(5000); 
            confirmDeleteButton.click();
            console.log('inside if 1'+ deleteAddress)
           // browser.sleep(10000); 
         } else {
        browser.sleep(5000); 
         console.log('inside if'+ deleteAddress)
          cancelDeleteButton.click();
        }
    });
}

//               -------------- CLIENT DEPENDENT SECTION BUTTONS --------------

clickDependentListButton(): void {
    const self = this;
    const dependentListButton = this.listDependentPage.dependentListButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(dependentListButton), this.wait)
    .then(function() {
        dependentListButton.click();
    });
}

clickAddDependentInfoButton():void{
    const self = this;
    const addDependentInfoButton = this.listDependentPage.addDependentInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(addDependentInfoButton), this.wait)
    .then(function() {
        addDependentInfoButton.click();
    });
}

clickEditDependentButton():void{
    const self = this;
    const editDependentButton = this.listDependentPage.editDependentButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editDependentButton), this.wait)
    .then(function() {
        editDependentButton.click();
        browser.sleep(3000);
    });
}

clickAddDependentInfoOKButton():void{
    const self = this;
    const addOKDependentInfoButton = this.listDependentPage.addOKDependentInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(addOKDependentInfoButton), this.wait)
    .then(function() {
        addOKDependentInfoButton.click();
    });
}


clickEditDependentInfoOKButton():void{
    const self = this;
    const editOKDependentInfoButton = this.listDependentPage.editOKDependentInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editOKDependentInfoButton), this.wait)
    .then(function() {
        editOKDependentInfoButton.click();
    });
}

clickCloseDependentInfoButton():void{
    const self = this;
    const closeDependentInfoButton = this.listDependentPage.closeDependentInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(closeDependentInfoButton), this.wait)
    .then(function() {
        closeDependentInfoButton.click();
    });
}

clickEditListDependentButton(): void {
    const self = this; 
    const editListDependentButton = this.listDependentPage.editListDependentButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editListDependentButton), this.wait)
    .then(function() {
        editListDependentButton.click();
    });
}

clickDeleteDependentButton():void{
    const self = this;
    const deleteDependentButton = this.listDependentPage.deleteDependentButton();
    const deleteDependent = self.csvProcessor.filterData('deleteDependent');
    const confirmDeleteButton = this.listDependentPage.confirmDeleteButton(); 
    const cancelDeleteButton = this.listDependentPage.cancelDeleteButton(); 
   
   browser.wait(protractor.ExpectedConditions.presenceOf(deleteDependentButton), this.wait)
   .then(function() {
        deleteDependentButton.click();
        console.log( 'inside if' + deleteDependent.trim() + 'hhhh');
      

        if (deleteDependent === 'yes')
        {   
            const abc= element.all(by.id('confirm_dialog__ok'));
            console.log("total element"+abc.count());
            console.log( 'inside if' + deleteDependent)
            browser.sleep(5000); 
       
      
          confirmDeleteButton.click();
          console.log('inside if 1'+ deleteDependent)
          browser.sleep(10000); 
         }
        else {
        browser.sleep(5000); 
         console.log('inside if'+ deleteDependent)
          cancelDeleteButton.click();
        }
    });
}


   

};
  



