'use strict';
var fileWritter = require('./fileWritter');
var htmlReporter = require('./htmlReporter');
var csvProcessor = require('./CSV_Processor');
var jasminePtorFailfast = function(){		
	this.FailedSpecName="";
	this.currentSuiteName="";
	// Global Variabales for Performance - Start
	this.time1=0;
	this.time2=0;
	// For Writing File 
	this.perfMetric;
	this.headers;
	// Global Variabales for Performance End
};

var getLob = function(scriptName){
	var partialLob = scriptName.split('_')[1];
	var exactLob='';
	switch(partialLob){
		case 'DV001' : exactLob = 'Investment'; break;
		case 'SR001a': exactLob = 'Savings';break;
		case 'IP001a': exactLob = 'IPT';break;
		case 'VA001a': exactLob = 'VAP';break;
	}
	return exactLob;
}

jasminePtorFailfast.prototype.launch = function() {
	var self = this;
	var htmlreporter = new htmlReporter();
	var specRefs = getSpecReferences();
	var reportWritter = new fileWritter();
	var perfWritter = new csvProcessor();
	
	return {
		jasmineStarted: function jasmineStarted(suiteInfo) {
			reportWritter.startHTML(suiteInfo);
		},		
		suiteStarted: function suiteStarted(result) {			
			self.currentSuiteName = result.fullName;			
			reportWritter.startBodyWithSuite(self.currentSuiteName);
			browser.actions().sendKeys(protractor.Key.chord(protractor.Key.CONTROL, protractor.Key.F5)).perform();
				perfWritter.initialize('functional/Perf/'+ getLob(self.currentSuiteName) +'/'+ self.currentSuiteName +'.csv','');
				perfWritter.readDatafromFile(function(data){      
					self.perfMetric = data ; 
				});
				perfWritter.getHeaderArray(function(data){      
					self.headers = data ;
				});
		},
		specStarted: function specStarted(result) {
			reportWritter.startSpec();
			self.time1 = (new Date()).getTime();
		},
		specDone: function specDone(result) {	
			var message;
			var description;
			var isWarning = (result.fullName.indexOf('@warn') > -1 ? true : false);	
			if(result.status == 'failed' && !isWarning){
				disableSpec(self.currentSuiteName,specRefs.specs)
				message = result.failedExpectations[0].message ;
				description = result.failedExpectations[0]. stack ;
			}
			reportWritter.addSpecResult(result.fullName,result.status,message,description);
				self.time2 = (new Date()).getTime();
				var captureTime =  (self.time2 - self.time1)/1000;   
				var param = {};
				param.currentSpec = result.fullName.split(self.currentSuiteName+'#')[1];
				param.captureTime = captureTime;
				param.headers = self.headers;
				param.perfMetric = self.perfMetric;
				self.perfMetric = perfWritter.buildPerfMetrics(param);
		},
		suiteDone: function suiteDone(result) {
			reportWritter.closeBodyWithSuite(result);
			perfWritter.writeData(self.perfMetric);
		},
		jasmineDone: function jasmineDone() {
			reportWritter.closeHTML();
			reportWritter.writeFile();		
		}
	};
};
function getSpecReferences() {
	var specs = [];
	jasmine.getEnv().specFilter = function (spec) {
		specs.push(spec);
		return true;
	};
	return{
		specs : specs
	}
}
function disableSpec(suiteName,specs) {	
	specs.forEach(function(item){
		if(item. description.indexOf(suiteName) > -1){
			item.disable();
		}
	});
}

module.exports  = jasminePtorFailfast;