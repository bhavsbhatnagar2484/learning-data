

import {element, ElementFinder, by} from 'protractor';

export class ClientSummaryQuestionsPage {

// Client Questions Section


smokeYes() { return element(by.id('answer_true'))}
smokeNo() { return element(by.id('answer_false'))} 
smokingYearsField() { return element.all(by.id('answer')).get(3)}

sameNationalityeField() { return element(by.id('question-3-undefined'))}

hazardousActivity() { return element.all(by.id('answer')).get(1)}
hazardousActivitySkyDiving() { return element(by.id('answer_0'))}
hazardousActivityScobaDiving()  { return element(by.id('answer_1'))}
hazardousActivityBunjiJumping() { return element(by.id('answer_2'))}

 // Buttons
 editClientQuestionsButton() { return element(by.id('questions-undefined'))}

 OkClientQuestionsButton() { return element(by.id('modal__ok'))}
 closeClientQuestionsButton() { return element(by.id('modal__close'))}



}