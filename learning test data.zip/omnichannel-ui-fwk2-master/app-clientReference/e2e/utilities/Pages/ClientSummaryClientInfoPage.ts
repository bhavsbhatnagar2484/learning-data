

import {element, ElementFinder, by} from 'protractor';

export class ClientSummaryClientInfoPage {

 // Client Information Section
 editFirstNameField() { return element(by.id('edit-personal-first-name'))}
 editMiddleNameField() { return element(by.id('edit-personal-middle-name'))}
 editLastNameField() { return element(by.id('edit-personal-last-name'))}
 editGenderOption() { return element(by.id('edit-personal-gender_Female'))}
//  editGenderOption() { return element(by.id('edit-personal-gender_MALE'))}
 editDateOfBirthField() { return element(by.id('edit-personal-date-of-birth_input'))}
 // editDateOfBirthField() { return element(by.id('editPersonal_personal_birthDate'))}
 editEmailField() { return element(by.id('edit-personal-email'))}

 // Buttons
 editClientInfoButton() { return element(by.id('edit-personal-undefined'))}

 // okClientInfoButton() { return element(by.css('[class^="btn btn-primary okButtonModal"]'))}
 okClientInfoButton() { return element(by.id('modal__ok'))}
 closeClientInfoButton() { return element(by.id('modal__cross'))}
 
 closeButton() { return element(by.id('home-screen'))}
 clientSummaryButton() { return element(by.id('client-summary-screen'))}
 
}