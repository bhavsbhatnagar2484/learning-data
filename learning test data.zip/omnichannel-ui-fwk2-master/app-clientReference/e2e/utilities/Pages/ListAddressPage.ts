

import {element, ElementFinder, by} from 'protractor';

export class ListAddressPage {

 // Edit Address Detail
 addressLine1Field() { return element(by.id('current-edit-address-address-line-1'))}
 addressLine2Field() { return element(by.id('current-edit-address-address-line-2'))}
 cityField() { return element(by.id('current-edit-address-city'))}
 stateField() { return element(by.id('current-edit-address-state'))}
 postalCodeField() { return element(by.id('current-edit-address-postal-code'))}
 countryField() { return element(by.id('current-edit-address-country'))}
 
 addressTypeOption() { return element(by.id('current-edit-address-type'))}


  // Add Address Detail
  addAddressLine1Field() { return element(by.id('add-address-address-line-1'))}
  addAddressLine2Field() { return element(by.id('add-address-address-line-2'))}
  addCityField() { return element(by.id('add-address-city'))}
  addStateField() { return element(by.id('add-address-state'))}
  addPostalCodeField() { return element(by.id('add-address-postal-code'))}
  addCountryField() { return element(by.id('add-address-country'))}
 // addAddressTypeOption() { return element(by.id('add-address-type'))}
 
 
 addressListButton() { return element(by.id('list_address'))}
 
 // addressListButton() { return element(by.css('[class^="flaticon-list iconText"]'))}
 // addressListButton() { return element(by.xpath('//*[@id="undefined_list_address"]'))}
 
 
 editClientAddressButton() { return element(by.id('primary-address-undefined'))}
 
 addAddressInfoButton() { return element(by.id('create_address'))}

 editOKAddressInfoButton() { return element(by.id('modal__ok'))}
 addOKAddressInfoButton() { return element(by.id('modal__ok'))}
 closeAddressInfoButton() { return element(by.id('client-summary-screen'))}
 


 editListClientAddressButton() { return element(by.css('[class^="flaticon-edit iconText ng-star-inserted"]'))}


  deleteAddressButton() { return element.all(by.css('[class^="fa fa-trash"]')).get(1)}
  
 // deleteAddressButton() { return element(by.id('delete_address_icon_2405'))}
 confirmDeleteButton() { return element(by.id('confirm_dialog__ok'));}
 // confirmDeleteButton() { return element(by.id('confirm_dialog__ok'))}
 cancelDeleteButton() { return element(by.id('confirm_dialog__cancel'))}

}
