

import {element, ElementFinder, by} from 'protractor';

export class LoginPage {

userNameField() { return element(by.id('authUsername'))}
passwordField() { return element(by.id('authPassword'))}

loginButton() { return element(by.id('loginBtn')) }

logoutIcon() { return element(by.id('dropdownBasicUser')) }
logoutButton() { return element(by.css('[class="mat-menu-content ng-trigger ng-trigger-fadeInItems"]')) }
// logoutButton() { return element(by.id('cdk-overlay-0')) }

}