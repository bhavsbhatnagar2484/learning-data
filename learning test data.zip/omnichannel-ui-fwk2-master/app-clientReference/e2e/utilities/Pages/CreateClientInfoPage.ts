

import {element, ElementFinder, by} from 'protractor';

export class CreateClientInfoPage {

 
 firstNameField() { return element(by.id('add-personal-first-name'))}
 middleNameField() { return element(by.id('add-personal-middle-name'))}
 lastNameField() { return element(by.id('add-personal-last-name'))}
 

 femaleGenderOption() { return element.all(by.css('[class^="mat-button-toggle-label-content"]')).get(0)}
 maleGenderOption() { return element.all(by.css('[class^="mat-button-toggle-label-content"]')).get(1)}

//  dateOfBirthField() { return element(by.css('[aria-label="Date input field"]'))}
 dateOfBirthField() { return element(by.id('add-personal-date-of-birth_input'))}
 emailField() { return element(by.id('add-personal-email'))}

 nextButton() { return element(by.id('wizard_addPersonal_stepNext'))}

}
