

import {element, ElementFinder, by} from 'protractor';

export class ListDependentPage {

 // Edit Dependent Detail
 dependentNameField() { return element(by.id('current-edit-dependent-name'))}
 dependentDoB() { return element(by.id('current-edit-dependent-date-of-birth_input'))}
 
 relationDropdown() { return element(by.id('current-edit-dependent-relation'))}
 relationTypeSpouse() { return element.all(by.css('[class^="mat-option ng-star-inserted"]')).get(0)}
 relationTypeChildren() { return element.all(by.css('[class^="mat-option ng-star-inserted"]')).get(1)}
 relationTypeOther() { return element.all(by.css('[class^="mat-option ng-star-inserted"]')).get(2)}


//  relationTypeSpouse() { return element(by.id('current-edit-dependent-relation')).$('[value="SPOUSE"]')}
//  relationTypeChildren() { return element(by.id('current-edit-dependent-relation')).$('[value="CHILDREN"]')}
//  relationTypeOther() { return element(by.id('current-edit-dependent-relation')).$('[value="OTHER"]')}

 relationFieldOption() { return element(by.id('current-edit-dependent-relation'))}
 
 typeDropdown() { return element(by.id('current-edit-dependent-type'))}
 dependentTypePrimary() { return element.all(by.css('[class^="mat-option ng-star-inserted"]')).get(0)}
 dependentTypeSecondary() { return element.all(by.css('[class^="mat-option ng-star-inserted"]')).get(1)}
 dependentTypeOption() { return element(by.id('current-edit-dependent-type'))}

 //----------------------------------------------------------------------------------------------------------
  // Add Dependent Detail
 addDependentNameField() { return element(by.id('add-dependent-name'))}
 addDependentDoB() { return element(by.id('add-dependent-date-of-birth_input'))}

 addRelationDropdown() { return element(by.id('add-dependent-relation'))}
 addRelationTypeSpouse() { return element.all(by.css('[class^="mat-option ng-star-inserted"]')).get(0)}
 addRelationTypeChildren() { return element.all(by.css('[class^="mat-option ng-star-inserted"]')).get(1)}
 addRelationTypeOther() { return element.all(by.css('[class^="mat-option ng-star-inserted"]')).get(2)}

 addTypeDropdown() { return element(by.id('add-dependent-type'))}
 addDependentTypePrimary() { return element(by.css('add-dependent-type_0'))}
 addDependentTypeSecondary() { return element(by.css('add-dependent-type_1'))}
  
 dependentListButton() { return element(by.id('list_dependent'))}
 
 addDependentInfoButton() { return element(by.id('create_dependent'))}
 addOKDependentInfoButton() { return element(by.id('modal__ok'))}
 editOKDependentInfoButton() { return element(by.id('modal__ok'))}
 closeDependentInfoButton() { return element(by.id('client-summary-screen'))}
 

 editDependentButton() { return element(by.id('primary-dependent-undefined'))}
 
 editListDependentButton() { return element(by.css('[class^="flaticon-edit iconText ng-star-inserted"]'))}
 

 deleteDependentButton() { return element(by.css('[class^="fa fa-trash"]'))}

 confirmDeleteButton() { return element(by.id('confirm_dialog__ok'))}
 cancelDeleteButton() { return element(by.id('confirm_dialog__cancel'))}
 
}
 