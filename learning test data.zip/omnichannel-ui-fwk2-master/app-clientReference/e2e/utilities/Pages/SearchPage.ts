

import {element, ElementFinder, by} from 'protractor';

export class SearchPage {

 firstNameSearchField() { return element(by.id('client-search-first-name'))}
 middleNameSearchField() { return element(by.id('client-search-middle-name'))}
 lastNameSearchField() { return element(by.id('client-search-last-name'))}
 
 genderSearchOption() { return element(by.id('client-search-gender'))}
 dateOfBirthSearchField() { return element(by.id('client-search-date-of-birth_input'))}
 emailSearchField() { return element(by.id('client-search-email'))}
 
 createButton() { return element(by.id('create_client'))}
 searchButton() { return element(by.id('btnfilter'))}

 editButton() { return element(by.css('[class^="flaticon-edit"]'))}
 
 resetButton() { return element(by.id('btnreset'))}
 
 
 deleteButton() { return element(by.css('[class^="fa fa-trash"]'))}

 
 confirmDeleteButton() { return element(by.id('confirm_dialog__ok'))}
 cancelDeleteButton() { return element(by.id('confirm_dialog__cancel'))}

//  ------------

personIcon() { return element(by.id('dropdownBasicUser'))}
arabic() { return element.all(by.id('oc-language-option-{i}')).get(2)}

}



