

import {element, ElementFinder, by} from 'protractor';

export class CreateAddressInfoPage {

 // Create Client Address Page
 addressLine1Field() { return element(by.id('add-address-address-line-1'))}
 addressLine2Field() { return element(by.id('add-address-address-line-2'))}
 cityField() { return element(by.id('add-address-city'))}
 stateField() { return element(by.id('add-address-state'))}
 countryField() { return element(by.id('add-address-country'))}
 postalCodeField() { return element(by.id('add-address-postal-code'))}
 
 // addressDropDown() { return element(by.css('[class^="mat-select-value"]'))}
 addressDropDown() { return element.all(by.id('add-address-type')).get(0)}
 addressTypePrimary() { return element(by.id('add-address-type_0'))}
 addressTypeSecondary() { return element(by.id('add-address-type_1'))}
 
 previousButton() { return element(by.id('wizard_addAddress_stepPrevious'))}
 
 startOverButton() { return element(by.id('wizard_addAddress_stepNext'))}
 
 cancelButton() { return element(by.id('undefined_home-screen'))}
 


}