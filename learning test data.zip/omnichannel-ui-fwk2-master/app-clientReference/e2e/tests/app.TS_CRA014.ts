//TS_CRA014 - To edit dependent list -              
//1)Delete existing dependent    2)Add dependent-1                                  
//3)Add dependent-2              4)Edit existing dependent       


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA014', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA014');
  });

   it('TS_CRA014#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA014#Login to the Application', () => {
     this.application.loginApplication();
  });

   //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA014#Search Client using - Date of Birth,Gender,Email', () => {
     // const criteria = ['Date of Birth,Gender,Email'];
     const criteria = ['FirstName', 'MiddleName', 'LastName'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param); 
     
  });

   it('TS_CRA014#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA014#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

    //         -----------  UPDATE DEPENDENT   ----------    //

 it('TS_CRA014#Click Edit Button of Dependent', () => {
  this.application.clickEditDependentButton();
});

it('TS_CRA014#Update Dependent Details', () => {
  this.application.updateExistingDependent();
  console.log('Updated dependent');
});

it('TS_CRA014#Click Dependent Ok Button', () => {
  this.application.clickEditDependentInfoOKButton();
});

   //         -----------  ADD DEPENDENT   ----------    //

  it('TS_CRA014#Click on Add Dependent Info Button', () => {
     this.application.clickAddDependentInfoButton();
  });

 it('TS_CRA014#Fill Dependent-1 Info Details', () => {
     this.application.addDependentInfoDetailsTwo();
     console.log('Added dependent');
  });

 it('TS_CRA014#Click Dependent Info Ok Button', () => {
     this.application.clickAddDependentInfoOKButton();
  });

  //         -----------  ADD DEPENDENT   ----------    //

 it('TS_CRA014#Click on Add Dependent Info Button', () => {
     this.application.clickAddDependentInfoButton();
     browser.sleep(5000);
  });

 it('TS_CRA014#Fill Dependent-2 Info Details', () => {
     this.application.addDependentInfoDetailsTwo();
     console.log('Added dependent');
  });

 it('TS_CRA014#Click Dependent Info Ok Button', () => {
     this.application.clickAddDependentInfoOKButton();
  });

//   //         -----------  DELETE DEPENDENT   ----------    //

   it('TS_CRA014#CClick on Dependent List Button', () => {
    this.application.clickDependentListButton();
 });

 it('TS_CRA014#click Delete Button', () => {
    this.application.clickDeleteDependentButton();
    console.log('Deleted dependent');
 });

 it('TS_CRA014#Click Client Summary Button Button', () => {
  this.application.clickClientSummaryButton();
});

it('TS_CRA014#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA014#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});