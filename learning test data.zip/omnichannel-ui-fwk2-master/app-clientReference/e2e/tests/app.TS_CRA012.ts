//TS_CRA012 - To update dependent info by editing its details.



import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA012', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA012');
  });

   it('TS_CRA012#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA012#Login to the Application', () => {
     this.application.loginApplication();
    // browser.sleep(10000);
  });

   //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA012#Search Client using - Email', () => {
     const criteria = ['Email'];
     this.param1 = this.application.getParam(criteria);
     this.application.clientSearchByParams(this.param1); 
  });

   it('TS_CRA012#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA012#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

   //         -----------  UPDATE DEPENDENT   ----------    //

  it('TS_CRA012#Click Edit Button of Client Questions in Client Summary', () => {
     this.application.clickEditDependentButton();
  });

  it('TS_CRA012#Update Existing Dependent Details', () => {
     this.application.updateExistingDependent();
  });

  it('TS_CRA012#Click Dependent Ok Button', () => {
     this.application.clickEditDependentInfoOKButton();
  });

  it('TS_CRA012#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA012#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});