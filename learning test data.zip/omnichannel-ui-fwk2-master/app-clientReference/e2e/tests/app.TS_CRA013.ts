//TS_CRA013 -  To update address info by editing its details


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA013', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA013');
  });

   it('TS_CRA013#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA013#Login to the Application', () => {
     this.application.loginApplication();
  });

   //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA013#Search Client using - First Name, Middle Name, Last Name', () => {
     const criteria = ['FirstName', 'MiddleName', 'LastName'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param); 
  });

   it('TS_CRA013#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA013#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

   //         -----------  UPDATE ADDRESS   ----------    //

  it('TS_CRA013#Click Edit Button of Address in Client Summary', () => {
     this.application.clickEditAddressButton();
  });
  
  it('TS_CRA013#Update Existing Address Details', () => {
     this.application.updateExistingAddress();
  });

  it('TS_CRA013#Click Address Ok Button', () => {
     this.application.clickEditAddressInfoOKButton();
  });

  it('TS_CRA013#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA013#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});