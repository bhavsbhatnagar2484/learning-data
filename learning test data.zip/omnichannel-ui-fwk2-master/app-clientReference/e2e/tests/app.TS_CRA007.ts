//TS_CRA007 - To delete client - search the cient,delete it


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA007', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA007');
  });

   it('TS_CRA007#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA007#Login to the Application', () => {
     this.application.loginApplication();
  });

    //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA007#Search Client To be Deleted using - First Name', () => {
     const criteria = ['FirstName'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param); 
  });

   it('TS_CRA007#Click Search Button', () => {
     this.application.clickSearchButton();
  });

    //         -----------  DELETE CLIENT   ----------    //

  it('TS_CRA007#click Delete Button', () => {
     this.application.clickDeleteClientButton();
  });

   it('TS_CRA007#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});