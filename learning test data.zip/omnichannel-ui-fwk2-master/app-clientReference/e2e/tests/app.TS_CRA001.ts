// TS_CRA001 - To create new client by filling 
// all the details of client information and address information

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA001', () => {
 beforeAll(() => {
    this.application = new Application('TS_CRA001');
  });

   it('TS_CRA001#Launch URL', () => {    
    this.application.launchURL();  
    // browser.sleep(6000);  
  });

   it('TS_CRA001#Login to the Application', () => {
     this.application.loginApplication();
     browser.sleep(12000);  
  });
  
   it('TS_CRA001#Click Create Button', () => {
     this.application.clickCreateButton();
  });

   it('TS_CRA001#Fill Client Information', () => {
     this.application.fillClientInformation();
  });

   it('TS_CRA001#Go to address information page', () => {
     this.application.clickAddressInfoButton();
  });

   it('TS_CRA001#Fill Address Information', () => {
     this.application.fillAddressInformation();
  });

   it('TS_CRA001#Go to client summary', () => {
     this.application.clickStartOverButton();
  });

   it('TS_CRA001#Click on Logout Button', () => {
     this.application.logoutIcon();
     browser.sleep(4000); 
     this.application.logoutButton();
     browser.sleep(8000); 
  });

});
