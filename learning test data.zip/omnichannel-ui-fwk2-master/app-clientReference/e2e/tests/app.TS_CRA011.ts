//TS_CRA011 - To update client questions and add dependent info in client summary


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA011', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA011');
  });

   it('TS_CRA011#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA011#Login to the Application', () => {
     this.application.loginApplication();
  });

  
     //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA011#Search Client using - Middle Name', () => {
     const criteria = ['MiddleName'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param);
     browser.sleep(4000); 
  });

   it('TS_CRA011#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA011#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

      //         -----------  UPDATE CLIENT QUESTIONS   ----------    //

  it('TS_CRA011#Click Edit Button of Client Questions in Client Summary', () => {
     this.application.clickEditClientQuestionsButton();
     browser.sleep(3000);
  });

 it('TS_CRA011#Update Client Questions', () => {
     this.application.updateClientQuestions();
  }); 

  it('TS_CRA011#Click Client Questions Ok Button', () => {
     this.application.clickOkClientQuestionsButton();
  });

     //         -----------  DEPENDENT CLIENT   ----------    //

  it('TS_CRA011#Click on Add Dependent Info Button', () => {
     this.application.clickAddDependentInfoButton();
  });

  it('TS_CRA011#Fill Dependent Info Details', () => {
     this.application.addDependentInfoDetails();
  });

  it('TS_CRA011#Click Dependent Info Ok Button', () => {
     this.application.clickAddDependentInfoOKButton();
  });

  it('TS_CRA011#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA011#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});