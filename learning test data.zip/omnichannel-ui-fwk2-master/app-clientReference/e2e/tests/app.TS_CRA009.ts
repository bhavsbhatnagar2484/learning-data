//TS_CRA009 - To delete client - To delete dependent info in client summary 


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA009', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA009');
  });

   it('TS_CRA009#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA009#Login to the Application', () => {
     this.application.loginApplication();
  });

  
     //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA009#Search Client using - Last Name', () => {
     const criteria = ['LastName'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param); 
  });

   it('TS_CRA009#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA009#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

  
     //         -----------  DELETE DEPENDENT   ----------    //

  it('TS_CRA009#CClick on Dependent List Button', () => {
    this.application.clickDependentListButton();
 });

   it('TS_CRA009#Click Delete Button - First Entry of Dependent Information', () => {
     this.application.clickDeleteDependentButton();
  });

  it('TS_CRA009#Click Client Summary Button Button', () => {
    this.application.clickClientSummaryButton();
 });

  it('TS_CRA009#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA009#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});