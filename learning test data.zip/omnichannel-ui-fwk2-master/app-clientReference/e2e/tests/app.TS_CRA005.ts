//TS_CRA005 - To search client using first name and date of birth,
//verify all the details of searched client.

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA005', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA005');
  });

   it('TS_CRA005#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA005#Login to the Application', () => {
     this.application.loginApplication();
  });

    //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA005#Search Client By criteria -  First Name ,Date of Birth', () => {
     const criteria = ['FirstName', 'DateOfBirth'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param); 
  });

  it('TS_CRA005#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA005#Go to Client Summary - click on Edit Button of Searched Client', () => {
     this.application.clickEditButton();
  });

     //         -----------  VERIFY CLIENT INFORMATION ----------    //

  it('TS_CRA005#Client Summary - click on Edit Button of Client Details', () => {
    this.application.clickEditClientInfoButton();
 });

   it('TS_CRA005#Verify Client Details', () => {
     this.application.verifyClientInfoDetails();
  });
 
  it('TS_CRA005#Client Summary - click on Close Button of Client Info', () => {
    this.application.clickOkClientInfoButton();
 });

 //      -----------  VERIFY ADDRESS INFORMATION ----------    //

 it('TS_CRA005#Client Summary - click on Edit Button of Address Details', () => {
  this.application.clickEditAddressButton();
});

 it('TS_CRA005#Verify Address Details', () => {
   this.application.verifyAddressDetails();
});

it('TS_CRA005#Client Summary - click on Close Button of Address Details', () => {
  this.application.clickEditAddressInfoOKButton();
});

   //         -----------  VERIFY DEPENDENT INFORMATION ----------    //
   
it('TS_CRA005#Client Summary - click on Edit Button of Dependent Details', () => {
  this.application.clickEditDependentButton();
});

 it('TS_CRA005#Verify Dependent Details', () => {
   this.application.verifyDependentDetails();
});

it('TS_CRA005#Client Summary - click on Close Button of Dependent Details', () => {
  this.application.clickEditDependentInfoOKButton();
});

   it('TS_CRA005#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA005#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});
