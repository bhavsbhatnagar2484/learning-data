//TS_CRA004 - To search client using middle name and gender,reset details,
//verify all the details of searched client.

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA004', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA004');
  });

   it('TS_CRA004#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA004#Login to the Application', () => {
     this.application.loginApplication();
  });
  
  //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA004#Search Client By criteria -  Middle Name', () => {
     const criteria = ['MiddleName'];
     this.param1 = this.application.getParam(criteria);
     this.application.clientSearchByParams(this.param1); 
  });

   it('TS_CRA004#Click Reset Button', () => {
     this.application.clickResetButton();
  });

    it('TS_CRA004#Search Client By criteria -  Middle Name', () => {
      const criteria = ['MiddleName'];
      const param = this.application.getParam(criteria);
      this.application.clientSearchByParams(param); 
  });

   it('TS_CRA004#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA004#Go to Client Summary - click on Edit Button of Searched Client', () => {
     this.application.clickEditButton();
  });

  
   //         -----------  VERIFY CLIENT INFORMATION ----------    //
    
  it('TS_CRA004#Client Summary - click on Edit Button of Client Details', () => {
    this.application.clickEditClientInfoButton();
 });

   it('TS_CRA004#Verify Client Details', () => {
     this.application.verifyClientInfoDetails();
  });
 
  it('TS_CRA004#Client Summary - click on Close Button of Client Info', () => {
    this.application.clickOkClientInfoButton();
 });


  //      -----------  VERIFY ADDRESS INFORMATION ----------    //

 it('TS_CRA004#Client Summary - click on Edit Button of Address Details', () => {
  this.application.clickEditAddressButton();
});

 it('TS_CRA004#Verify Address Details', () => {
   this.application.verifyAddressDetails();
});

it('TS_CRA004#Client Summary - click on Close Button of Address Details', () => {
  this.application.clickEditAddressInfoOKButton();
});

    //         -----------  VERIFY DEPENDENT INFORMATION ----------    //

it('TS_CRA004#Client Summary - click on Edit Button of Dependent Details', () => {
  this.application.clickEditDependentButton();
});

 it('TS_CRA004#Verify Dependent Details', () => {
   this.application.verifyDependentDetails();
});

it('TS_CRA004#Client Summary - click on Close Button of Dependent Details', () => {
  this.application.clickEditDependentInfoOKButton();
});

   it('TS_CRA004#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA004#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});
