// TS_CRA010 - To update client info and add address info in client summary 


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA010', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA010');
  });

   it('TS_CRA010#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA010#Login to the Application', () => {
     this.application.loginApplication();
  });

     //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA010#Search Client using - Date of birth', () => {
     const criteria = ['DateOfBirth'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param); 
  });

   it('TS_CRA010#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA010#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

  //         -----------  UPDATE CLIENT   ----------    //

   it('TS_CRA010#Click Edit Button of Client Info in Client Summary', () => {
     this.application.clickEditClientInfoButton();
  });

   it('TS_CRA010#Update Client Info Details', () => {
     this.application.updateClientInfoDetails();
  });

  it('TS_CRA010#Click Client Info OK Button', () => {
    this.application.clickOkClientInfoButton();
 });

 //         -----------  ADD ADDRESS   ----------    //

   it('TS_CRA010#Click on Add Address Info Button', () => {
     this.application.clickAddAddressInfoButton();
  });

   it('TS_CRA010#Add Address Info Details', () => {
     this.application.addAddressInfoDetails();
  });

   it('TS_CRA010#Click Address Info Ok Button', () => {
     this.application.clickAddAddressInfoOKButton();
  });

   it('TS_CRA010#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});