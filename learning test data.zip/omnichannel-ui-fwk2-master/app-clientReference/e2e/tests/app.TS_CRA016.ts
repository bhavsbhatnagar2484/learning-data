// _________________ Arabic  ______________________________________


// TS_CRA016 - To create new client by filling 
// all the details of client information and address information

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA016', () => {
 beforeAll(() => {
    this.application = new Application('TS_CRA016');
  });

   it('TS_CRA016#Launch URL', () => {    
    this.application.launchURL();  
    browser.sleep(2000);  
  });

   it('TS_CRA016#Login to the Application', () => {
     this.application.loginApplication();
  });

  it('TS_CRA016#Login to the Application', () => {
    this.application.selectLanguage();
 });

   it('TS_CRA016#Click Create Button', () => {
     this.application.clickCreateButton();
  });

   it('TS_CRA016#Fill Client Information', () => {
     this.application.fillClientInformation();
  });

   it('TS_CRA016#Go to address information page', () => {
     this.application.clickAddressInfoButton();
  });

   it('TS_CRA016#Fill Address Information', () => {
     this.application.fillAddressInformation();
  });

   it('TS_CRA016#Go to client summary', () => {
     this.application.clickStartOverButton();
  });

   it('TS_CRA016#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});
