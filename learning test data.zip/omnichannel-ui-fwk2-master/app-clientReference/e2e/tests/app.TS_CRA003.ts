//TS_CRA003 -To search client using first name and last name,
//verify all the details of searched client.

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA003', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA003');
  });

   it('TS_CRA003#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA003#Login to the Application', () => {
     this.application.loginApplication();
  });

   //         -----------  SEARCH CLIENT   ----------    //

  it('TS_CRA003#Search Client By criteria - First Name ,Last Name', () => {
      const criteria = ['FirstName', 'LastName'];
     //const criteria = ['FirstName'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param); 
  });;

   it('TS_CRA003#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA003#Go to Client Summary - click on Edit Button of Searched Client', () => {
     this.application.clickEditButton();
  });

   //         -----------  VERIFY CLIENT INFORMATION ----------    //

  it('TS_CRA003#Client Summary - click on Edit Button of Client Details', () => {
    this.application.clickEditClientInfoButton();
 });

   it('TS_CRA003#Verify Client Details', () => {
     this.application.verifyClientInfoDetails();
  });
 
  it('TS_CRA003#Client Summary - click on OK Button of Client Info', () => {
    this.application.clickOkClientInfoButton();
 });

    //      -----------  VERIFY ADDRESS INFORMATION ----------    //

 it('TS_CRA003#Client Summary - click on Edit Button of Address Details', () => {
  this.application.clickEditAddressButton();
});

 it('TS_CRA003#Verify Address Details', () => {
   this.application.verifyAddressDetails();
});

it('TS_CRA003#Client Summary - click on OK Button of Address Details', () => {
  this.application.clickEditAddressInfoOKButton();
});

    //         -----------  VERIFY DEPENDENT INFORMATION ----------    //

it('TS_CRA003#Client Summary - click on Edit Button of Dependent Details', () => {
  this.application.clickEditDependentButton();
});

 it('TS_CRA003#Verify Dependent Details', () => {
   this.application.verifyDependentDetails();
});

it('TS_CRA003#Client Summary - click on OK Button of Dependent Details', () => {
  this.application.clickEditDependentInfoOKButton();
});

it('TS_CRA003#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA003#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});
