//TS_CRA015 - To edit address list -                
//1)Delete existing address             2)Add address-1                                  
// 3)Add address-2                      4)Edit existing address       

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from '../utilities/ClientReferenceApplication';

describe('TS_CRA015', () => {
 
beforeAll(() => {
    this.application = new Application('TS_CRA015');
  });

   it('TS_CRA015#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA015#Login to the Application', () => {
     this.application.loginApplication();
     browser.sleep(12000); 
  });

    //         -----------  SEARCH CLIENT   ----------    //

   it('TS_CRA015#Search Client using - Last Name', () => {
     const criteria = ['LastName'];
     const param = this.application.getParam(criteria);
     this.application.clientSearchByParams(param); 
  });

   it('TS_CRA015#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA015#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

 //         -----------  ADD ADDRESS-1   ----------    //

  it('TS_CRA015#Click on Add Address-1 Info Button', () => {
     this.application.clickAddAddressInfoButton();
  });

 it('TS_CRA015#Fill Address-1 Info Details', () => {
     this.application.addAddressInfoDetails();
     console.log('Added Address');
  });

 it('TS_CRA015#Click Address Info Ok Button', () => {
     this.application.clickAddAddressInfoOKButton();
  });

 //         -----------  ADD ADDRESS-2   ----------    //

 it('TS_CRA015#Click on Add Address Info Button', () => {
     this.application.clickAddAddressInfoButton();
  });

 it('TS_CRA015#Fill Address-2 Info Details', () => {
     this.application.addAddressInfoDetails();
     console.log('Added Address');
  });

 it('TS_CRA015#Click Address Info Ok Button', () => {
     this.application.clickAddAddressInfoOKButton();
  });

  //         -----------  UPDATE ADDRESS   ----------    //

 it('TS_CRA015#Click Edit Button of Address in Client Summary', () => {
     this.application.clickEditAddressButton();
  });

 it('TS_CRA015#Update Address Details', () => {
     this.application.updateExistingAddress();
     console.log('Updated Address');
  });

 it('TS_CRA015#Click Address Ok Button', () => {
     this.application.clickEditAddressInfoOKButton();
  });

  //         -----------  DELETE ADDRESS   ----------    //

  it('TS_CRA015#Click on Address List Button', () => {
    this.application.clickAddressListButton();
  });

  it('TS_CRA015#click Delete Button', () => {
    this.application.clickDeleteAddressButton();
    console.log('Deleted Address');
  });

  it('TS_CRA015#Click Client Summary Button Button', () => {
    this.application.clickClientSummaryButton();
 });


 it('TS_CRA015#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA015#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});