import { Property } from 'oc-infra';

export class CustomSelect extends Property{

    viewVaule: any;

    constructor(input: CustomSelect){
        super(input);
    }

    transformData(input: CustomSelect) {
        this.placeholder = 'Select Gender';
        this.updateMode = 'change';
        this.values = input.values;
        return this;
    }  

}