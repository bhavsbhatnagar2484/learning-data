import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs/Rx";
import { MatDialog } from '@angular/material';

@Injectable()
export class CommonService {

    constructor(private http: Http, public dialog: MatDialog) {}

    public postCallback(url: string, body: Object, headers: any){
        return this.http.post(url, body ? body : {}, { headers: headers })
        .map(response => {
            return response.json();
        })
        .share()
        .catch(error => Observable.throw(error.json()));
    }

    public getCallback(url: string, headers: any){
        return this.http.get(url, { headers: headers })
        .map(response => {
            return response.json();
        })
        .share()
        .catch(error => Observable.throw(error.json()));
    }

    public getModalDialog() {
        return this.dialog;
    }
}