import { Component, OnInit } from '@angular/core';
import { Headers } from '@angular/http';

import { CommonService } from './../../services/common.service';
import { AuthenticationService } from './../../services/authentication.service';
import { AdvGrowlService } from 'primeng-advanced-growl';
import { APICallerService } from 'oc-infra';
import { OcInfraModule } from 'oc-infra';
import { NavigationService } from 'oc-infra';
import { Configuration } from 'oc-infra';
import { LoginComponent } from './../login.component/login.component';
@Component({
  'template': '',
  'entryComponents': [LoginComponent]
})
export class LogoutComponent implements OnInit {

  private logoutURL: string;

  private logoutBody: Object;

  private logoutResponseData: any;

  constructor(private commonService: CommonService, private authenticationService: AuthenticationService) {
    this.logoutURL = this.authenticationService.config.authnURL + '/sessions?_action=logout';
    this.logoutBody = {};
  }

  ngOnInit() {
    this.executeLogout();
  }

  private executeLogout() {
    window.sessionStorage.clear();
    this.authenticationService.getHeaderProperties.emit(false);
    this.authenticationService.resetHeaders();
    OcInfraModule.AppInjector.get(NavigationService).navigateTo(Configuration.config.loginPage);
    OcInfraModule.AppInjector.get(AdvGrowlService).createSuccessMessage('Success logout', 'Success');
  }
}
