import { Component, OnInit } from '@angular/core';
import { Headers } from '@angular/http';
import { OcInfraModule, NavigationService, APICallerService, Configuration } from 'oc-infra';
import { CommonService } from './../../services/common.service';
import { AuthenticationService } from './../../services/authentication.service';
import { AdvGrowlService } from 'primeng-advanced-growl';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  private authURL: string;

  private authBody: Object;

  private authUsername: String;

  private authPassword: String;

  private authResponseData: any;

  public static processErrors(msg: string, timeout?: boolean) {
    OcInfraModule.AppInjector.get(AdvGrowlService).createErrorMessage(msg, 'Error');
    OcInfraModule.AppInjector.get(APICallerService).pendingCalls = OcInfraModule.AppInjector.get(APICallerService).pendingCalls - 1;
    if (timeout) {
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    }
  }

  constructor(private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private growlService: AdvGrowlService) {

    }

  ngOnInit() {
    OcInfraModule.AppInjector.get(APICallerService).pendingCalls = OcInfraModule.AppInjector.get(APICallerService).pendingCalls + 1;
    this.authenticationService.loadConfig()
    .subscribe(response => {
      this.authURL = this.authenticationService.config.authnURL + '/authenticate';
      this.authBody = {};
      this.authenticationService.httpHeaders.set('Content-Type', 'application/json');
      this.authenticationService.resetHeaders();

      OcInfraModule.AppInjector.get(APICallerService).pendingCalls = OcInfraModule.AppInjector.get(APICallerService).pendingCalls + 1;
      this.commonService.postCallback(this.authURL, this.authBody, this.authenticationService.httpHeaders)
      .subscribe(
        response => {
          this.authResponseData = response;
          OcInfraModule.AppInjector.get(APICallerService).pendingCalls = OcInfraModule.AppInjector.get(APICallerService).pendingCalls - 1;
        },
        error => {
          this.handleErrors(error);
        }
      );
      OcInfraModule.AppInjector.get(APICallerService).pendingCalls = OcInfraModule.AppInjector.get(APICallerService).pendingCalls - 1;
    },
    error => {
      this.handleErrors(error);
    });
  }

  private executeLogin() {
    if (this.authUsername !== undefined && this.authPassword !== undefined ) {
      if (this.authResponseData !== undefined && this.authResponseData.callbacks !== undefined && this.authResponseData.callbacks.length > 0) {
        for (let i = 0; i < this.authResponseData.callbacks.length; i++) {
          if (this.authResponseData.callbacks[i].type === 'NameCallback' && this.authResponseData.callbacks[i].input[0].name === 'IDToken1') {
            this.authResponseData.callbacks[i].input[0].value = this.authUsername;
              continue;
          }
          if (this.authResponseData.callbacks[i].type === 'PasswordCallback' && this.authResponseData.callbacks[i].input[0].name === 'IDToken2') {
            this.authResponseData.callbacks[i].input[0].value = this.authPassword;
              continue;
          }
        }

        OcInfraModule.AppInjector.get(APICallerService).pendingCalls = OcInfraModule.AppInjector.get(APICallerService).pendingCalls + 1;
        this.commonService.postCallback(this.authURL, this.authResponseData, this.authenticationService.httpHeaders)
        .subscribe(
          response => {

            window.sessionStorage.setItem('tokenId', response.tokenId.toString());
            window.sessionStorage.setItem('username', this.authUsername.toString());

            OcInfraModule.AppInjector.get(NavigationService).navigateTo('/screen/' + Configuration.config.landingPage);
            this.growlService.createSuccessMessage('Authentication successful', 'Success');
            OcInfraModule.AppInjector.get(APICallerService).pendingCalls = OcInfraModule.AppInjector.get(APICallerService).pendingCalls - 1;
          },
          error => {
            this.handleErrors(error);
          }
        );
      }
    }
  }

  private handleErrors(error) {
    if (error.code === 401) {
      if (error.detail && error.detail.errorCode && error.detail.errorCode === 110) {
        LoginComponent.processErrors(error.message, true);
      } else {
        LoginComponent.processErrors(error.message);
      }
    } else if (error.code === 408) {
      LoginComponent.processErrors(error.message, true);
    } else {
      LoginComponent.processErrors('Something went worng');
    }
  }

}
