import { Component } from '@angular/core';
import { OcInfraModule, NavigationService } from'oc-infra';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Client Reference Application';

  constructor() {

    const username = window.sessionStorage.getItem('username');
    if(!username || username === undefined){
      OcInfraModule.AppInjector.get(NavigationService).navigateTo('/');
    }

  }
}
