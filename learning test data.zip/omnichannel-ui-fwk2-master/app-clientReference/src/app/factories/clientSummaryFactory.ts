import * as _ from 'lodash';
import { OcInfraModule, NavigationService, APICallerService, ResourceService, ResourceDirectoryService, ModalComponent } from'oc-infra';
import { CommonFactory } from './commonFactory';
import { CommonService } from 'app/services/common.service';

export class ClientSummaryFactory extends CommonFactory {

    navigateTo(params) {
        super.navigateTo(params.defaultValue);
    }

    navigateToWithLink(params) {
        const baseAlias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName(params.defaultValue.alias, true);
        const navParams = params.defaultValue;
        navParams.link = baseAlias.href;
        super.navigateTo(navParams);
        if (navParams.url === 'addressSummary') {
            this.performRefresh('addresses');
        } else if (navParams.url === 'dependentSummary') {
            this.performRefresh('dependents');
        }
        
    }

    openClientSummary(params) {
        const baseAlias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName(params.defaultValue.alias, true);
        params.defaultValue.link = baseAlias.href;
        super.navigateTo(params.defaultValue);
    }

    addAddress(params) {
        if (!_.isEmpty(params.payload)) {
            params.payload.message = 'Address Details added successfully';
            if (params.payload instanceof Array) {
                super.patchAction(params.payload);
            }
            params.modal.dialogRef.close(); 
        }
    }

    createAddress(params) {
        if(params.modal && params.modal.modal) {
            params.modal.modal.close();
            setTimeout(() => {
                OcInfraModule.AppInjector.get(CommonService).getModalDialog().open(ModalComponent, { data: params.modal, disableClose: params.modal.modal.disableClose, 
                    closeOnNavigation: params.modal.modal.closeOnNavigation });
            },2000)
        }
        const baseAlias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName(params.defaultValue.actionURL, true);
        const createParams: any = {};
        createParams.url = baseAlias.href + '/addresses';
        createParams.body = null;
        createParams.alias = params.defaultValue.alias;
        super.createAction(createParams);
    }

    addDependent(params) {
        //proceed only when params.payload is not empty
        if (!_.isEmpty(params.payload)) {
            params.payload.message = 'Dependent Details added successfully';
            if (params.payload instanceof Array) {
                super.patchAction(params.payload);
                if (params.payload[0] !== undefined && params.payload[0].payload.dependent_type === 'PRIMARY') {
                    const newParam: any = {};
                    newParam.value = params.payload[0].payload.dependent_type;
                    newParam.alias = 'addDependent';
                    this.updatePrimaryDependentAlias(newParam);
                }
            }
            params.modal.dialogRef.close(); 
        }
    }
    createDependent(params) {
        const baseAlias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName(params.defaultValue.actionURL, true);
        const createParams: any = {};
        createParams.url = baseAlias.href + '/dependents';
        createParams.body = null;
        createParams.alias = params.defaultValue.alias;
        super.createAction(createParams);
    }

    editPersonal(params) {
        if (params) {
            params.payload.message = 'Personal Details updated successfully';
            if (params.payload instanceof Array) {
                super.patchAction(params.payload);
            }
            params.modal.dialogRef.close(); 
        }
    }

    editAddress(params) {
        if (params) {
            params.payload.message = 'Address Details updated successfully';
            if (params.payload instanceof Array) {
                super.patchAction(params.payload);
            }
            params.modal.dialogRef.close(); 
        }
    }

    editDependent(params) {
        if (params) {
            params.payload.message = 'Dependent Details updated successfully';
            if (params.payload instanceof Array) {
                super.patchAction(params.payload);
            }
            params.modal.dialogRef.close(); 
        }
    }

    editQuestion(params) {
        if (params) {
            params.payload.message = 'Answers updated successfully';
            if (params.payload instanceof Array) {
                super.patchAction(params.payload);
            }
            params.modal.dialogRef.close(); 
        }
    }

    deleteAddress(params) {
        if (params && params.data && params.data.params) {
            this.performDelete(params);
            this.performRefresh('addresses');
        }
    }

    deleteDependent(params) {
        if (params && params.data && params.data.params) {
            this.performDelete(params);
            this.performRefresh('dependents');
        }
    }

    performDelete(params) {
        const alias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName(params.data.params.alias, true);
        const delParams = { alias: params.data.params.alias, url: alias.href }
        super.deleteAction(delParams);
        OcInfraModule.AppInjector.get(ResourceDirectoryService).deleteElementResourceDirectory(alias.href);
        OcInfraModule.AppInjector.get(ResourceService).updateCreateAliasName(params.data.params.alias, undefined, true);
    }

    controlVisibilityOfPrimaryDepenentButton() {
        const alias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName('primaryDependent', true);
        if (alias && alias.href) {
            return true;
        } else {
            return false;
        }
    }

    updatePrimaryDependentAlias(param) {
        if (param && param.value === 'PRIMARY') {
            const resourceService = OcInfraModule.AppInjector.get(ResourceService);
            let resourceHref = resourceService.getHrefByAliasName(param.alias);
            if (resourceHref instanceof Array && resourceHref.length === 1) {
                resourceHref = resourceHref[0];
            }
            resourceService.updateCreateAliasName('primaryDependent', resourceHref, true);
        }
    }

    performRefresh(aliasName) {
        setTimeout(() => {
            const refreshParams: any = {};
            const baseAlias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName(aliasName, true);
            refreshParams.url = baseAlias.href;
            super.refreshAction(refreshParams);
        }, 300);
    }
}
