import { OcInfraModule, APICallerService, Configuration, NavigationService, ResourceService, ConfirmDialogComponent } from 'oc-infra';
import { CommonFactory } from './commonFactory';
import { AdvGrowlService } from 'primeng-advanced-growl';
import { Resource } from '../../../node_modules/oc-infra/model/resource';
import { Constants } from '../../../node_modules/oc-infra/util/constants';

export class SearchClientFactory extends CommonFactory {

    navigateTo(params) {
        const navParams = params.defaultValue;
        super.navigateTo(navParams);
    }

    addClient(params){
        OcInfraModule.AppInjector.get(APICallerService).post(Resource.getHostUrl('clients') + 'clients', {},
        'addClient').subscribe(
          response => {
            const navParams = {"url":"addClient", 
            "alias":"addClient"};
            super.navigateTo(navParams);
            
          }
        );
    }

    openClientSummary(params) {
        const navigationParams: any = {};
        navigationParams.url = 'clientSummary';
        navigationParams.link = params.href;
        navigationParams.alias = 'client';
        super.navigateTo(navigationParams);
    }

    deleteClient(params) {
        let confirmDialogData : any = {};
        confirmDialogData.id = params.action.modal;
        confirmDialogData.message = params.action.message;
        confirmDialogData.metamodel = params.action.metamodel;
        confirmDialogData.url = params.href;
        confirmDialogData.resourceData = {
            firstname : params.fields[0].value,
            lastname : params.fields[2].value,
            id: params.fields[6].value 
        };
        confirmDialogData.confirmFunction = () => {
            OcInfraModule.AppInjector.get(APICallerService).delete(params.href).subscribe(deleteResponse => {

                //const refreshParams: any = {};
                //const baseAlias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName('clients', true);
                //refreshParams.url = baseAlias.href;
                //super.refreshAction(refreshParams);

                if (deleteResponse._embedded.length > 0) {
                    const msg = deleteResponse._embedded[0].message;
                    OcInfraModule.AppInjector.get(AdvGrowlService).createErrorMessage(msg, 'Failure');
                } else {
                    OcInfraModule.AppInjector.get(AdvGrowlService).createSuccessMessage('Client deleted successfully', 'Success');
                }

            });
        };
        params.confirmDialog.open(ConfirmDialogComponent, { data: confirmDialogData });
    }
}
