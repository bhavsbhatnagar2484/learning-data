import { FactoryLoader } from'oc-infra';
import { SearchClientFactory } from './searchClientFactory';
import { CustomPropertyFactory } from './customPropertyFactory';
import { DependentSummaryFactory } from './dependentSummaryFactory';
import { AddressSummaryFactory } from './addressSummaryFactory';
import { ClientSummaryFactory } from './clientSummaryFactory';
import { DefaultCustomFactory } from './defaultCustomFactory';
import { AddClientFactory } from './addClientFactory';
export class CustomFactoryLoader implements FactoryLoader {
    getCustomFactory(factory: string) {
        switch (factory) {
            case 'searchClientFactory': return new SearchClientFactory();
            case 'clientSummaryFactory': return new ClientSummaryFactory();
            case 'addressSummaryFactory': return new AddressSummaryFactory();
            case 'dependentSummaryFactory': return new DependentSummaryFactory();
            case 'addClientFactory': return new AddClientFactory();
            default : return new DefaultCustomFactory();
        }
    }
    getCustomPropertyFactory() {
        return new CustomPropertyFactory();
    }
}
