import { ClientSummaryFactory } from './clientSummaryFactory';
import * as _ from 'lodash';
import { OcInfraModule, NavigationService, APICallerService, ResourceService, ConfirmDialogComponent } from'oc-infra';
import { CommonFactory } from './commonFactory';
import { AdvGrowlService } from 'primeng-advanced-growl';

export class DependentSummaryFactory extends ClientSummaryFactory {

    navigateTo(params) {
        super.openClientSummary(params);
    }

    addDependent(params) {
        super.addDependent(params);
        this.performRefresh('dependents');
    }

    createDependent(params) {
        super.createDependent(params);
    }

    editDependent(params) {
        super.editDependent(params);
        this.performRefresh('dependents');
    }

    deleteDependent(params) {
        super.deleteDependent(params);
    }

    deleteDependentFromTable(params) {
        const  confirmDialogData : any = {};
        confirmDialogData.id = params.action.modal;
        confirmDialogData.message = params.action.message;
        confirmDialogData.metamodel = params.action.metamodel;
        confirmDialogData.url = params.href;
        confirmDialogData.confirmFunction = () => {
            OcInfraModule.AppInjector.get(APICallerService).delete(params.href).subscribe(deleteResponse => {

                super.performRefresh('dependents');

                if (deleteResponse._embedded.length > 0) {
                    const msg = deleteResponse._embedded[0].message;
                    OcInfraModule.AppInjector.get(AdvGrowlService).createErrorMessage(msg, 'Failure');
                } else {
                    OcInfraModule.AppInjector.get(AdvGrowlService).createSuccessMessage('Dependent deleted successfully', 'Success');
                }

            });

        };
        params.confirmDialog.open(ConfirmDialogComponent, { data: confirmDialogData });
    }
}
