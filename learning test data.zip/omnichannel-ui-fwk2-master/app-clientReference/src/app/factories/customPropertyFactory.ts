import { Property } from 'oc-infra';
import { CustomSelect } from './../../model/custom-select';

export class CustomPropertyFactory {

    public instanceProperty(property: any): Property {
        switch(property.type) {
            case 'custom-select': 
                return new CustomSelect(property).transformData(property);
            default: 
                return null;
        }
    }

}