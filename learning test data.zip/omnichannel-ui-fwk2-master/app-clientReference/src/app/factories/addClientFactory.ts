import { AdvGrowlService } from 'primeng-advanced-growl';
import * as _ from 'lodash';
import { OcInfraModule, NavigationService, APICallerService, ResourceService } from'oc-infra';
// import { GrowlService } from 'ng2-growl';
import { CommonFactory } from './commonFactory';
import { Observable } from '../../../node_modules/rxjs';


export class AddClientFactory extends CommonFactory {

    patchAddress(params) {
        params.payload.forEach(payloadObj => {
            OcInfraModule.AppInjector.get(APICallerService).patch(payloadObj.url, payloadObj.payload).subscribe(response => {
                OcInfraModule.AppInjector.get(AdvGrowlService).createSuccessMessage('Client Details added successfully', 'Success');
                const navigationParam = {
                    'url': 'searchClient',
                    'link': '',
                    'alias': 'clients'
                }
                super.navigateTo(navigationParam);
            });
        });

    }
    patchPerson(params) {
        //return true;
        let obs = new Observable((observer) =>{
            let payloadObj = params.payload[0];
                OcInfraModule.AppInjector.get(APICallerService).patch(payloadObj.url, payloadObj.payload).subscribe(response => {
                    observer.next({nextStep: true}); 
                    observer.complete();  
                });           
            });        
        return obs;
    }

    navigateTo(params) {
        // OcInfraModule.AppInjector.get(GrowlService).addSuccess({heading: 'Success', message: 'Client Details added successfully'});  
        super.navigateTo(params);
    }

    cancelRegistration(params) {
        const baseAlias = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName('addClient', true);
        const deleteParams: any = {};
        deleteParams.url = baseAlias.href;
        deleteParams.alias = 'addClient';
        super.deleteAction(deleteParams);
        super.navigateTo(params.defaultValue);
    }

}
