import { CommonModule } from '@angular/common';
import { ClientSummaryFactory } from './clientSummaryFactory';
import * as _ from 'lodash';
import { OcInfraModule, NavigationService, APICallerService, ResourceService, ConfirmDialogComponent } from'oc-infra';
import { CommonFactory } from './commonFactory';
import { AdvGrowlService } from 'primeng-advanced-growl';

export class AddressSummaryFactory extends ClientSummaryFactory {

    navigateTo(params) {
        super.openClientSummary(params);
    }

    addAddress(params) {
        super.addAddress(params);
        this.performRefresh('addresses');
    }

    createAddress(params) {
        super.createAddress(params);
    }

    editAddress(params) {
        super.editAddress(params);
        this.performRefresh('addresses');
    }

    deleteAddress(params) {
        super.deleteAddress(params);
    }

    deleteAddressFromTable(params) {
        const  confirmDialogData : any = {};
        confirmDialogData.id = params.action.modal;
        confirmDialogData.message = params.action.message;
        confirmDialogData.metamodel = params.action.metamodel;
        confirmDialogData.url = params.href;
        confirmDialogData.confirmFunction = () => {
            OcInfraModule.AppInjector.get(APICallerService).delete(params.href).subscribe(deleteResponse => {

                super.performRefresh('addresses');

                if (deleteResponse._embedded.length > 0) {
                    const msg = deleteResponse._embedded[0].message;
                    OcInfraModule.AppInjector.get(AdvGrowlService).createErrorMessage(msg, 'Failure');
                } else {
                    OcInfraModule.AppInjector.get(AdvGrowlService).createSuccessMessage('Address deleted successfully', 'Success');
                }

            });
        };

        params.confirmDialog.open(ConfirmDialogComponent, { data: confirmDialogData });
    }
}
