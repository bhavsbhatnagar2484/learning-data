import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { OcInfraModule } from 'oc-infra';
import { CommonService } from './../app/services/common.service';
import { ocInfraConfig } from './ocinfra-config';

@NgModule({
    imports: [OcInfraModule, FormsModule, CommonModule],
    declarations: [],
    exports: [],
    providers: [CommonService]
})
export class SharedModule { }
