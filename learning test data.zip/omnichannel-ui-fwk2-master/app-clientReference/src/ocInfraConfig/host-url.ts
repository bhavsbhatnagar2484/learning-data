
export const hostURL = {
    defaultHostUrl : 'https://client-ref-fwk2-api.mybluemix.net/',
    multiHostUrl: []
}