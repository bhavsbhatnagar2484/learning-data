import { OcInfraConfig } from 'oc-infra';
import { FactoryLoader } from 'oc-infra';
import { CustomFactoryLoader } from './../app/factories/custom-factory.loader';
import { hostURL } from './host-url';

export function CustomFactoryLoaderFunction() {
  return new CustomFactoryLoader();
}

export const ocInfraConfig: OcInfraConfig = {
  hostURL: hostURL,
  debug: true,
  metamodelBaseURL: window.location.origin + '/assets/',
  modifiedHeaderTag: 'X-GraphTalk-Modified',
  deletedHeaderTag: 'X-Delete',
  apiDateFormat: 'yyyy-mm-dd',
  dateFormat: 'dd/mm/yyyy',
  apiDateSeparator: '-',
  custom: {
    provide: FactoryLoader,
    useFactory: CustomFactoryLoaderFunction
  },
  headers: {
    'content-type': 'application/json',
    'accept': 'application/hal+json',
    'accept-language': 'en'
  },
  typeAheadMinChar: 2,
  printErrors: true,
  leftDirLanguages: ['en-GB', 'fr'],
  rightDirLanguages: ['sa'],
  defaultLanguage: 'en-GB',
  themes: ['theme1', 'theme2'],
  recaptchaSiteKey: '',
  loginPage: '/',
  logoutPage: '/logout',
  landingPage: 'searchClient',
  dateOptions: {
    dateFormat: 'dd/mm/yyyy',
    firstDayOfWeek: [
      {'language': ['en-GB', 'fr'], 'firstDayOfWeek': 0},
      {'language': ['sa'], 'firstDayOfWeek': 6}
    ],
  },
  navegableScreens: [{ menu: 'searchClient' }],
  questionnaireConfig: {
    questionsLink: 'questionnaire:questions',
    subQuestionsLink: 'questionnaire:sub_questions',
    questionText: 'question',
    answerValue: 'answer',
    patchOnBlur: true
  },
  numberOptions: {
    lang: 'en'
  },
  profileOptions: [
    {
      title: '_PROFILE',
      screen: 'profile'
    },
    {
      title: '_CONTACT',
      screen: 'contact'
    }
  ],
  SOR: 'CRA'
};
