const lighthouse = require('lighthouse');
const chromeLauncher = require('lighthouse/chrome-launcher');
const log = require('lighthouse-logger');
const fs = require('fs');
const config = require('./config.js');
const perfConfig = require('./lighthouse-config.js');
const Printer = require('lighthouse/lighthouse-cli/printer');

const lighthouseRunner = {
    runAudit : function(url) {
        const flags = { logLevel: 'info', output: 'html' , port: 5858};
        log.setLevel(flags.logLevel);
        return new Promise((resolve)=>{
            lighthouse(url, flags, null).then(results => {
                results.artifacts = undefined;                
                if (config.outputReport) {
                    Printer.checkOutputPath = './report/report.html';        
                    return Printer.write(results, flags.output, config.outputPath);       
                }else{
                    return true;
                };
                resolve(true);
            });
        });
        
    }
}

module.exports = lighthouseRunner;