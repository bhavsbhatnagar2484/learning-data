const config = {
    outputReport: true,
    outputPath: "./reports/report.html"
}

module.exports = config;