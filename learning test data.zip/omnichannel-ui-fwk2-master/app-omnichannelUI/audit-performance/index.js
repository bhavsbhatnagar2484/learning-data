const lighthouse = require('lighthouse');
const chromeLauncher = require('lighthouse/chrome-launcher');
const log = require('lighthouse-logger');
const fs = require('fs');
const config = require('./config.js');
const perfConfig = require('./lighthouse-config.js');
const Printer = require('lighthouse/lighthouse-cli/printer');

function launchChromeAndRunLighthouse(url, flags = {}, config = null) {
    return chromeLauncher.launch().then(chrome => {
        flags.port = chrome.port;
        return lighthouse(url, flags, config);
        //return lighthouse(url, flags, config).then(results =>
        //    chrome.kill().then(() => results));
    });
}

const flags = { logLevel: 'info', output: 'html' };
log.setLevel(flags.logLevel);

launchChromeAndRunLighthouse('https://omnichannel-ui-fwk2-dev.mybluemix.net/#/screen/searchClient', flags, perfConfig).then(results => {
    results.artifacts = undefined;
    if (config.outputReport) {
        Printer.checkOutputPath = './reports/report.html';        
        return Printer.write(results, flags.output, config.outputPath);       
    }else{
        return true;
    }
});