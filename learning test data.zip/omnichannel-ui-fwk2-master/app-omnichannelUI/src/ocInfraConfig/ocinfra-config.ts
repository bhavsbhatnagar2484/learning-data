import { OcInfraConfig } from 'oc-infra';
import { FactoryLoader } from 'oc-infra';
import { CustomFactoryLoader } from './../app/factories/custom-factory.loader';
import { hostURL } from './host-url';

export function CustomFactoryLoaderFunction() {
  return new CustomFactoryLoader();
}

export const ocInfraConfig: OcInfraConfig = {
  hostURL: hostURL,
  debug: true,
  metamodelBaseURL: window.location.origin + '/assets/',
  modifiedHeaderTag: 'X-GraphTalk-Modified',
  deletedHeaderTag: 'X-Delete',
  apiDateFormat: 'yyyy-mm-dd',
  dateFormat: 'dd/mm/yyyy',
  apiDateSeparator: '-',
  custom: {
    provide: FactoryLoader,
    useFactory: CustomFactoryLoaderFunction
  },
  headers: {
    'content-type': 'application/vnd.hal+json',
    'accept': 'application/hal+json',
    'accept-language': 'en'
  },
  typeAheadMinChar: 2,
  printErrors: true,
  leftDirLanguages: ['en', 'es'],
  defaultLanguage: 'en',
  themes: ['theme1', 'theme2'],
  recaptchaSiteKey: '',
  loginPage: '/',
  logoutPage: '/logout',
  landingPage: 'quotesSearch',
  dateOptions: {
    dateFormat: 'dd/mm/yyyy',
    firstDayOfWeek: 0
  },
  navegableScreens: [{ menu: 'quotesSearch' }],
  numberOptions: {
    lang: 'en'
  }
};
