import { OcInfraModule, APICallerService, Configuration, NavigationService, ResourceService } from 'oc-infra';
import { CommonFactory } from './commonFactory';

export class quotesCreateFactory extends CommonFactory{

    patchOwner(params){        
        params.forEach(payloadObj => {
            OcInfraModule.AppInjector.get(APICallerService).patch(payloadObj.url, payloadObj.payload).subscribe(response => {
                console.log('patch successfull')
            });
        }); 
    }
    patchRisk(params){        
        params.forEach(payloadObj => {
            OcInfraModule.AppInjector.get(APICallerService).patch(payloadObj.url, payloadObj.payload).subscribe(response => {
                console.log('patch successfull')
            });
        }); 
    }
    patchAdditionalInfo(params){        
        params.forEach(payloadObj => {
            OcInfraModule.AppInjector.get(APICallerService).patch(payloadObj.url, payloadObj.payload).subscribe(response => {
                console.log('patch successfull')
            });
        }); 
    }
    
    cancel(params){
        let resource = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName(params.defaultValue.alias, true);
        let obj : any ={};
        obj.url = resource.href;
        super.refreshAction(obj);
        super.navigateTo(params.defaultValue);
    }

    startOver(params){
        let navigationParam : any = {}
        navigationParam.url="quotesSearch";
        super.navigateTo(navigationParam);
        let URL = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName('quotes', true);
        let navparam: any = {};
        navparam.url=URL.href;
        super.refreshAction(navparam);
       
    }
        calculatePremium(params){
        // patch aditional info.
        params.forEach(payloadObj => {
            OcInfraModule.AppInjector.get(APICallerService).patch(payloadObj.url, payloadObj.payload).subscribe(response => {
                console.log('patch successfull')
            });
        }); 
                  
        //GET premium URL---
        
        let premiumURL = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName('tariffCal', true);
        let premium: any = {};
        premium.url = premiumURL.href + '/execute';
        OcInfraModule.AppInjector.get(APICallerService).post(premium.url).subscribe(postResponse => {
        //get premium
        let annualCost= postResponse.updateResponse.messages['0'].message[0];
        let annual : any ={};
        annual.url =annualCost;
        annual.optionParams= 'premium';
        super.refreshAction(annual);
        //doing get again 

                          });
                        }
                    }

                