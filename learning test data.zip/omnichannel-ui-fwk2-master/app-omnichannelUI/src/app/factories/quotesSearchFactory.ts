import { OcInfraModule, APICallerService, Configuration, NavigationService, ResourceService } from 'oc-infra';
import { CommonFactory } from './commonFactory';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

export class quotesSearchFactory extends CommonFactory{

    navigateTo(params){
        let navParams =  params.defaultValue;
        super.navigateTo(navParams);

        let URL = OcInfraModule.AppInjector.get(ResourceService).getAliasByAliasName('quotes', true);
        let postUrl : any ={};
        postUrl.url = URL.href;
        postUrl.alias = 'quote';
        super.createAction(postUrl);
    }
    navigateToAsia(params){
       
        const navigationParams: any = {};
        navigationParams.url = 'quotesCreate';
        navigationParams.link = params.href;
        super.navigateTo(navigationParams);
    }
}