import { FactoryLoader } from 'oc-infra';
import { quotesCreateFactory } from "./quotesCreateFactory";
import { CustomPropertyFactory } from "./customPropertyFactory";
import { quotesSearchFactory } from './quotesSearchFactory';
import { DefaultCustomFactory } from './defaultCustomFactory';
export class CustomFactoryLoader implements FactoryLoader {
    getCustomFactory(factory: string) {
        switch (factory) {
            case 'quotesCreateFactory': return new quotesCreateFactory();
            case 'quotesSearchFactory': return new quotesSearchFactory();
            default : return new DefaultCustomFactory();
        }
    }
    getCustomPropertyFactory() {
        return new CustomPropertyFactory();
    }
}
