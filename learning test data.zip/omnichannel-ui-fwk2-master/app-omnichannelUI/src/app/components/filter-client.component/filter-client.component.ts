import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as _ from 'lodash';
import { OptionParams } from 'oc-infra';
import 'rxjs/add/operator/takeWhile';
import { MetamodelService, TextComponent, SelectComponent, DateComponent, ButtonComponent, APICallerService, OcInfraModule, Configuration } from 'oc-infra';
import { CommonFactory } from './../../factories/commonFactory';


@Component({
    "selector": 'filter-client-component',
    "templateUrl": './filter-client.component.html',
    "styleUrls": ['./filter-client.component.scss'],
    "entryComponents": [TextComponent, SelectComponent, DateComponent, ButtonComponent],
})
export class FilterClientComponent extends CommonFactory implements OnInit, OnDestroy {

    private customFields: any;
    private alive  = true;
    
    protected loadMetamodel(metamodelName: string) {
        OcInfraModule.AppInjector.get(MetamodelService).getMetamodel(metamodelName + '.json')
        .takeWhile(() => this.alive)

        .subscribe(metamodel => {
            this.customFields = metamodel;
           
        },
        error => {
            console.log("Error in load metamodel : " + metamodelName + ':' + error);
        });
    }

    ngOnInit(){
        const subscription = this.loadMetamodel("filterQuotes");
    }

    ngOnDestroy(){
        this.alive = false;
    }

    filterClient(event) {
        const optionParams  = new OptionParams();
        optionParams.params = [];

        for (const property of this.customFields.sections[0].properties){
            if (!_.isEmpty(property.value)) {
                optionParams.params.push({'key': property.id, 'value': property.value});
            }
        }
        let refreshParams: any = {};
        refreshParams.url = Configuration.config.hostURL + this.customFields.resource;
        refreshParams.optionParams = optionParams;
        super.refreshAction(refreshParams);

    }

    resetClient(event){
        for (const property of this.customFields.sections[0].properties){
        if (!_.isEmpty(property.value || property.viewValue )) {
        property.value = null;
        property.viewValue = null;
        }
        }
        let refreshParams: any = {};
        refreshParams.url = Configuration.config.hostURL + this.customFields.resource;
        super.refreshAction(refreshParams);
        
        } 
}