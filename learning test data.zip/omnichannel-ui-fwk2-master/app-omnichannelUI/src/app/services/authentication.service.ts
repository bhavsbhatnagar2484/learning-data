import { Injectable, EventEmitter, Output } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { CanActivate } from '@angular/router/src/interfaces';
import * as _ from 'lodash';
import { OcInfraModule, APICallerService, ResourceSchemaService, Configuration } from 'oc-infra';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router/src/router_state';

@Injectable()
export class AuthenticationService implements CanActivate {

    private configURL = 'https://dev.gateway.api.dxc.technology/csc-insurance-api-development/omnichannel-dev/omnichannel/dev/resource/tenants/dxc/configs/appConf';

    private clientId = 'dc1809ba-d09f-4d9f-ae9c-304a7ff6fc88';

    private clientSecret = 'pK8eC3cQ4rD1pV0cC1dQ6uX3mQ5cP2qI1lQ6xG0fS1yP7sA2nN';

    public config: any = {};

    public httpHeaders: Headers;

    @Output()
    getHeaderProperties: EventEmitter<any> = new EventEmitter();

    constructor(private http: Http) {
        this.resetHeaders();
    }

    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
      ): Observable<boolean>|Promise<boolean>|boolean {
        const user = window.sessionStorage.getItem('username');
        const tokenId = window.sessionStorage.getItem('tokenId');
        const localHeaders = OcInfraModule.AppInjector.get(APICallerService).headers.toJSON();
        if (user && tokenId) {
            this.getHeaderProperties.emit(true);
            if (!localHeaders.iPlanetDirectoryPro || !this.httpHeaders.get('iPlanetDirectoryPro') ) {
                this.httpHeaders.set('iPlanetDirectoryPro', tokenId);
                this.changeApiHeaders();
            }
            return true;
        } else {
            this.getHeaderProperties.emit(false);
            window.location.href = window.location.href;
            return false;
        }
    }

    public loadConfig() {
        return this.http.get(this.configURL, { headers: this.httpHeaders })
                .map(response => {
                    const res = response.json();
                    this.config = res.resource_body.config.base;
                    return res;
                })
                .catch(error => {
                    console.log('Error in config load : ' + error.json());
                    return Observable.throw(error);
                });
    }

    public resetHeaders() {
        this.httpHeaders = new Headers;
        this.httpHeaders.set('X-IBM-Client-ID', this.clientId);
        this.httpHeaders.set('X-IBM-Client-Secret', this.clientSecret);
        this.changeApiHeaders();
    }

    public changeApiHeaders() {
        OcInfraModule.AppInjector.get(APICallerService).changeHeaders(this.httpHeaders.toJSON());
        OcInfraModule.AppInjector.get(ResourceSchemaService).changeHeaders(this.httpHeaders.toJSON());
    }

}