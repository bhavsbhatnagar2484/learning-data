import { ElementFinder, browser, by, element, protractor } from 'protractor';
import { CsvProcessor } from './CsvProcessor';
export class Application{

    app:object;
	wait:number;
	csvProcessor : CsvProcessor;
	url:string;
	EC:object;
	currentEnv:string;
	scriptName:string;

	constructor(scriptName:string){
		console.log("do Something here ....");
		this.url = browser.params.Url;
		this.currentEnv = browser.params.env;	
		this.csvProcessor = new CsvProcessor();
		this.initTestData('./e2e/dataRepo/'+ this.currentEnv +'/dataRepo.csv',scriptName);
	}

	initTestData(file:string,testCaseName:string):void{
		var self = this;
		self.csvProcessor.initialize(file,testCaseName);	
		 self.csvProcessor.readDatafromFile(function(data){
		 	self.csvProcessor.initData(data);
		 });
	};

	showDate():void{
		
	}

	launchURL():void{
		browser.driver.manage().window().maximize();
		browser.get(this.url);		
		browser.waitForAngularEnabled(true);
	};

	loginToAppOC(){
		var self = this;	
		var userName = self.csvProcessor.filterData('UserName');
		var password = self.csvProcessor.filterData('Password');

		element(by.xpath('/html/body/div[2]/nav/div/div[1]/div[2]/a')).click();
        browser.sleep(1000);
        element(by.id('inputUsername')).sendKeys(userName);
        element(by.id('inputPassword')).sendKeys(password);
        element(by.id('btn_submit')).click();
        browser.waitForAngularEnabled(true);
	};

	NavigateToQuoteSearchAsia(){
		 browser.waitForAngularEnabled(true);
		 element(by.xpath('//*[@id="component-0"]/span/span/div/div/div[8]/div')).click();		 
	}
	searchQuote(){
		 browser.waitForAngularEnabled(true);	
		 var self = this;
		 var productCode = self.csvProcessor.filterData('productCode');
		 element(by.id('quote-product-id')).sendKeys(productCode);		 
		 element(by.xpath('//*[@id="btn_auto_quote_asia_search"]/span')).click();	
		 browser.sleep(5000);
	}

    
}