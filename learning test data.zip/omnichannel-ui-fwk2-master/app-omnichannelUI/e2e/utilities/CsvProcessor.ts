import * as fs from 'fs';
import * as csv from 'fast-csv';


export class CsvProcessor{

        data:object[];
        fileName:string;
        testCaseName:string;
        newStepIndex:number;        
        tempPerf;

        constructor(){     

            console.log("For csvProcessor........................");

	        this.fileName;
	        this.testCaseName;
	        this.newStepIndex = 0; // Global variable For Writing performance into CSV 
	        this.tempPerf = []; 
        }

        public initialize(fileName:string,testCaseName:string) : void{
            this.fileName = fileName ;
            this.testCaseName = testCaseName;
            if(!fs.existsSync(this.fileName)){
                fs.writeFileSync(this.fileName, "");
            };
        }

        initData(data):void {
            this.data = data ;		
          
        }

        showData():void{
            console.log("fileName : "+this.fileName+" :: testCaseName"+ this.testCaseName);
        }

        readDatafromFile(callback):void {
            var stream = fs.createReadStream(this.fileName);	
            var streamObject = csv.fromStream(stream, {headers : true});
            var completeData = [];
            streamObject.on("data", function(data){
                completeData.push(data);
            })
            .on("end", function(){
                this.data = completeData ;
                callback(completeData);
            });
        }

        filterData(columnName:string) : string {
            var self = this;
            var testCaseName = this.testCaseName;
            var result;
          
            if(self.data){
                result = self.data.filter(function(row){                   
                    return row['TestName'] === testCaseName ;
                })[0][columnName];
            }
            return result;
        }

      buildPerfMetrics(param) : number[]{
            var currentSpec = param.currentSpec;
            var captureTime = param.captureTime;
            var headers = param.headers;
            var perfMetric = param.perfMetric;
            var iteration="";
            var row = {};
            if(headers.length === 0){    
                iteration = "Test - 1";
                row["TestStep"] = currentSpec;
                row[iteration]  = captureTime;
                perfMetric.push(row);
            }else{
                this.newStepIndex++;
                var isAvail = false;
                iteration = "Test - "+ (headers.length);
                for(var i=0;i<perfMetric.length;i++){
                    if(perfMetric[i].TestStep === currentSpec){           
                        perfMetric[i][iteration] = captureTime ; 
                        isAvail = true;
                    }
                }
                if(!isAvail){
                    this.tempPerf = [];
                    row["TestStep"] = currentSpec;
                    row[iteration] = captureTime;          
                    if(this.newStepIndex > perfMetric.length){
                        for(var i=0;i<perfMetric.length;i++){
                            this.tempPerf.push(perfMetric[i]);
                        }
                        this.tempPerf.push(row);
                    }else{
                        for(var i=0;i<(this.newStepIndex-1);i++){
                            this.tempPerf.push(perfMetric[i]);
                        }
                        this.tempPerf.push(row);
                        for(var i=(this.newStepIndex-1);i<perfMetric.length;i++){
                            this.tempPerf.push(perfMetric[i]);
                        }
                    }
                    perfMetric = this.tempPerf;
                }
            }
            return perfMetric;
        }


        getHeaderArray(callback):void{
            var perfFileName  = this.fileName;
            var stream = fs.createReadStream(perfFileName);	
            var streamObject = csv.fromStream(stream, {headers : true});
            var completeData = [];
            streamObject.on("data", function(data){
                completeData.push(data);
            })
            .on("end", function(){
                var headerArray = [];
                for(var i=0;i<completeData.length;i++){
                    var tempJson = completeData[i];
                    for(var key in tempJson){
                        var attrName = key;
                        var isAvail=false;
                        for(var j =0;j<headerArray.length;j++){
                            if(headerArray[j]==attrName){
                                isAvail = true;
                            }
                        }
                        if(!isAvail){
                            headerArray.push(attrName);
                        }
                    }
                }
                callback(headerArray)
            })
        }


         addHeader():void{
            var perfFileName  = this.fileName;
            var stream = fs.createReadStream(perfFileName);	
            var streamObject = csv.fromStream(stream, {headers : true});
            var completeData = [];
            streamObject.on("data", function(data){
                completeData.push(data);
            })
            .on("end", function(){
                var writtableJson = [];
                var headerArray = [];
                for(var i=0;i<completeData.length;i++){
                    var tempJson = completeData[i];
                    for(var key in tempJson){
                        var attrName = key;
                        var isAvail=false;
                        for(var j =0;j<headerArray.length;j++){
                            if(headerArray[j]==attrName){
                                isAvail = true;
                            }
                        }
                        if(!isAvail){
                            headerArray.push(attrName);
                        }
                    }
                }
                headerArray.push( (headerArray.length) + " Test")
                writtableJson.push(headerArray);
                for(var i=0;i<completeData.length;i++){
                    var csvRow = completeData[i];  
                    var tempArray = [];
                    for(var j =0 ;j<headerArray.length;j++){

                        tempArray.push(csvRow[headerArray[j]]);
                    }
                    writtableJson.push(tempArray);
                }
                var ws = fs.createWriteStream(perfFileName);
                csv
                .write(writtableJson, {headers: true})
                .pipe(ws);
            });	
        }

        writeData(data):void{
            var perfFileName = this.fileName ; 
            var ws = fs.createWriteStream(perfFileName);
            csv
            .write(data, {headers: true})
            .pipe(ws);
        }
}