
import { ElementFinder, browser, by, element, protractor } from 'protractor';
import { CsvProcessor } from './CsvProcessor';
import { LoginPage } from './Pages/LoginPage';
import { SearchPage } from './Pages/SearchPage';
import { CreateClientInfoPage } from './Pages/CreateClientInfoPage';
import { CreateAddressInfoPage } from './Pages/CreateAddressInfoPage';
import { ClientSummaryClientInfoPage } from './Pages/ClientSummaryClientInfoPage';
import { ClientSummaryQuestionsPage } from './Pages/ClientSummaryQuestionsPage';
import { ListAddressPage } from './Pages/ListAddressPage';
import { ListDependentPage } from './Pages/ListDependentPage';



export class Application {

app: object;
wait: number;
csvProcessor: CsvProcessor;
url: string;
EC: object;
currentEnv: string;
scriptName: string;
specdata: object;


loginPage: LoginPage;
searchPage: SearchPage;
createClientInfoPage: CreateClientInfoPage;
createAddressInfoPage: CreateAddressInfoPage;
clientSummaryClientInfoPage: ClientSummaryClientInfoPage;
clientSummaryQuestionsPage: ClientSummaryQuestionsPage;
listAddressPage: ListAddressPage;
listDependentPage: ListDependentPage;

constructor(scriptName: string) {
    console.log('do Something here ....');
    this.url = browser.params.Url;
    this.currentEnv = browser.params.env;
    this.csvProcessor = new CsvProcessor();
    this.initTestData('./e2e/dataRepo/' + this.currentEnv + '/ClientReferenceApplication.csv', scriptName);

    this.wait = browser.params.wait;
    this.EC = protractor.ExpectedConditions;
    this.specdata = {};
    this.searchPage = new SearchPage();
    this.loginPage = new LoginPage();
    this.createClientInfoPage = new CreateClientInfoPage();
    this.createAddressInfoPage = new CreateAddressInfoPage();
    this.clientSummaryClientInfoPage = new ClientSummaryClientInfoPage();
    this.clientSummaryQuestionsPage = new ClientSummaryQuestionsPage();
    this.listAddressPage = new ListAddressPage();
    this.listDependentPage = new ListDependentPage();
    
}

initTestData(file: string, testCaseName: string): void {
    const self = this;
    self.csvProcessor.initialize(file, testCaseName);
    self.csvProcessor.readDatafromFile(function (data) {
    self.csvProcessor.initData(data);
  });
};

showDate(): void { }

launchURL(): void {
    browser.driver.manage().window().maximize();
    browser.get(this.url);
    browser.waitForAngularEnabled(true);
    browser.sleep(4000);
};

getParam(criteria: any) {
    const self = this;
    const param = {};
    criteria.forEach(function (item: any) {
 
    const value = this.csvProcessor.filterData(item);
    param[item] = value;
 // console.log("^^^^^^"+value);
 });
    return param;
 };
 
 clientSearchByParams(param) {
     for (let key in param) {
         switch (key) {
             case ('FirstName'):
             this.searchPage.firstNameSearchField().sendKeys(param[key]);
             break;
 
             case ('MiddleName'):
             this.searchPage.middleNameSearchField().sendKeys(param[key]);
             break;
 
             case ('LastName'):
             this.searchPage.lastNameSearchField().sendKeys(param[key]);
             break;
             
             case ('Gender'):
             this.searchPage.genderSearchOption().sendKeys(param[key]);
             break;
 
             case ('DateOfBirth'):
             this.searchPage.dateOfBirthSearchField().sendKeys(param[key]);
             break;
 
             case ('Email'):
             this.searchPage.emailSearchField().sendKeys(param[key]);
             break;
         }
     }
 };

// ----------------------   LOGIN PAGE  -----------------------------------------

loginApplication() {
    const self = this;
    const userName = self.csvProcessor.filterData('UserName');		
    const password = self.csvProcessor.filterData('Password');
   
    this.loginPage.userNameField().sendKeys(userName);
    this.loginPage.passwordField().sendKeys(password);

    this.loginPage.loginButton().click();
    // browser.sleep(6000);
    browser.waitForAngularEnabled(true);
};

logoutIcon() {
  const self =  this;
  const clickLogoutIcon = this.loginPage.logoutIcon();
  browser.wait(protractor.ExpectedConditions.presenceOf(clickLogoutIcon), this.wait)
  .then(function() {
    clickLogoutIcon.click();
  });
};

logoutButton() {
    const self = this;
    const clickLogoutIcon = this.loginPage.logoutButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(clickLogoutIcon), this.wait)
    .then(function() {
      clickLogoutIcon.click();
    });
  };

// -----------------  CREATE CLIENT FUNCTIONS   --------------------------------------- 

// -----------    Fill Client Information  --------
 fillClientInformation(){
    const self = this;	
    const FirstName = self.csvProcessor.filterData('FirstName');
    const MiddleName = self.csvProcessor.filterData('MiddleName');
    const LastName = self.csvProcessor.filterData('LastName');
    const Gender = self.csvProcessor.filterData('Gender');
    const DateOfBirth = self.csvProcessor.filterData('DateOfBirth');
    const Email = self.csvProcessor.filterData('Email');

    const firstNameField = this.createClientInfoPage.firstNameField();
    browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(firstNameField), this.wait)
    .then(function() {
        firstNameField.click();
    });
    this.createClientInfoPage.firstNameField().sendKeys(FirstName);
    this.createClientInfoPage.middleNameField().sendKeys(MiddleName);
   
    this.createClientInfoPage.lastNameField().sendKeys(LastName);
    this.createClientInfoPage.emailField().sendKeys(Email);
    this.createClientInfoPage.dateOfBirthField().sendKeys(DateOfBirth);

    // if (Gender === 'female') {
    //     this.createClientInfoPage.genderFemale().click();
    // }
    // else { 
    //     this.createClientInfoPage.genderMale().click();
    // }
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

// -----------    Fill Address Information  --------

fillAddressInformation(){
    const self = this;	
    const AddressLine1 = self.csvProcessor.filterData('AddressLine1');
    const AddressLine2 = self.csvProcessor.filterData('AddressLine2');
    const City = self.csvProcessor.filterData('City');
    const State = self.csvProcessor.filterData('State');
    const PostalCode = self.csvProcessor.filterData('PostalCode');
    const Country = self.csvProcessor.filterData('Country');
    const AddressType = self.csvProcessor.filterData('AddressType');

    const addressLine1Field = this.createAddressInfoPage.addressLine1Field();
    // browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(addressLine1Field), this.wait)
    .then(function() {
        addressLine1Field.click();
    });
    addressLine1Field.sendKeys(AddressLine1);
    this.createAddressInfoPage.addressLine2Field().sendKeys(AddressLine2);
    this.createAddressInfoPage.cityField().sendKeys(City);
    this.createAddressInfoPage.stateField().sendKeys(State);
    this.createAddressInfoPage.postalCodeField().sendKeys(PostalCode);
    this.createAddressInfoPage.countryField().sendKeys(Country);

    // if (AddressType === 'Primary') {
    //     this.createAddressInfoPage.addressTypePrimary().click();
    // }
    // else {
    //     this.createAddressInfoPage.addressTypeSecondary().click();
    // }
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

// -----------------  CLIENT SUMMARY FUNCTIONS -------------------------------------- 

  // -----------    Update Client Information  --------

  updateClientInfoDetails(){
    const self = this;	
    const FirstName = self.csvProcessor.filterData('edit_FirstName');
    const MiddleName = self.csvProcessor.filterData('edit_MiddleName');
    const LastName = self.csvProcessor.filterData('edit_LastName');
    const Gender = self.csvProcessor.filterData('edit_Gender');
    const DateOfBirth = self.csvProcessor.filterData('edit_DateOfBirth');
    const Email = self.csvProcessor.filterData('edit_Email');

    const editFirstNameField = this.clientSummaryClientInfoPage.editFirstNameField();
    browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(editFirstNameField), this.wait)
    .then(function() {
        editFirstNameField.clear();
    });
    this.clientSummaryClientInfoPage.editFirstNameField().sendKeys(FirstName);

    this.clientSummaryClientInfoPage.editMiddleNameField().clear();
    this.clientSummaryClientInfoPage.editMiddleNameField().sendKeys(MiddleName);

    this.clientSummaryClientInfoPage.editLastNameField().clear();
    this.clientSummaryClientInfoPage.editLastNameField().sendKeys(LastName);

    this.clientSummaryClientInfoPage.editDateOfBirthField().clear();
    this.clientSummaryClientInfoPage.editDateOfBirthField().sendKeys(Email);

    this.clientSummaryClientInfoPage.editEmailField().clear();
    this.clientSummaryClientInfoPage.editEmailField().sendKeys(DateOfBirth);

    // if (Gender === 'female') {
    //     this.createClientInfoPage.genderFemale().click();
    // }
    // else { 
    //     this.createClientInfoPage.genderMale().click();
    // }
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

  // -----------    Update Client Questions  --------

  updateClientQuestions(){
    const self = this;	
    const Smoke = self.csvProcessor.filterData('Smoke');
    const SmokingYears = self.csvProcessor.filterData('SmokingYears');
    const SameNationality = self.csvProcessor.filterData('SameNationality');
    const HazardousActivity = self.csvProcessor.filterData('HazardousActivity');
   
    const hazardousActivityFieldOption = this.clientSummaryQuestionsPage.hazardousActivityFieldOption();
    browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(hazardousActivityFieldOption), this.wait)
    .then(function() {
        hazardousActivityFieldOption.clear();
    });
   
   // hazardousActivityFieldOption('Activity': value).click();
   // this.clientSummaryQuestionsPage.smokeOption('Select': value).click();
    

    // this.clientSummaryQuestionsPage.sameNationalityeField().clear();
    // this.clientSummaryQuestionsPage.sameNationalityeField().sendKeys(SameNationality);

    // this.clientSummaryQuestionsPage.smokingYearsField().clear();
    // this.clientSummaryQuestionsPage.smokingYearsField().sendKeys(SmokingYears);

    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};



  // -----------    Address List Operations  --------

  addAddressInfoDetails(){
    const self = this;	
    const AddressLine1 = self.csvProcessor.filterData('add_AddressLine1');
    const AddressLine2 = self.csvProcessor.filterData('add_AddressLine2');
    const City = self.csvProcessor.filterData('add_City');
    const State = self.csvProcessor.filterData('add_State');
    const PostalCode = self.csvProcessor.filterData('add_Country');
    const Country = self.csvProcessor.filterData('add_PostalCode');
    const AddressType = self.csvProcessor.filterData('add_AddressType');

    const addressLine1Field = this.listAddressPage.addressLine1Field();
    // browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(addressLine1Field), this.wait)
    .then(function() {
        addressLine1Field.click();
    });
    addressLine1Field.sendKeys(AddressLine1);
    this.listAddressPage.addressLine2Field().sendKeys(AddressLine2);
    this.listAddressPage.addCityField().sendKeys(City);
    this.listAddressPage.addStateField().sendKeys(State);
    this.listAddressPage.addPostalCodeField().sendKeys(PostalCode);
    this.listAddressPage.addCountryField().sendKeys(Country);

    // addressTypeOption('Type': value).click();
    
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
 }

 updateExistingAddress(){
    const self = this;	
    const AddressLine1 = self.csvProcessor.filterData('edit_AddressLine1');
    const AddressLine2 = self.csvProcessor.filterData('edit_AddressLine2');
    const City = self.csvProcessor.filterData('edit_City');
    const State = self.csvProcessor.filterData('edit_State');
    const PostalCode = self.csvProcessor.filterData('edit_Country');
    const Country = self.csvProcessor.filterData('edit_PostalCode');
    const AddressType = self.csvProcessor.filterData('edit_AddressType');

    const addressLine1Field = this.listAddressPage.addressLine1Field();
    // browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(addressLine1Field), this.wait)
    .then(function() {
        addressLine1Field.clear();
    });
    addressLine1Field.sendKeys(AddressLine1);

    this.listAddressPage.addressLine2Field().clear();
    this.listAddressPage.addressLine2Field().sendKeys(AddressLine2);

    this.listAddressPage.cityField().clear();
    this.listAddressPage.cityField().sendKeys(City);

    this.listAddressPage.stateField().clear();
    this.listAddressPage.stateField().sendKeys(State);

    this.listAddressPage.postalCodeField().clear();
    this.listAddressPage.postalCodeField().sendKeys(PostalCode);

    this.listAddressPage.countryField().clear();
    this.listAddressPage.countryField().sendKeys(Country);

    // addressTypeOption('Type': value).click();
    
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
 }


 // -----------    Dependent List Operations  --------

 addDependentInfoDetails(){
    const self = this;	
    const DependentName = self.csvProcessor.filterData('add_dependentName');
    const Relation = self.csvProcessor.filterData('add_relation');
    const DependentType = self.csvProcessor.filterData('add_dependentType');
    const DependentDoB = self.csvProcessor.filterData('add_dependentDoB');
 

    const addDependentNameField = this.listDependentPage.addDependentNameField();
    // browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(addDependentNameField), this.wait)
    .then(function() {
        addDependentNameField.click();
    });
    addDependentNameField.sendKeys(DependentName);
    this.listDependentPage.addDependentDoB().sendKeys(DependentDoB);

    //  this.listDependentPage.relationFieldOption().sendKeys(Relation);
    // this.listDependentPage.dependentTypeOption().sendKeys(DependentType);
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
 }

 updateExistingDependent(){
    const self = this;	
    const DependentName = self.csvProcessor.filterData('edit_dependentName');
    const Relation = self.csvProcessor.filterData('edit_relation');
    const DependentType = self.csvProcessor.filterData('edit_dependentType');
    const DependentDoB = self.csvProcessor.filterData('edit_dependentDoB');
  

    const dependentNameField = this.listDependentPage.dependentNameField();
    // browser.sleep(4000);
    browser.wait(protractor.ExpectedConditions.presenceOf(dependentNameField), this.wait)
    .then(function() {
        dependentNameField.click();
    });
    dependentNameField.sendKeys(DependentName);
    this.listDependentPage.dependentDoB().sendKeys(DependentDoB);

    //  this.listDependentPage.relationFieldOption().sendKeys(Relation);
    // this.listDependentPage.dependentTypeOption().sendKeys(DependentType);
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
 }
  // --------------------------------- SEARCH PAGE BUTTONS----------------------------------


clickCreateButton():void{
    const self = this;
    const  createButton = this.searchPage.createButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(createButton), this.wait)
    .then(function() {
        createButton.click();
    });
  };  
 
  clickSearchButton():void{
    const self = this;
    const searchButton = this.searchPage.searchButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(searchButton), this.wait)
    .then(function() {
        searchButton.click();
    });
  };

  clickResetButton():void{
    const self = this;
    const resetButton = this.searchPage.resetButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(resetButton), this.wait)
    .then(function() {
        resetButton.click();
    });
  };

  clickEditButton():void{
    const self = this;
    const editButton = this.searchPage.editButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editButton), this.wait)
    .then(function() {
        editButton.click();
    });
  };
  
  clickDeleteClientButton():void{
    let self = this;
    const deleteButton = this.searchPage.deleteButton();
    const deleteClient = self.csvProcessor.filterData('deleteClient');
    browser.wait(protractor.ExpectedConditions.presenceOf(deleteButton), this.wait)
    .then(function() {
        deleteButton.click();

        if (deleteClient === 'delete')
        {
        browser.sleep(5000); 
        var confirmDeleteButton = this.searchPage.confirmDeleteButton(); 
        browser.wait(protractor.ExpectedConditions.presenceOf(confirmDeleteButton), this.wait)
        .then(function() {
          confirmDeleteButton.click();
         });
        }
    
        else {
        browser.sleep(5000); 
        var cancelDeleteButton = this.searchPage.cancelDeleteButton(); 
        browser.wait(protractor.ExpectedConditions.presenceOf(cancelDeleteButton), this.wait)
        .then(function() {
          cancelDeleteButton.click();
          });
        }
    });
};  

   // -------------------------- CREATE CLIENT BUTTONS --------------------------------
   
   clickAddressInfoButton():void{
    const self = this;
    const nextButton = this.createClientInfoPage.nextButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(nextButton), this.wait)
    .then(function() {
        nextButton.click();
    });
  };

  clickGoClientInfoButton():void{
    const self = this;
    const previousButton = this.createAddressInfoPage.previousButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(previousButton), this.wait)
    .then(function() {
        previousButton.click();
    });
  };
   
  clickStartOverButton():void{
    const self = this;
    const startOverButton = this.createAddressInfoPage.startOverButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(startOverButton), this.wait)
    .then(function() {
        startOverButton.click();
    });
}; 
   
    // clickCancelButton():void{
    //     const self = this;
    //     const cancelButton = this.createAddressInfoPage.cancelButton();
    //     browser.wait(protractor.ExpectedConditions.presenceOf(cancelButton), this.wait)
    //     .then(function() {
    //         cancelButton.click();
    //     });
    // }; 
   
// --------------------------   CLIENT SUMMARY BUTTONS -----------------------------

     clickCloseButton():void{
        const self = this;
        const closeButton = this.clientSummaryClientInfoPage.closeButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(closeButton), this.wait)
        .then(function() {
            closeButton.click();
        });
    }; 
   
 //              -------------- CLIENT INFORMATION SECTION BUTTONS --------------

 clickEditClientInfoButton():void{
    const self = this;
    const editClientInfoButton = this.clientSummaryClientInfoPage.editClientInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editClientInfoButton), this.wait)
    .then(function() {
        editClientInfoButton.click();
    });
};

clickOkClientInfoButton():void{
    const self = this;
    const okClientInfoButton = this.clientSummaryClientInfoPage.okClientInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(okClientInfoButton), this.wait)
    .then(function() {
        okClientInfoButton.click();
    });
};

clickCloseClientInfoButton():void{
    const self = this;
    const closeClientInfoButton = this.clientSummaryClientInfoPage.closeClientInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(closeClientInfoButton), this.wait)
    .then(function() {
        closeClientInfoButton.click();
    });
};
   
//              -------------- CLIENT QUESTION SECTION BUTTONS --------------

clickEditClientQuestionsButton():void{
    const self = this;
    const editClientQuestionsButton = this.clientSummaryQuestionsPage.editClientQuestionsButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editClientQuestionsButton), this.wait)
    .then(function() {
        editClientQuestionsButton.click();
    });
};

clickOkClientQuestionsButton():void{
    const self = this;
    const OkClientQuestionsButton = this.clientSummaryQuestionsPage.OkClientQuestionsButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(OkClientQuestionsButton), this.wait)
    .then(function() {
        OkClientQuestionsButton.click();
    });
};

clickCloseQuestionsButton():void{
    const self = this;
    const closeClientQuestionsButton = this.clientSummaryQuestionsPage.closeClientQuestionsButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(closeClientQuestionsButton), this.wait)
    .then(function() {
        closeClientQuestionsButton.click();
    });
};
  
//               -------------- CLIENT ADDRESS SECTION BUTTONS --------------

    
clickAddressListButton():void{
    const self = this;
    const addressListButton = this.listAddressPage.addressListButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(addressListButton), this.wait)
    .then(function() {
        addressListButton.click();
    });
};

clickAddAddressInfoButton():void{
    const self = this;
    const addAddressInfoButton = this.listAddressPage.addAddressInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(addAddressInfoButton), this.wait)
    .then(function() {
        addAddressInfoButton.click();
    });
}

clickEditAddressButton():void{
    const self = this;
    const editClientAddressButton = this.listAddressPage.editClientAddressButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editClientAddressButton), this.wait)
    .then(function() {
        editClientAddressButton.click();
    });
}

clickAddressInfoOKButton():void{
    const self = this;
    const okAddressInfoButton = this.listAddressPage.okAddressInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(okAddressInfoButton), this.wait)
    .then(function() {
        okAddressInfoButton.click();
    });
}

clickAddressInfoCloseButton():void{
    const self = this;
    const closeAddressInfoButton = this.listAddressPage.closeAddressInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(closeAddressInfoButton), this.wait)
    .then(function() {
        closeAddressInfoButton.click();
    });
}

clickEditListClientAddressButton(): void {
    const self = this; 
    const editListClientAddressButton = this.listAddressPage.editListClientAddressButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editListClientAddressButton), this.wait)
    .then(function() {
        editListClientAddressButton.click();
    });
}

clickDeleteAddressButton(): void {
    const self = this;
    const deleteAddressButton = this.listAddressPage.deleteAddressButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(deleteAddressButton), this.wait)
    .then(function() {
        deleteAddressButton.click();
    });
}

//               -------------- CLIENT DEPENDENT SECTION BUTTONS --------------

clickDependentListButton(): void {
    const self = this;
    const dependentListButton = this.listDependentPage.dependentListButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(dependentListButton), this.wait)
    .then(function() {
        dependentListButton.click();
    });
}

clickAddDependentInfoButton():void{
    const self = this;
    const addDependentInfoButton = this.listDependentPage.addDependentInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(addDependentInfoButton), this.wait)
    .then(function() {
        addDependentInfoButton.click();
    });
}

clickEditDependentButton():void{
    const self = this;
    const editDependentButton = this.listDependentPage.editDependentButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editDependentButton), this.wait)
    .then(function() {
        editDependentButton.click();
    });
}

clickDependentInfoOKButton():void{
    const self = this;
    const okDependentInfoButton = this.listDependentPage.okDependentInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(okDependentInfoButton), this.wait)
    .then(function() {
        okDependentInfoButton.click();
    });
}

clickCloseDependentInfoButton():void{
    const self = this;
    const closeDependentInfoButton = this.listDependentPage.closeDependentInfoButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(closeDependentInfoButton), this.wait)
    .then(function() {
        closeDependentInfoButton.click();
    });
}

clickEditListDependentButton(): void {
    const self = this; 
    const editListDependentButton = this.listDependentPage.editListDependentButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(editListDependentButton), this.wait)
    .then(function() {
        editListDependentButton.click();
    });
}
clickDeleteDependentButton():void{
    const self = this;
    const deleteDependentButton = this.listDependentPage.deleteDependentButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(deleteDependentButton), this.wait)
    .then(function() {
        deleteDependentButton.click();
    });
}


   

};
  



