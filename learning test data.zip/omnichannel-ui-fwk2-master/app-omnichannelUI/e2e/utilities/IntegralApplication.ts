
import { ElementFinder, browser, by, element, protractor } from 'protractor';
import { CsvProcessor } from './CsvProcessor';
import { LoginPage } from './Pages/LoginPage';
import { SearchPage } from './Pages/SearchPage';
import { OwnerInfoPage } from './Pages/OwnerInfoPage';
import { RiskInfoPage } from './Pages/RiskInfoPage';
import { AdditionalInfoPage } from './Pages/AdditionalInfoPage';
import { concat } from 'rxjs/observable/concat';



export class Application {

app: object;
wait: number;
csvProcessor: CsvProcessor;
url: string;
EC: object;
currentEnv: string;
scriptName: string;
specdata: object;


loginPage: LoginPage;
searchPage: SearchPage;
ownerInfoPage: OwnerInfoPage;
riskInfoPage: RiskInfoPage;
additionalInfoPage: AdditionalInfoPage;


constructor(scriptName: string) {
    console.log('do Something here ....');
    this.url = browser.params.Url;
    this.currentEnv = browser.params.env;
    this.csvProcessor = new CsvProcessor();
    this.initTestData('./e2e/dataRepo/' + this.currentEnv + '/IntegralApplication.csv', scriptName);

    this.wait = browser.params.wait;
    this.EC = protractor.ExpectedConditions;
    this.specdata = {};
    this.searchPage = new SearchPage();
    this.loginPage = new LoginPage();
    this.ownerInfoPage = new OwnerInfoPage();
    this.riskInfoPage = new RiskInfoPage();
    this.additionalInfoPage = new AdditionalInfoPage();

}

initTestData(file: string, testCaseName: string): void {
    const self = this;
    self.csvProcessor.initialize(file, testCaseName);
    self.csvProcessor.readDatafromFile(function (data) {
    self.csvProcessor.initData(data);
  });
};

showDate(): void { }

launchURL(): void {
    browser.driver.manage().window().maximize();
    browser.get(this.url);
    browser.waitForAngularEnabled(true);
    browser.sleep(4000);
};

getParam(criteria: any) {
    const self = this;
    const param = {};
    criteria.forEach(function(item){
 
    const value = self.csvProcessor.filterData(item);
    param[item] = value;
    console.log( '^^^^^^' + value);
 });
    return param;
 };

 //  ------------  Function to perform search operation   --------------

 quoteSearchByParams(param: any) {
    browser.sleep(8000);
   // element(by.xpath('//*[@id="toggle-1"]/div/div[1]/div/div/div')).click();
  
     for (let key in param) {
        browser.sleep(2000);
         switch (key) {
            
             case ('ProductID'):
             this.searchPage.productIdSearchField().sendKeys(param[key]);
             break;

             case ('BirthDate'):
             this.searchPage.effectiveDateSearchField().click();
             console.log("clciked++")
             this.searchPage.effectiveDateSearchField().sendKeys(param[key]);
             break;
 
             case ('FullName'):
             this.searchPage.riskHolderSearchField().sendKeys(param[key]);
             break;
 
             case ('QuoteNumber'):
             this.searchPage.quoteNumberSearchOption().sendKeys(param[key]);
             break;
             
             case ('DistributorId'):
             this.searchPage.distributorIdSearchField().sendKeys(param[key]);
             break;
             }   
         browser.sleep(1000);
     }
 };


 //    //   ------------------   LOGIN PAGE  -----------------     //    //

loginApplication() {
    const self = this;
    const userName = self.csvProcessor.filterData('UserName');		
    const password = self.csvProcessor.filterData('Password');
   
    this.loginPage.userNameField().sendKeys(userName);
    this.loginPage.passwordField().sendKeys(password);
    browser.sleep(1000)
    
    this.loginPage.loginButton().click();
    browser.waitForAngularEnabled(true);
};

clickLogoutIcon() {
  const self =  this;
  const clickLogoutIcon = this.loginPage.logoutIcon();
  browser.wait(protractor.ExpectedConditions.presenceOf(clickLogoutIcon), this.wait)
  .then(function() {
    clickLogoutIcon.click();
  });
};

clickLogoutButton() {
    const self = this;
    const clickLogoutIcon = this.loginPage.logoutButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(clickLogoutIcon), this.wait)
    .then(function() {
      clickLogoutIcon.click();
    });
};


   //    //   ------------------   SEARCH PAGE BUTTONS -----------------     //    //

clickCreateButton() {
    const self =  this;
    const clickCreateButton = this.searchPage.createButton();
    browser.wait(protractor.ExpectedConditions.presenceOf(clickCreateButton), this.wait)
    .then(function() {
        clickCreateButton.click();
    });
};
  
clickSearchButton() {
      const self = this;
      const clickSearchButton = this.searchPage.searchButton();
      browser.wait(protractor.ExpectedConditions.presenceOf(clickSearchButton), this.wait)
      .then(function() {
        clickSearchButton.click();
    });
};

clickResetButton() {
        const self = this;
        const clickResetButton = this.searchPage.resetButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickResetButton), this.wait)
        .then(function() {
            clickResetButton.click();
     });
};

clickEditButton() {
        const self = this;
        const clickEditButton = this.searchPage.editButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickEditButton), this.wait)
        .then(function() {
            clickEditButton.click();
    });
};

//    //   ------------------   CREATE PAGE BUTTONS  -----------------     //    //
   
   // ---------------------    OWNER INFO PAGE --------------------  //
clickRiskInfoButton() {
        const self = this;
        const clickRiskInfoButton = this.ownerInfoPage.riskInfoButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickRiskInfoButton), this.wait)
        .then(function() {
        clickRiskInfoButton.click();
    });
};
    
   // ---------------------    RISK INFO PAGE --------------------  //
clickOwnerInfoButton() {
        const self = this;
        const clickOwnerInfoButton = this.riskInfoPage.ownerInfoButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickOwnerInfoButton), this.wait)
        .then(function() {
            clickOwnerInfoButton.click();
    });
};

clickAdditionalInfoButton() {
        const self = this;
        const clickadditionalInfoButton = this.riskInfoPage.additionalInfoButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickadditionalInfoButton), this.wait)
        .then(function() {
            clickadditionalInfoButton.click();
    });
};

     // ---------------------    ADDITIONAL INFO PAGE --------------------  //
clickBackRiskInfoButton() {
        const self = this;
        const clickBackRiskInfoButton = this.additionalInfoPage.backRiskInfoButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickBackRiskInfoButton), this.wait)
        .then(function() {
            clickBackRiskInfoButton.click();
    });
};

clickPremiumInfoButton() {
        const self = this;
        const clickPremiumInfoButton = this.additionalInfoPage.premiumInfoButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickPremiumInfoButton), this.wait)
        .then(function() {
            clickPremiumInfoButton.click();
    });
};

     // ---------------------    PREMIUM INFO PAGE --------------------  //
clickBackaAdditionalInfoButton() {
        const self = this;
        const clickBackaAdditionalInfoButton = this.additionalInfoPage.backaAdditionalInfoButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickBackaAdditionalInfoButton), this.wait)
        .then(function() {
            clickBackaAdditionalInfoButton.click();
    });
};

clickStartOverButton() {
        const self = this;
        const clickstartOverButton = this.additionalInfoPage.startOverButton();
        browser.wait(protractor.ExpectedConditions.presenceOf(clickstartOverButton), this.wait)
        .then(function() {
           // browser.sleep(6000);
            clickstartOverButton.click();
    });
};

//    //   -----------------  CREATE QUOTE FUNCTIONS   ---------------   //    // 

    // //     -----------    Fill Owner Information  --------    // //     
fillOwnerInfo(){
    const self = this;	
    const FullName = self.csvProcessor.filterData('FullName');
    const BirthDate = self.csvProcessor.filterData('BirthDate');
    const Gender = self.csvProcessor.filterData('Gender');
    browser.sleep(4000);
   
    this.ownerInfoPage.partyTypeField().click();

    this.ownerInfoPage.fullNameField().sendKeys(FullName);
    this.ownerInfoPage.birthDate().sendKeys(BirthDate);
    
    if (Gender === 'Female') {
        this.ownerInfoPage.genderOption().click();
    }
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

// // ----------------    Fill Risk Information  --------------  // //

fillRiskInfo(){
    const self = this;	
    const SumInsured = self.csvProcessor.filterData('SumInsured');
    const YearofRegistration = self.csvProcessor.filterData('YearofRegistration');
    const EngineCapacity = self.csvProcessor.filterData('EngineCapacity');
    const DriverName = self.csvProcessor.filterData('DriverName');
    const NCDPercentage = self.csvProcessor.filterData('NCDPercentage');

    this.riskInfoPage.vehicleUseField().click();
    this.riskInfoPage.sumInsuredField().sendKeys(SumInsured);
    this.riskInfoPage.yearofRegistrationField().sendKeys(YearofRegistration);
    
    this.riskInfoPage.modelField().click();
    this.riskInfoPage.engineCapacityField().sendKeys(EngineCapacity);
    this.riskInfoPage.geographicLocationField().click();
    
    this.riskInfoPage.driverNameField().sendKeys(DriverName);
    this.riskInfoPage.quoteCover().click();

    this.riskInfoPage.driverGender().click();
    this.riskInfoPage.ncdPercentage().sendKeys(NCDPercentage);
    this.riskInfoPage.permittedDriver().click();

    browser.waitForAngularEnabled(true);
};

// //     -----------    Fill Additional Information  --------    // //     

fillAdditionalInfo(){
    const self = this;	
    const AdditionalPremium = self.csvProcessor.filterData('AdditionalPremium');
    const AdditionalLimit = self.csvProcessor.filterData('AdditionalLimit');
   
    this.additionalInfoPage.additionalPremiumInfo().sendKeys(AdditionalPremium);
    this.additionalInfoPage.additionalCover().click();
    this.additionalInfoPage.additionalLimit().sendKeys(AdditionalLimit);
    
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

// -----------------  UPDATE QUOTE FUNCTIONS  -------------------------------------- 

  // -----------    Update Owner Information  --------

updateOwnerInfo(){
    const self = this;	
    const FullName = self.csvProcessor.filterData('editFullName');
    const BirthDate = self.csvProcessor.filterData('editBirthDate');
    const Gender = self.csvProcessor.filterData('editGender');
    browser.sleep(4000);
   
    this.ownerInfoPage.editPartyTypeField().click();

    this.ownerInfoPage.editFullNameField().clear();
    this.ownerInfoPage.editFullNameField().sendKeys(FullName);
    
    this.ownerInfoPage.editBirthDate().clear();
    this.ownerInfoPage.editBirthDate().sendKeys(BirthDate);
    
    if (Gender === 'Female') {
        this.ownerInfoPage.genderOption().click();
    }
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

// // ----------------    Update Risk Information  --------------  // //

updateRiskInfo(){
    const self = this;	
    const SumInsured = self.csvProcessor.filterData('editSumInsured');
    const YearofRegistration = self.csvProcessor.filterData('editYearofRegistration');
    const EngineCapacity = self.csvProcessor.filterData('editEngineCapacity');
    const DriverName = self.csvProcessor.filterData('editDriverName');
    const NCDPercentage = self.csvProcessor.filterData('editNCDPercentage');

    this.riskInfoPage.editVehicleUseField().click();
    
    this.riskInfoPage.editSumInsuredField().clear();
    this.riskInfoPage.editSumInsuredField().sendKeys(SumInsured);
    
    this.riskInfoPage.editYearofRegistrationField().clear();
    this.riskInfoPage.editYearofRegistrationField().sendKeys(YearofRegistration);
    
    this.riskInfoPage.editModel().click();
    
    this.riskInfoPage.editEngineCapacityField().clear();
    this.riskInfoPage.editEngineCapacityField().sendKeys(EngineCapacity);
    
    this.riskInfoPage.editGeographicLocationField().click();
    
    this.riskInfoPage.editDriverNameField().clear();
    this.riskInfoPage.editDriverNameField().sendKeys(DriverName);
    
    this.riskInfoPage.editQuoteCover().click();

    this.riskInfoPage.editDriverGender().click();
    
    this.riskInfoPage.editNCDPercentage().clear();
    this.riskInfoPage.editNCDPercentage().sendKeys(NCDPercentage);
    
    this.riskInfoPage.editPermittedDriver().click();
    browser.waitForAngularEnabled(true);
};

// //     -----------    Update Additional Information  --------    // //     

updateAdditionalInfo(){
    const self = this;	
    const AdditionalPremium = self.csvProcessor.filterData('editAdditionalPremium');
    const AdditionalLimit = self.csvProcessor.filterData('editAdditionalLimit');
   
    this.additionalInfoPage.editAdditionalPremiumInfo().clear();
    this.additionalInfoPage.editAdditionalPremiumInfo().sendKeys(AdditionalPremium);

    this.additionalInfoPage.editAdditionalCover().click();

    this.additionalInfoPage.editAdditionalLimit().clear();
    this.additionalInfoPage.editAdditionalLimit().sendKeys(AdditionalLimit);
    
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

//    //   -----------------  VERIFY QUOTE FUNCTIONS   ---------------   //    // 

// //     -----------    Verify Owner Information  --------    // //     

verifyOwnerInfo(){
    const self = this;	
    const PartyType = self.csvProcessor.filterData('PartyType');
    const FullName = self.csvProcessor.filterData('FullName');
    const BirthDate = self.csvProcessor.filterData('BirthDate');
    browser.sleep(4000);
   
    expect(this.ownerInfoPage.partyTypeField().getAttribute('value')).toContain(PartyType);
    expect(this.ownerInfoPage.fullNameField().getAttribute('value')).toContain(FullName);
    expect(this.ownerInfoPage.birthDate().getAttribute('value')).toContain(BirthDate);
    
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};

// // ----------------    Verify Risk Information  --------------  // //

verifyRiskInfo(){
    const self = this;	
    const VehicleUse = self.csvProcessor.filterData('VehicleUse');
    const SumInsured = self.csvProcessor.filterData('SumInsured');
    const YearofRegistration = self.csvProcessor.filterData('YearofRegistration');
    
    const Model = self.csvProcessor.filterData('Model');
    const CommencementDate = self.csvProcessor.filterData('CommencementDate');
    const EngineCapacity = self.csvProcessor.filterData('EngineCapacity');
    
    const GeographicLocation = self.csvProcessor.filterData('GeographicLocation');
    const DriverName = self.csvProcessor.filterData('DriverName');
    const QuoteCover = self.csvProcessor.filterData('QuoteCover');
    
    const DriverGender = self.csvProcessor.filterData('DriverGender');
    const NCDPercentage = self.csvProcessor.filterData('NCDPercentage');
    const PermittedDriver = self.csvProcessor.filterData('PermittedDriver');
   
    
    expect(this.riskInfoPage.vehicleUseField().getAttribute('value')).toContain(VehicleUse);
    expect(this.riskInfoPage.sumInsuredField().getAttribute('value')).toContain(SumInsured);
    expect(this.riskInfoPage.yearofRegistrationField().getAttribute('value')).toContain(YearofRegistration);
    
    expect(this.riskInfoPage.modelField().getAttribute('value')).toContain(Model);
    expect(this.riskInfoPage.commencementDateField().getAttribute('value')).toContain(CommencementDate);
    expect(this.riskInfoPage.engineCapacityField().getAttribute('value')).toContain(EngineCapacity);
   
    expect(this.riskInfoPage.geographicLocationField().getAttribute('value')).toContain(GeographicLocation);
    expect(this.riskInfoPage.driverNameField().getAttribute('value')).toContain(DriverName);
    expect(this.riskInfoPage.quoteCover().getAttribute('value')).toContain(QuoteCover);
    
    expect(this.riskInfoPage.driverGender().getAttribute('value')).toContain(DriverGender);
    expect(this.riskInfoPage.ncdPercentage().getAttribute('value')).toContain(NCDPercentage);
    expect(this.riskInfoPage.permittedDriver().getAttribute('value')).toContain(PermittedDriver);
    browser.waitForAngularEnabled(true);
};

// //     -----------    Verify Additional Information  --------    // //     

verifyAdditionalInfo(){
    const self = this;	
    const AdditionalPremium = self.csvProcessor.filterData('AdditionalPremium');
    const AdditionalCover = self.csvProcessor.filterData('AdditionalCover');
    const AdditionalLimit = self.csvProcessor.filterData('AdditionalLimit');
   
    expect( this.additionalInfoPage.additionalPremiumInfo().getAttribute('value')).toContain(AdditionalPremium);
    expect( this.additionalInfoPage.additionalCover().getAttribute('value')).toContain(AdditionalCover);
    expect( this.additionalInfoPage.additionalLimit().getAttribute('value')).toContain(AdditionalLimit);
    browser.sleep(9000);
    browser.waitForAngularEnabled(true);
};


//    ---------------   END OF FUNCTION ---------------
};
  



