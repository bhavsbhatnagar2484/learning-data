

import {element, ElementFinder, by} from 'protractor';

export class ClientSummaryClientInfoPage {

 // Client Information Section
 editFirstNameField() { return element(by.id('editPersonal_personal_firstName'))}
 editMiddleNameField() { return element(by.id('editPersonal_personal_middleName'))}
 editLastNameField() { return element(by.id('editPersonal_personal_lastName'))}
// editGenderOption() { return element(by.id('personal_gender'))}
 editDateOfBirthField() { return element(by.id('inputUsername'))}
 editEmailField() { return element(by.id('editPersonal_personal_email'))}

 editClientInfoButton() { return element(by.id('editPersonal_edit_person'))}

 okClientInfoButton() { return element(by.xpath('//*[@id="id"]/div/div/div[3]/button[1]'))}
 closeClientInfoButton() { return element(by.xpath('//*[@id="id"]/div/div/div[3]/button[2]'))}
 
 closeButton() { return element(by.xpath('undefined_home-screen'))}

}