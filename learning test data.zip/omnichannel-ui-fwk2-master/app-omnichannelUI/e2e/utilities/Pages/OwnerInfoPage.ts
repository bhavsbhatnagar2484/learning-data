
import {element, ElementFinder, by} from 'protractor';

export class OwnerInfoPage {
 
// Owner Info Fields
 partyTypeField() {return element(by.cssContainingText('option', 'Policy Owner'))}
 fullNameField() { return element(by.id('owner_info_quote-full-name'))}
 birthDate() { return element(by.css('[aria-label="Date input field"]'))}

 // Edit quote
 editPartyTypeField() {return element(by.cssContainingText('option', 'Life Assured'))}
 editFullNameField() { return element(by.id('owner_info_quote-full-name'))}
 editBirthDate() { return element(by.css('[aria-label="Date input field"]'))}

 genderOption() { return element(by.id('quote-gender'))}

 riskInfoButton() { return element(by.id('wizard_ownerInfo_stepNext'))}
 
}
