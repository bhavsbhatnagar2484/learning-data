

import {element, ElementFinder, by} from 'protractor';

export class CreateAddressInfoPage {

 // Create Client Address Page
 addressLine1Field() { return element(by.id('addAddress_address_address1'))}
 addressLine2Field() { return element(by.id('addAddress_address_address2'))}
 cityField() { return element(by.id('addAddress_address_city'))}
 stateField() { return element(by.id('addAddress_address_state'))}
 countryField() { return element(by.id('addAddress_address_country'))}
 postalCodeField() { return element(by.id('addAddress_address_zip'))}
 addressTypePrimary() { return element(by.id('address_type')).$('[value="PRIMARY"]')}
 addressTypeSecondary() { return element(by.id('address_type')).$('[value="SECONDARY"]')}
 
 previousButton() { return element(by.xpathid('//*[@id="wizard-container"]/wizard/div/div/wizard-step/button[1]'))}
 
 startOverButton() { return element(by.xpath('//*[@id="wizard-container"]/wizard/div/div/wizard-step/button[2]'))}
 
 // cancelButton() { return element(by.id('inputUsername'))}
 


}