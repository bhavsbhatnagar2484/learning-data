

import {element, ElementFinder, by} from 'protractor';

export class ListAddressPage {

 // Edit Address Detail
 addressLine1Field() { return element(by.id('currentEditAddress_address_address1'))}
 addressLine2Field() { return element(by.id('currentEditAddress_address_address2'))}
 cityField() { return element(by.id('currentEditAddress_address_city'))}
 stateField() { return element(by.id('currentEditAddress_address_state'))}
 postalCodeField() { return element(by.id('currentEditAddress_address_country'))}
 countryField() { return element(by.id('currentEditAddress_address_zip'))}
 
 addressTypeOption() { return element(by.id('address_type'))}


  // Add Address Detail
  addAddressLine1Field() { return element(by.id('addAddress_address_address1'))}
  addAddressLine2Field() { return element(by.id('addAddress_address_address2'))}
  addCityField() { return element(by.id('addAddress_address_city'))}
  addStateField() { return element(by.id('addAddress_address_state'))}
  addPostalCodeField() { return element(by.id('addAddress_address_zip'))}
  addCountryField() { return element(by.id('addAddress_address_country'))}
 
 
 addressListButton() { return element(by.id('undefined_list_address'))}
 
 editClientAddressButton() { return element(by.id('primaryAddress_edit_address'))}
 
 addAddressInfoButton() { return element(by.id('undefined_create_address'))}

 okAddressInfoButton() { return element(by.xpath('//*[@id="id"]/div/div/div[3]/button[1]'))}
 closeAddressInfoButton() { return element(by.xpath('//*[@id="id"]/div/div/div[3]/button[2]'))}
 

 // ID of below element required
 editListClientAddressButton() { return element(by.xpath('/html/body/app-root/ocinfra-renderer/div[3]/div/div[4]/ocinfra-table/table/tbody/tr[1]/td[15]/span[1]'))}
 
// ID of below element required
 deleteAddressButton() { return element(by.xpath('/html/body/app-root/ocinfra-renderer/div[3]/div/div[4]/ocinfra-table/table/tbody/tr[1]/td[15]/span[2]'))}

}
