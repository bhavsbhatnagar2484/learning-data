

import {element, ElementFinder, by} from 'protractor';

export class RiskInfoPage {

 // Create Quote Risk Page
 vehicleUseField() {return element(by.cssContainingText('option', 'Angle Dozers- Tractors'))}
 sumInsuredField() { return element(by.id('risk_info_quote-sum-insured'))}
 yearofRegistrationField() { return element(by.id('risk_info_quote-year-of-registration'))}

 modelField() {return element(by.cssContainingText('option', 'Kawasaki Honey'))}
 commencementDateField() { return element(by.css('[aria-label="Date input field"]'))}
 engineCapacityField() { return element(by.id('risk_info_quote-engine-capacity'))}
 
 geographicLocationField() {return element(by.cssContainingText('option', 'Kuala Lumpur, Selangor'))}
 driverNameField() { return element(by.id('risk_info_quote-driver-name'))}
 quoteCover() {return element(by.cssContainingText('option', 'Accident'))}
 
 driverGender() {return element(by.cssContainingText('option', 'Female'))}
 ncdPercentage() { return element(by.id('risk_info_quote-NCD-percentage'))}
 permittedDriver() {return element(by.cssContainingText('option', 'Private Car - Insured + 1'))}


 //  Edit quote Risk Page
 editVehicleUseField() {return element(by.cssContainingText('option', 'Bas Kilang'))}
 editSumInsuredField() { return element(by.id('risk_info_quote-sum-insured'))}
 editYearofRegistrationField() { return element(by.id('risk_info_quote-year-of-registration'))}

 editModel() {return element(by.cssContainingText('option', 'Alfa Berlina 2000cc'))}
 editCommencementDateField() { return element(by.css('[aria-label="Date input field"]'))}
 editEngineCapacityField() { return element(by.id('risk_info_quote-engine-capacity'))}
 
 editGeographicLocationField() {return element(by.cssContainingText('option', 'Johor, Pulau Pinang'))}
 editDriverNameField() { return element(by.id('risk_info_quote-driver-name'))}
 editQuoteCover() {return element(by.cssContainingText('option', 'Comp Cover'))}

 
 
 editDriverGender() {return element(by.cssContainingText('option', 'Male'))}
 editNCDPercentage() { return element(by.id('risk_info_quote-NCD-percentage'))}
 editPermittedDriver() {return element(by.cssContainingText('option', 'Motorcycle - Single Driver'))}
 
 // Risk Page Buttons
 ownerInfoButton() { return element(by.id('wizard_riskInfo_stepPrevious'))}
 additionalInfoButton() { return element(by.id('wizard_riskInfo_stepNext'))}

}