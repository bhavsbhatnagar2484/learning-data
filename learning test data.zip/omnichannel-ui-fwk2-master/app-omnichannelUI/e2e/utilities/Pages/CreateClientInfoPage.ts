

import {element, ElementFinder, by} from 'protractor';

export class CreateClientInfoPage {

 
 firstNameField() { return element(by.id('addPersonal_personal_firstName'))}
 middleNameField() { return element(by.id('addPersonal_personal_middleName'))}
 lastNameField() { return element(by.id('addPersonal_personal_lastName'))}
 genderFemale() { return element(by.id('addPersonal_personal_gender_[object Object]'))}
 genderMale() { return element(by.id('addPersonal_personal_gender_[object Object]'))}
 dateOfBirthField() { return element(by.xpath('//*[@id="addPersonal_personal_birthDate"]/div/div/input'))}
 emailField() { return element(by.id('addPersonal_personal_email'))}

 nextButton() { return element(by.xpath('//*[@id="wizard-container"]/wizard/div/wizard-step/button'))}
 
}
