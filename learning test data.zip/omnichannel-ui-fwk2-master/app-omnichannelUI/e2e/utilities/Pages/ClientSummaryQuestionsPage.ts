

import {element, ElementFinder, by} from 'protractor';

export class ClientSummaryQuestionsPage {

// Client Questions Section
 // put ID of following elements
smokeOption() { return element(by.id('inputUsername'))}
smokingYearsField() { return element(by.id('inputPassword'))}
sameNationalityeField() { return element(by.id('question3_answer'))}
hazardousActivityFieldOption() { return element(by.xpath('//*[@id="answer"]'))}


 editClientQuestionsButton() { return element(by.id('questions_edit_question'))}

 OkClientQuestionsButton() { return element(by.xpath('//*[@id="id"]/div/div/div[3]/button[1]'))}
 closeClientQuestionsButton() { return element(by.xpath('//*[@id="id"]/div/div/div[3]/button[2]'))}



}