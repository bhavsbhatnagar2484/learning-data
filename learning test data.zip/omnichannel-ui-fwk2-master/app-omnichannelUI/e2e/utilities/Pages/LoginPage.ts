

import {element, ElementFinder, by} from 'protractor';

export class LoginPage {

loginTab() { return element(by.id('/html/body/app-root/app-login/div/div[3]/button')) }

userNameField() { return element(by.id('authUsername'))}
passwordField() { return element(by.id('authPassword'))}

loginButton() { return element(by.xpath('/html/body/app-root/app-login/div/div[3]/button')) }

logoutIcon() { return element(by.id('dropdownBasicUser')) }
logoutButton() { return element(by.xpath('//*[@id="login"]/ul/li/a')) }
}