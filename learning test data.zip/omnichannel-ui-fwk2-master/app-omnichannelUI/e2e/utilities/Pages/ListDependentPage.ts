

import {element, ElementFinder, by} from 'protractor';

export class ListDependentPage {

 // Edit Dependent Detail
 dependentNameField() { return element(by.id('currentEditDependent_dependent_name'))}
 dependentDoB() { return element(by.xpath('//*[@id="currentEditDependent_dependent_DOB"]/div/div/input'))}
 
 relationFieldOption() { return element(by.id('dependent_relation'))}
 dependentTypeOption() { return element(by.id('dependent_type'))}

  // Add Dependent Detail
 addDependentNameField() { return element(by.id('addDependent_dependent_name'))}
 addDependentDoB() { return element(by.xpath('//*[@id="addDependent_dependent_DOB"]/div/div/input'))}
 
  
 dependentListButton() { return element(by.id('undefined_list_dependent'))}
 
 addDependentInfoButton() { return element(by.id('undefined_create_dependent'))}
 okDependentInfoButton() { return element(by.xpath('//*[@id="id"]/div/div/div[3]/button[1]'))}
 closeDependentInfoButton() { return element(by.xpath('//*[@id="id"]/div/div/div[3]/button[2]'))}
 

 editDependentButton() { return element(by.id('primaryDependent_edit_dependent'))}

 // ID of below element required
 editListDependentButton() { return element(by.xpath('/html/body/app-root/ocinfra-renderer/div[3]/div/div[4]/ocinfra-table/table/tbody/tr/td[5]/span[1]'))}
// ID of below element required
 deleteDependentButton() { return element(by.xpath('/html/body/app-root/ocinfra-renderer/div[3]/div/div[4]/ocinfra-table/table/tbody/tr/td[5]/span[2]'))}

}
 