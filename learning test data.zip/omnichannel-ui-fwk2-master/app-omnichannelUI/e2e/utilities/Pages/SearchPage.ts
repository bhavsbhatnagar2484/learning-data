
import {element, ElementFinder, by} from 'protractor';

export class SearchPage {

 productIdSearchField() { return element(by.id('quote-product-id'))}
 effectiveDateSearchField() { return element(by.css('[aria-label="Date input field"]'))}
 riskHolderSearchField() { return element(by.id('quote-owner-name'))}
 quoteNumberSearchOption() { return element(by.id('quote-identifier'))}
 distributorIdSearchField() { return element(by.id('quote-distributor-id'))}

 createButton() { return element(by.id('create_quote'))}
 
 searchButton() { return element(by.css('[value="Search"]'))}
 resetButton() { return element(by.css('[value="Reset"]'))}
 editButton() { return element(by.css('[class^="fa fa-pencil-square-o iconText"]'))}
 }



