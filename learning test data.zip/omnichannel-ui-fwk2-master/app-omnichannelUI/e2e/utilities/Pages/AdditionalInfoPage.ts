
import {element, ElementFinder, by} from 'protractor';

export class AdditionalInfoPage {

 // Fill Additional Info details
 additionalPremiumInfo() { return element(by.id('risk_info_quote-additional-premium'))}
 additionalCover() {return element(by.cssContainingText('option', 'Breakage of Windscreen Mal'))}
 additionalLimit() { return element(by.id('risk_info_quote-additional-limit'))}

 // Edit Additional Info Details
 editAdditionalPremiumInfo() { return element(by.id('risk_info_quote-additional-premium'))}
 editAdditionalCover() {return element(by.cssContainingText('option', 'Canvas Top'))}
 editAdditionalLimit() { return element(by.id('risk_info_quote-additional-limit'))}

 // Additional Info Page Buttons
 backRiskInfoButton() { return element(by.id('wizard_additionalInfo_stepPrevious'))}
 premiumInfoButton() { return element(by.id('wizard_additionalInfo_stepNext'))}

 // Premium Info Page Buttons
 backaAdditionalInfoButton() { return element(by.id('wizard_premiumInfo_stepPrevious'))}
 startOverButton() { return element(by.id('wizard_premiumInfo_stepNext'))}
}
