//TS_CRA009 - To update client info and add address info in client summary 


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA009', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA009");
  });

   it('TS_CRA009#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA009#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA009#Search Client using - Date of birth', () => {
     var criteria = ['Date of birth'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA009#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA009#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

   it('TS_CRA009#Click Edit Button of Client Info in Client Summary', () => {
     this.application.clickEditClientInfoButton();
  });

   it('TS_CRA009#Update Client Info Details', () => {
     this.application.updateClientInfoDetails();
  });

  it('TS_CRA009#Click Client Info OK Button', () => {
    this.application.clickOkClientInfoButton();
 });

   it('TS_CRA009#Click on Add Address Info Button', () => {
     this.application.clickAddAddressInfoButton();
  });

   it('TS_CRA009#Fill Address Info Details', () => {
     this.application.fillAddressInfoDetails();
  });

   it('TS_CRA009#Click Address Info Ok Button', () => {
     this.application.clickAddressInfoOkButton();
  });

  it('TS_CRA009#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA009#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});