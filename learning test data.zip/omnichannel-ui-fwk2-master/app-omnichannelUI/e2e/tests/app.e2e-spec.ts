import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/Application";
describe('TS001', () => {
 

  beforeAll(() => {
    // Do common configuration for all specs........
   this.application = new Application("TS001");
  });

  it('TS001#should Launch app omnichannel ', () => {    
    this.application.launchURL();    
 });

  it('TS001#should login', () => {
     this.application.loginToAppOC();
  });

  it('TS001#navigate from dashboard to quotesSearch Asia', () => {
     this.application.NavigateToQuoteSearchAsia();
  });

  it('TS001#searchQuote',() =>{
    this.application.searchQuote();
  })
});
