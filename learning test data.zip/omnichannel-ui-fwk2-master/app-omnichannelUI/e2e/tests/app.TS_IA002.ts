// TS_IA002 - To search existing quote by Product ID. 
// Search the existing quote and verify all the fields.

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/IntegralApplication";

describe('TS_IA002', () => {
 beforeAll(() => {
    this.application = new Application('TS_IA002');
  });

  it('TS_IA002#Launch URL', () => {    
    this.application.launchURL();  
  });

  it('TS_IA002#Login to the Application', () => {
     this.application.loginApplication();
  });

    //         -----------  SEARCH CLIENT   ----------    //

  it('TS_IA002#Search Quote By criteria - Product ID', () => {
   const criteria = ['ProductID','QuoteNumber'];
   const param = this.application.getParam(criteria);
   this.application.quoteSearchByParams(param); 
  });;

  it('TS_IA002#Click Search Button', () => {
   this.application.clickSearchButton();
  });

  it('TS_IA002#Go to Searched Quote - click on Edit Button of Searched Quote', () => {
   this.application.clickEditButton();
  });

 //         -----------  VERIFY QUOTE INFORMATION ----------    //

  it('TS_IA002#Verify Owner Information', () => {
   this.application.verifyOwnerInfo();
  });

  it('TS_IA002#Go to Risk Information page', () => {
     this.application.clickRiskInfoButton();
  });

//         -----------  VERIFY RISK INFORMATION ----------    //
  it('TS_IA002#Verify Risk Information', () => {
     this.application.verifyRiskInfo();
  });

  it('TS_IA002#Go to Additional Information Page', () => {
    this.application.clickAdditionalInfoButton();
  });
  
 //         -----------  VERIFY ADDITIONAL INFORMATION ----------    //
  it('TS_IA002#Verify Additional Information', () => {
    this.application.verifyAdditionalInfo();
  });

  it('TS_IA002#Go to Premium Information Page', () => {
    this.application.clickPremiumInfoButton();
  });

   //         -----------   PREMIUM INFORMATION ----------    //
  it('TS_IA002#Click Start Over ', () => {
     this.application.clickStartOverButton();
  });

  it('TS_IA002#Click on Logout Button', () => {
     this.application.clickLogoutIcon();
     this.application.clickLogoutButton();
  });

});
