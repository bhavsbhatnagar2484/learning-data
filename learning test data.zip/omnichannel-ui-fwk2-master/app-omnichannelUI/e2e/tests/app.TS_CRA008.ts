//TS_CRA008 - To delete client - To delete dependent info in client summary 


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA008', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA008");
  });

   it('TS_CRA008#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA008#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA008#Search Client using - Last Name', () => {
     var criteria = ['Last Name'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA008#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA008#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

   it('TS_CRA008#Click Delete Button - First Entry of Dependent Information', () => {
     this.application.clickDeleteDependentButton();
  });

  it('TS_CRA008#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA008#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});