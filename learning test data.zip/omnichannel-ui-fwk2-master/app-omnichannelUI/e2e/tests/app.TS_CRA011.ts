//TS_CRA011 - To update dependent info by editing its details.



import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA011', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA011");
  });

   it('TS_CRA011#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA011#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA011#Search Client using - Email', () => {
     var criteria = ['Email'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA011#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA011#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

  it('TS_CRA011#Click Edit Button of Client Questions in Client Summary', () => {
     this.application.clickEditDependentButton();
  });

  it('TS_CRA011#Update Existing Dependent Details', () => {
     this.application.updateExistingDependent();
  });

  it('TS_CRA011#Click Dependent Ok Button', () => {
     this.application.clickDependentOkButton();
  });

  it('TS_CRA011#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA011#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});