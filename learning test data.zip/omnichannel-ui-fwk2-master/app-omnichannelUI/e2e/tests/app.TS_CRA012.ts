//TS_CRA012 -  To update address info by editing its details


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA012', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA012");
  });

   it('TS_CRA012#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA012#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA012#Search Client using - First Name, Middle Name, Last Name', () => {
     var criteria = ['First Name, Middle Name, Last Name'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA012#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA012#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

  it('TS_CRA012#Click Edit Button of Address in Client Summary', () => {
     this.application.clickEditAddressButton();
  });
  

  it('TS_CRA012#Update Existing Address Details', () => {
     this.application.updateExistingAddress();
  });

  it('TS_CRA012#Click Address Ok Button', () => {
     this.application.clickAddressOkButton();
  });

  it('TS_CRA012#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA012#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});