// TS_IA003 - To search existing quote by  Effective Date. 
// Search the existing quote and verify all the fields.

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/IntegralApplication";

describe('TS_IA003', () => {
  beforeAll(() => {
    this.application = new Application('TS_IA003');
  });

  it('TS_IA003#Launch URL', () => {    
    this.application.launchURL();  
  });

  it('TS_IA003#Login to the Application', () => {
     this.application.loginApplication();
  });

    //         -----------  SEARCH CLIENT   ----------    //

  it('TS_IA003#Search Quote By criteria - Effective Date', () => {
   const criteria = ['EffectiveDate','QuoteNumber'];
   const param = this.application.getParam(criteria);
   this.application.quoteSearchByParams(param); 
  });;

  it('TS_IA003#Click Search Button', () => {
   this.application.clickSearchButton();
  });

  it('TS_IA003#Go to Searched Quote - click on Edit Button of Searched Quote', () => {
   this.application.clickEditButton();
  });

 //         -----------  VERIFY QUOTE INFORMATION ----------    //

  it('TS_IA003#Verify Owner Information', () => {
   this.application.verifyOwnerInfo();
  });

  it('TS_IA003#Go to Risk Information page', () => {
     this.application.clickRiskInfoButton();
  });

//         -----------  VERIFY RISK INFORMATION ----------    //
  it('TS_IA003#Verify Risk Information', () => {
     this.application.verifyRiskInfo();
  });

  it('TS_IA003#Go to Additional Information Page', () => {
    this.application.clickAdditionalInfoButton();
  });
  
 //         -----------  VERIFY ADDITIONAL INFORMATION ----------    //
  it('TS_IA003#Verify Additional Information', () => {
    this.application.verifyAdditionalInfo();
  });

  it('TS_IA003#Go to Premium Information Page', () => {
    this.application.clickPremiumInfoButton();
  });

   //         -----------   PREMIUM INFORMATION ----------    //
  it('TS_IA003#Click Start Over ', () => {
     this.application.clickStartOverButton();
  });

  it('TS_IA003#Click on Logout Button', () => {
     this.application.clickLogoutIcon();
     this.application.clickLogoutButton();
  });

});
