// TS_IA005 - To search existing quote by Quote Number and edit all the fields.. 
// Search the existing quote and edit all the fields.

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/IntegralApplication";

describe('TS_IA005', () => {
  beforeAll(() => {
    this.application = new Application('TS_IA005');
  });

  it('TS_IA005#Launch URL', () => {    
    this.application.launchURL();  
  });

  it('TS_IA005#Login to the Application', () => {
     this.application.loginApplication();
  });

 //         -----------  SEARCH CLIENT   ----------    //

  it('TS_IA005#Search Quote By criteria - Quote Number', () => {
   const criteria = ['QuoteNumber'];
   const param = this.application.getParam(criteria);
   this.application.quoteSearchByParams(param); 
  });;

  it('TS_IA005#Click Search Button', () => {
   this.application.clickSearchButton();
  });

  it('TS_IA005#Go to Searched Quote - click on Edit Button of Searched Quote', () => {
   this.application.clickEditButton();
  });

 //         -----------  EDIT QUOTE INFORMATION ----------    //

  it('TS_IA005#Edit Owner Information', () => {
   this.application.updateOwnerInfo();
  });

  it('TS_IA005#Go to Risk Information page', () => {
     this.application.clickRiskInfoButton();
  });

//         -----------  EDIT RISK INFORMATION ----------    //
  it('TS_IA005#Edit Risk Information', () => {
     this.application.updateRiskInfo();
  });

  it('TS_IA005#Go to Additional Information Page', () => {
    this.application.clickAdditionalInfoButton();
  });
  
 //         -----------  EDIT ADDITIONAL INFORMATION ----------    //
  it('TS_IA005#Edit Additional Information', () => {
    this.application.updateAdditionalInfo();
  });

  it('TS_IA005#Go to Premium Information Page', () => {
    this.application.clickPremiumInfoButton();
  });

   //         -----------   PREMIUM INFORMATION ----------    //
  it('TS_IA005#Click Start Over ', () => {
     this.application.clickStartOverButton();
  });

  it('TS_IA005#Click on Logout Button', () => {
     this.application.clickLogoutIcon();
     this.application.clickLogoutButton();
  });

});
