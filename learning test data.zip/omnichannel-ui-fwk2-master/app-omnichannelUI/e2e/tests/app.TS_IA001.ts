// TS_IA001 - To create new client by filling 
// all the details of client information and address information

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/IntegralApplication";

describe('TS_IA001', () => {
  beforeAll(() => {
    this.application = new Application('TS_IA001');
  });

  it('TS_IA001#Launch URL', () => {    
    this.application.launchURL();  
  });

  it('TS_IA001#Login to the Application', () => {
     this.application.loginApplication();
  });

  it('TS_IA001#Click Create Button', () => {
     this.application.clickCreateButton();
  });

  it('TS_IA001#Fill Owner Information', () => {
     this.application.fillOwnerInfo();
  });

  it('TS_IA001#Go to Risk Information page', () => {
     this.application.clickRiskInfoButton();
  });

  it('TS_IA001#Fill Risk Information', () => {
     this.application.fillRiskInfo();
  });

  it('TS_IA001#Go to Additional Information Page', () => {
    this.application.clickAdditionalInfoButton();
  });
  
  it('TS_IA001#Fill Additional Information', () => {
    this.application.fillAdditionalInfo();
  });

  it('TS_IA001#Go to Premium Information Page', () => {
    this.application.clickPremiumInfoButton();
  });

  it('TS_IA001#Click Start Over ', () => {
     this.application.clickStartOverButton();
  });

  it('TS_IA001#Click on Logout Button', () => {
     this.application.clickLogoutIcon();
     this.application.clickLogoutButton();
  });

});
