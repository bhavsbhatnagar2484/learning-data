//TS_CRA006 - To delete client - search the cient,delete it


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA006', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA006");
  });

   it('TS_CRA006#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA006#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA006#Search Client To be Deleted using - First Name', () => {
     var criteria = ['First Name'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA006#Click Search Button', () => {
     this.application.clickSearchButton();
  });

  it('TS_CRA006#click Delete Button', () => {
     this.application.clickDeleteClientButton();
  });

   it('TS_CRA006#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});
