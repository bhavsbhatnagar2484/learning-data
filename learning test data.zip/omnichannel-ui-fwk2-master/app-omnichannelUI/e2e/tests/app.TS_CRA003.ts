//TS_CRA003 - To search client using middle name and gender,reset details,
//verify all the details of searched client.

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA003', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA003");
  });

   it('TS_CRA003#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA003#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA003#Search Client By criteria -  Middle Name, Gender', () => {
     var criteria = ['Middle Name, Gender'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA003#Click Reset Button', () => {
     this.application.clickResetButton();
  });

    it('TS_CRA003#Search Client By criteria -  Middle Name, Gender', () => {
     var criteria = ['Middle Name, Gender'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA003#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA003#Go to Client Summary - click on Edit Button of Searched Client', () => {
     this.application.clickEditButton();
  });

   it('TS_CRA003#Verify Details of Client Summary', () => {
     this.application.verifyClientSummaryDetails();
  });

   it('TS_CRA003#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA003#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});
