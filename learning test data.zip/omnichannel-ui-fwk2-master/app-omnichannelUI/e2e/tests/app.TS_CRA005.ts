//TS_CRA005 - To search client using last name and email,
//verify all the details of searched client.

import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA005', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA005");
  });

   it('TS_CRA005#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA005#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA005#Search Client By criteria - Last Name ,Email', () => {
     var criteria = ['Last Name ,Email'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

//          ------- CASUAL TEST ------------
  
  it ('TS_CRA005#click Search Link', function(){
      this.application.clickSearchLink(); 
  });

  it ('TS_CRA005#click Filter Button', function(){
     this.application.clickFilterButton(); 
  });

    it ('TS_CRA005#click Edit T Button', function(){
       this.application.clickEditTButton(); 
  });

//  ------------------- END --------------

   it('TS_CRA005#Click Search Button', () => {
     this.application.clickSearchButton();
  });

    it('TS_CRA005#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton(); 
  });

   it('TS_CRA005#Verify Details of Client Summary', () => {
     this.application.verifyClientSummaryDetails();
  });

   it('TS_CRA005#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA005#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});
