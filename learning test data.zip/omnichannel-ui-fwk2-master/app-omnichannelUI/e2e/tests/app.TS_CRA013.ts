//TS_CRA013 - To edit dependent list -              
//1)Delete existing dependent    2)Add dependent-1                                  
//3)Add dependent-2              4)Edit existing dependent       


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA013', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA013");
  });

   it('TS_CRA013#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA013#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA013#Search Client using - Date of Birth,Gender,Email', () => {
     var criteria = ['Date of Birth,Gender,Email'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA013#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA013#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

  it('TS_CRA013#CClick on Dependent List Button', () => {
     this.application.clickDependentListButton();
  });

  it('TS_CRA013#click Delete Button', () => {
     this.application.clickDeleteDependentButton();
  });

  it('TS_CRA013#Click on Add Dependent Info Button', () => {
     this.application.clickAddDependentInfoButton();
  });

 it('TS_CRA013#Fill Dependent-1 Info Details', () => {
     this.application.addDependentInfoDetails();
  });

 it('TS_CRA013#Click Dependent Info Ok Button', () => {
     this.application.clickDependentInfoOkButton();
  });

 it('TS_CRA013#Click on Add Dependent Info Button', () => {
     this.application.clickAddDependentInfoButton();
  });

 it('TS_CRA013#Fill Dependent-2 Info Details', () => {
     this.application.addDependentInfoDetails();
  });

 it('TS_CRA013#Click Dependent Info Ok Button', () => {
     this.application.clickDependentInfoOkButton();
  });

 it('TS_CRA013#Click Edit Button of Dependent in Client Summary', () => {
     this.application.clickEditDependentButton();
  });

 it('TS_CRA013#Update Dependent Details', () => {
     this.application.updateExistingDependent();
  });

 it('TS_CRA013#Click Dependent Ok Button', () => {
     this.application.clickDependentOkButton();
  });

 it('TS_CRA013#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA013#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});