//TS_CRA010 - To update client questions and add dependent info in client summary


import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import { Application } from "../utilities/ClientReferenceApplication";

describe('TS_CRA010', () => {
 
beforeAll(() => {
    this.application = new Application("TS_CRA010");
  });

   it('TS_CRA010#Launch URL', () => {    
    this.application.launchURL();    
  });

   it('TS_CRA010#Login to the Application', () => {
     this.application.loginApplication();
  });

   it('TS_CRA010#Search Client using - Gender', () => {
     var criteria = ['Gender'];
     this.param1 = this.application.getParam(criteria);
     this.application.ClientSearchByParams(this.param1); 
  });

   it('TS_CRA010#Click Search Button', () => {
     this.application.clickSearchButton();
  });

   it('TS_CRA010#Go to Client Summary - click on Edit Button Searched Client', () => {
     this.application.clickEditButton();
  });

  it('TS_CRA010#Click Edit Button of Client Questions in Client Summary', () => {
     this.application.clickEditClientQuestionsButton();
  });

  it('TS_CRA010#Update Client Questions', () => {
     this.application.updateClientQuestions();
  });

  it('TS_CRA010#Click Client Questions Ok Button', () => {
     this.application.clickOkClientQuestionsButton();
  });

  it('TS_CRA010#Click on Add Dependent Info Button', () => {
     this.application.clickAddDependentInfoButton();
  });

  it('TS_CRA010#Fill Dependent Info Details', () => {
     this.application.fillDependentInfoDetails();
  });

  it('TS_CRA010#Click Dependent Info Ok Button', () => {
     this.application.clickDependentInfoOkButton();
  });

  it('TS_CRA010#Click on Close Button', () => {
     this.application.clickCloseButton();
  });

   it('TS_CRA010#Click on Logout Button', () => {
     this.application.logoutIcon();
     this.application.logoutButton();
  });

});