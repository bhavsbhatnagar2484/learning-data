import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RendererComponent } from 'oc-infra';
import { LoginComponent } from './../components/login.component/login.component';
import { LogoutComponent } from './../components/logout.component/logout.component';
import { AuthenticationService } from 'app/services/authentication.service';

const routes: Routes = [
  { path: '', component: LoginComponent},
  { path: 'logout', component: LogoutComponent},
  { path: 'screen/:screenId', component: RendererComponent, canActivate: [ AuthenticationService ]},
  { path: '**', component: LogoutComponent, canActivate: [ AuthenticationService ]},
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule],
})
export class AppRoutingModule { }

export const routedComponents = [RendererComponent];
