import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { OcInfraModule } from 'oc-infra';
import { AdvGrowlModule, AdvGrowlService } from 'primeng-advanced-growl';
import { AppComponent } from '../components/app.component/app.component';
import { AppRoutingModule } from './app-routing.module';

import { ocInfraConfig } from './../../ocInfraConfig/ocinfra-config';
import { SharedModule } from './../../ocInfraConfig/ocinfra-shared.module';
import { LoginComponent } from './../components/login.component/login.component';
import { FooterComponent } from './../components/footer.component/footer.component';
import { LogoutComponent } from './../components/logout.component/logout.component';
import { CommonService } from './../services/common.service';
import { AuthenticationService } from './../services/authentication.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LogoutComponent,
    FooterComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    HttpModule,
    OcInfraModule.forRoot(ocInfraConfig, SharedModule),
    SharedModule,
    AppRoutingModule,
    AngularFontAwesomeModule,
    AdvGrowlModule
  ],
  providers: [
    CommonService,
    AuthenticationService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
