import { OcInfraModule, APICallerService, Configuration, NavigationService, ResourceService } from 'oc-infra';
import { CommonFactory } from './commonFactory';
import { AdvGrowlService } from 'primeng-advanced-growl';

export class SearchQuoteFactory extends CommonFactory {

    public navigateTo(params) {
        super.navigateTo(params.defaultValue);
    }
    
}
