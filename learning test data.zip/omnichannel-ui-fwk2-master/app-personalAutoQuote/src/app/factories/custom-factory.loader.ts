import { FactoryLoader } from 'oc-infra';
import { SearchQuoteFactory } from './searchQuoteFactory';
import { AddPersonalQuoteFactory } from './addPersonalQuoteFactory';
import { DefaultCustomFactory } from './defaultCustomFactory';
import { CustomPropertyFactory } from './customPropertyFactory';

export class CustomFactoryLoader implements FactoryLoader {
    getCustomFactory(factory: string) {
        switch (factory) {
            case 'searchQuoteFactory': return new SearchQuoteFactory();
            case 'addPersonalQuoteFactory': return new AddPersonalQuoteFactory();
            default : return new DefaultCustomFactory();
        }
    }
    getCustomPropertyFactory() {
        return new CustomPropertyFactory();
    }
}
