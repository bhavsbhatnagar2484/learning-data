export class AddPersonalQuoteFactory {

    addApplicantInfo(params) {

    }

    addVehicleInfo(params) {

    }

    addDriverInfo(params) {

    }

    addPremiumInfo(params) {

    }
    
}