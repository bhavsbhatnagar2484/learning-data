import { Property } from './../../../node_modules/oc-infra/ocinfra/model/property';

export class CustomPropertyFactory {
    
    public instanceProperty(property: any): Property {
        switch(property.type) {
            case 'custom-select': 
                //return new CustomSelect(property).transformData(property);
                return null;
            default: 
                return null;
        }
    }

}