export const hostURL = {
    defaultHostUrl : 'https://dev.gateway.api.dxc.technology/csc-insurance-api-development/omnichannel-dev/omnichannel/dev/quotes/pointin-pa/',
    multiHostUrl: []
}