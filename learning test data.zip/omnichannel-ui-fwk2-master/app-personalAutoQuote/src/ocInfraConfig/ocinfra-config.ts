import { OcInfraConfig } from 'oc-infra';
import { FactoryLoader } from 'oc-infra';
import { CustomFactoryLoader } from './../app/factories/custom-factory.loader';
import { hostURL } from "./host-url";

export function CustomFactoryLoaderFunction() {
  return new CustomFactoryLoader();
}

export const ocInfraConfig: OcInfraConfig = {
  hostURL: hostURL,
  debug: true,
  metamodelBaseURL: window.location.origin + '/assets/',
  modifiedHeaderTag: 'X-GraphTalk-Modified',
  deletedHeaderTag: 'X-Delete',
  apiDateFormat: 'yyyy-mm-dd',
  dateFormat: 'dd/mm/yyyy',
  apiDateSeparator: '-',
  custom: {
    provide: FactoryLoader,
    useFactory: CustomFactoryLoaderFunction
  },
  headers: {
    'content-type': 'application/json',
    'accept': 'application/json',
    "accept-language": 'en'
  },
  typeAheadMinChar: 2,
  printErrors: true,
  leftDirLanguages: ['en', 'es'],
  defaultLanguage: 'en',
  themes: ['theme1', 'theme2'],
  recaptchaSiteKey: '',
  offset: {
    xs: 12,
    md: 12,
    sm: 12,
    lg: 12
  },
  colspan: {
    xs: 12,
    md: 12,
    sm: 12,
    lg: 12
  },
  loginPage: '/',
  logoutPage: '/logout',
  landingPage: 'searchQuote',
  dateOptions: {
    dateFormat: 'dd/mm/yyyy',
    firstDayOfWeek: 0
  },
  navegableScreens: [{ menu: 'searchQuote' }],
  numberOptions: {
    lang: 'en'
  }
};